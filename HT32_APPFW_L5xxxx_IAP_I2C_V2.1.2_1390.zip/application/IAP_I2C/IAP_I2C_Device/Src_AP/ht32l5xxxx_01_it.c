/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_AP/ht32l5xxxx_01_it.c
 * @version $Rev:: 541          $
 * @date    $Date:: 2025-05-20 #$
 * @brief   This file provides all interrupt service routine.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "i2c_config.h"
#include "common\ring_buffer.h"

/* Private variables ---------------------------------------------------------------------------------------*/
volatile bool gRestartFlag = FALSE;

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_AP Application example
  * @{
  */

/* Private constants ---------------------------------------------------------------------------------------*/
#define LED_DELAY_COUNTER       500 /* 500ms */

/* Global variables ----------------------------------------------------------------------------------------*/
extern vs32 gIAPCmdTimeout;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
 * @brief   This function handles Hard Fault exception.
 * @retval  None
 ************************************************************************************************************/
void HardFault_Handler(void)
{
  #if 1

  static vu32 gIsContinue = 0;
  /*--------------------------------------------------------------------------------------------------------*/
  /* For development FW, MCU run into the while loop when the hardfault occurred.                           */
  /* 1. Stack Checking                                                                                      */
  /*    When a hard fault exception occurs, MCU push following register into the stack (main or process     */
  /*    stack). Confirm R13(SP) value in the Register Window and typing it to the Memory Windows, you can   */
  /*    check following register, especially the PC value (indicate the last instruction before hard fault).*/
  /*    SP + 0x00    0x04    0x08    0x0C    0x10    0x14    0x18    0x1C                                   */
  /*           R0      R1      R2      R3     R12      LR      PC    xPSR                                   */
  while (gIsContinue == 0)
  {
  }
  /* 2. Step Out to Find the Clue                                                                           */
  /*    Change the variable "gIsContinue" to any other value than zero in a Local or Watch Window, then     */
  /*    step out the HardFault_Handler to reach the first instruction after the instruction which caused    */
  /*    the hard fault.                                                                                     */
  /*--------------------------------------------------------------------------------------------------------*/

  #else

  /*--------------------------------------------------------------------------------------------------------*/
  /* For production FW, you shall consider to reboot the system when hardfault occurred.                    */
  /*--------------------------------------------------------------------------------------------------------*/
  NVIC_SystemReset();

  #endif
}

/*********************************************************************************************************//**
 * @brief   This function handles SysTick Handler.
 * @retval  None
 ************************************************************************************************************/
void SysTick_Handler(void)
{
  static u32 LedFlag = 0;
  static u32 uLEDDelayCounter = LED_DELAY_COUNTER;
  if(uLEDDelayCounter >0)
  {
    uLEDDelayCounter--;
  }
  else
  {
    if(LedFlag == 0)
    {
      LedFlag = 1;
      HT32F_DVB_LEDOn(HT_LED1);
    }
    else
    {
      LedFlag = 0;
      HT32F_DVB_LEDOff(HT_LED1);
    }
    uLEDDelayCounter = LED_DELAY_COUNTER;
  }
  if(gIAPCmdTimeout>0)
    gIAPCmdTimeout--;
}

/*********************************************************************************************************//**
 * @brief   This function handles I2C interrupt.
 * @retval  None
 ************************************************************************************************************/
void HTCFG_IAPI2C_IRQHandler(void)
{
  extern Buffer_TypeDef gTx;
  extern Buffer_TypeDef gRx;
  extern vu32 isTxFinish;
  u8 uData;
  u32 uResult;

  uResult = I2C_ReadRegister(HTCFG_IAPI2C_PORT, I2C_REGISTER_SR);
  /*----------------------------- Error Process ------------------------------------------------------------*/
  if(uResult & I2C_FLAG_BUSERR)
  {
    Buffer_Discard(&gRx);
    Buffer_Discard(&gTx);
    I2C_ClearFlag(HTCFG_IAPI2C_PORT, I2C_FLAG_BUSERR);
  }
  /*----------------------------- Stop Process -------------------------------------------------------------*/
  if(uResult & I2C_FLAG_STO)
  {
    if(uResult & I2C_FLAG_RXDNE)
    {
      /* Rx not empty                                                                                       */
      gRestartFlag = FALSE;
      /* Receive data sent from I2C                                                                         */
      Buffer_WriteByte(&gRx, I2C_ReceiveData(HTCFG_IAPI2C_PORT));
    }
    if((uResult == I2C_FLAG_STO) ||
       (uResult ==  (I2C_FLAG_BUSBUSY|I2C_FLAG_STO|I2C_FLAG_ADRS)) ||
       (uResult & I2C_FLAG_RXDNE))
    {
      gRestartFlag = FALSE;
    }
  }
  else if (uResult & I2C_FLAG_RXNACK)
  {
    /* Clear RXNACK flag                                                                                    */
    I2C_ClearFlag(HTCFG_IAPI2C_PORT, I2C_FLAG_RXNACK);
    isTxFinish = TRUE;
  }
  /*-----------------------------Rx Process ----------------------------------------------------------------*/
  else if(uResult & I2C_FLAG_RXDNE)
  {
    if((uResult&I2C_FLAG_ADRS) || (uResult&I2C_FLAG_TXDE)==0)
    {
      /* Restart Mode                                                                                       */
      gRestartFlag = TRUE;
      Buffer_WriteByte(&gRx, I2C_ReceiveData(HTCFG_IAPI2C_PORT));
    }
    else if(uResult&I2C_FLAG_RXBF)
    {
      /* Rx buffer full                                                                                     */
      Buffer_WriteByte(&gRx, I2C_ReceiveData(HTCFG_IAPI2C_PORT));
    }
  }
  /*-----------------------------Tx Process ----------------------------------------------------------------*/
  else if(uResult & I2C_FLAG_TXDE)
  {
    if(gRestartFlag == TRUE)
    {
      /* Restart Mode                                                                                       */
      gRestartFlag = FALSE;
    }
    if (Buffer_ReadByte(&gTx, &uData))
    {
      /* Send the remainder data to Master                                                                  */
      I2C_SendData(HTCFG_IAPI2C_PORT, uData);
    }
    else
    {
      /* Tx Buffer is empty                                                                                 */
      #if (I2C_ENABLE_DUMMY_DATA == 1)
        I2C_SendData(HTCFG_IAPI2C_PORT, I2C_DUMMY_DATA_VALUE);
      #else
        I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_TXDE, DISABLE);
      #endif
    }
  }
}


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
