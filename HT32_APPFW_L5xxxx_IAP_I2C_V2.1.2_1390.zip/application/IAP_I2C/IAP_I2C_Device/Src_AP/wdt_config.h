/*********************************************************************************************************//**
 * @file    wdt_config.h
 * @version $Rev:: 499          $
 * @date    $Date:: 2025-02-24 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __WDT_CONFIG
#define __WDT_CONFIG

/* Settings ------------------------------------------------------------------------------------------------*/
//    <q0> Enable Watch Dog Timer
//          <i> Default WDT = DISABLE
#define ENABLE_WDT                        (0)

/* Private constants ---------------------------------------------------------------------------------------*/
#if ENABLE_WDT
    #define WDT_RST WDT_Restart
#else
    #define WDT_RST(...)
#endif

#endif
