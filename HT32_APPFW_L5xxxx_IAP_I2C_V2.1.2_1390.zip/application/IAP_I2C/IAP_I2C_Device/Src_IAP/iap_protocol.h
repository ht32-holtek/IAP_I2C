/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_IAP/iap_protocol.h
 * @version $Rev:: 605          $
 * @date    $Date:: 2025-06-16 #$
 * @brief   The header file of IAP Protocol.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_PROTOCOL_H
#define __IAP_PROTOCOL_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_IAP IAP example
  * @{
  */

/* Settings ------------------------------------------------------------------------------------------------*/
/* Exported typedef ----------------------------------------------------------------------------------------*/

/* IAP Command                                                                                              */
/**
 * @brief IAP Command and return value
 */
typedef enum
{
  IAP_CMD_START_IAP = 0x8101U,
  IAP_CMD_START_APP = 0x8102U,
  IAP_CMD_ERASE     = 0x8103U,
  IAP_CMD_FLASH     = 0x8104U,
  IAP_CMD_CRC       = 0x8105U,
  IAP_CMD_GETINFO   = 0x8106U,

  IAP_RET_OK        = 0x5A01U,
  IAP_RET_FAIL      = 0x5A02U,
  IAP_RET_CMDERROR  = 0x5A03U,

  IAP_STATE_DATA_CONTINUE   = 0xF100U,
  IAP_STATE_RESET           = 0xF101U,
  IAP_STATE_BUFF_NOT_READY  = 0xF102U,
} IAP_CODE_Enum;

/**
 * @brief IAP Parameter for Flash command
 */
typedef enum
{
  IAP_PARA_PROGRAM = 0x00,
  IAP_PARA_VERIFY  = 0x01,
  IAP_PARA_READ    = 0x02,
} IAP_PARA_Enum;

/**
 * @brief IAP Protocol
 */
typedef __PACKED_H struct
{
  IAP_CODE_Enum Code;
  IAP_CODE_Enum Check;
  unsigned char  uLength;
  unsigned char  uPara;
  unsigned short uCRC;
  unsigned int   uStAddr;
  unsigned int   uEndAddr;
} __PACKED_F IAP_Protocol_TypeDef;

/* Exported constants --------------------------------------------------------------------------------------*/
#define IAP_CODE_LENGTH               (sizeof(IAP_CODE_Enum) * 2)   /* Bytes                                */
#define IAP_CMD_COUNT                 (6)                           /* Supported command count              */
#define IAP_RX_DATA_PACKET_SIZE       (128)                         /* Data packet size                     */
#define IAP_TX_DATA_PACKET_SIZE       (20)                          /* Data packet size                     */
#define IAP_CMDVALID                  (0xFFFF)                      /* Expect Code + Check value            */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* __IAP_PROTOCOL_H ---------------------------------------------------------------------------------*/
