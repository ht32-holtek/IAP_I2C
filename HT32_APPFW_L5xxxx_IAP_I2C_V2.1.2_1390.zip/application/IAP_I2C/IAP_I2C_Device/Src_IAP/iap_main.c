/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_IAP/iap_main.c
 * @version $Rev:: 568          $
 * @date    $Date:: 2025-05-29 #$
 * @brief   The main program of IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board_config.h"
#include "i2c_config.h"
#include "iap_config.h"
#include "iap_handler.h"
#include "iap_wdt_config.h"
#include "common\ring_buffer.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_IAP IAP example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define TIMER_BASE                    (UDIV32(SystemCoreClock, 8000))  /* 1 ms                              */

/* Private function prototypes -----------------------------------------------------------------------------*/
void IAPUser_BootProcess(void);
void NVIC_Configuration(void);
void CKCU_Configuration(void);
void GPIO_Configuration(void);
void I2C_Configuration(void);

/* Global variables ----------------------------------------------------------------------------------------*/
#if (IAP_TIMEOUT_EN == 1)
s32 gIAPTimeout = IAP_TIMEOUT;
#endif
#if (IAP_DOUBLE_RESET_EN == 1)
s32 gDoubleTimeout = IAP_DOUBLE_TIMEOUT;
#endif

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  #if !ENABLE_WDT
    WDT_DeInit();
  #endif

  #if (IAP_DEBUG_MODE == 1)
  RETARGET_Configuration();
  #endif

  IAPUser_BootProcess();

  NVIC_Configuration();

  CKCU_Configuration();

  GPIO_Configuration();

  I2C_Configuration();

  IAP_Init();

  while (1)
  {
    IAP_Handler();                      /* Start IAP mode                                                   */
    WDT_RST();
  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level boot process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_BootProcess(void)
{
  #if 0
  /* !!! NOTICE !!!
        Modify it if you want to use another GPIO pin.
  */
  /*--------------------------------------------------------------------------------------------------------*/
  /* Example that using GPIO to force the IAP mode.                                                         */
  /* GPIO = 1: Normal boot flow, GPIO = 0: IAP mode                                                         */
  /*--------------------------------------------------------------------------------------------------------*/
  {
    CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
    CKCUClock.Bit.PA      = 1;
    CKCU_PeripClockConfig(CKCUClock, ENABLE);
  }
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_0, GPIO_DIR_IN);
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_0, ENABLE);
  if (GPIO_ReadInBit(HT_GPIOA, GPIO_PIN_0) == SET)
  #endif
  {
    #if (IAP_TIMEOUT_EN == 1)
    if (BOOT_MODE == BOOT_MODE_APP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 and                                                                                    */
      /*   2. BOOT_MODE == BOOT_MODE_AP (Default IAP) and                                                   */
      /*   3. SP and PC of user's application is in range                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_GoCMD(IAP_APFLASH_START);
    }
    #elif (IAP_DOUBLE_RESET_EN == 1)
    if (RSTCU_GetResetFlagStatus(RSTCU_FLAG_EXTRST) == SET)
    {
      /* External IO reset.                                                                                 */
      if (HARDWAVE_RESET == HARDWAVE_RESET_FIRST)
      {
        /* The second external IO reset.                                                                    */
        HARDWAVE_RESET = 0;
      }
      else
      {
        /* The first external IO reset, stay in IAP mode.                                                   */
        HARDWAVE_RESET = HARDWAVE_RESET_FIRST;
      }
      RSTCU_ClearResetFlag(RSTCU_FLAG_EXTRST);
    }
    else
    {
      if (BOOT_MODE != BOOT_MODE_IAP)
      {
        /*--------------------------------------------------------------------------------------------------*/
        /* Start user application when                                                                      */
        /*   1. BOOT_MODE != BOOT_MODE_IAP (Default AP) and                                                 */
        /*   2. SP and PC of user's application is in range                                                 */
        /*--------------------------------------------------------------------------------------------------*/
        IAP_JumpToAP(IAP_APFLASH_START);
      }
    }
    #else
    if (BOOT_MODE != BOOT_MODE_IAP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 and                                                                                    */
      /*   2. BOOT_MODE != BOOT_MODE_IAP (Default AP) and                                                   */
      /*   3. SP and PC of user's application is in range                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_JumpToAP(IAP_APFLASH_START);
    }
    #endif
    DIV32_Init();
    SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);
    SYSTICK_SetReloadValue(TIMER_BASE);
    SYSTICK_IntConfig(ENABLE);
    SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
    SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
  }
}

/*********************************************************************************************************//**
  * @brief  This function is used to configure NVIC.
  * @retval None
  ***********************************************************************************************************/
void NVIC_Configuration(void)
{
  /* Enable NVIC I2C interrupt                                                                              */
  NVIC_EnableIRQ(HTCFG_IAPI2C_IRQn);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
  CKCUClock.Bit.AFIO              = 1;
  CKCUClock.Bit.HTCFG_IAPI2C_IPN  = 1;
  HTCFG_IAPI2C_SDA_GPIO_CLK(CKCUClock) =1;
  HTCFG_IAPI2C_SCL_GPIO_CLK(CKCUClock) =1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}

/*********************************************************************************************************//**
  * @brief  Configure the GPIO ports.
  * @retval None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
  AFIO_GPxConfig(HTCFG_IAPI2C_SCL_GPIO_ID, HTCFG_IAPI2C_SCL_AFIO_PIN, AFIO_FUN_I2C);
  AFIO_GPxConfig(HTCFG_IAPI2C_SDA_GPIO_ID, HTCFG_IAPI2C_SDA_AFIO_PIN, AFIO_FUN_I2C);
}

/*********************************************************************************************************//**
  * @brief  Configures I2C.
  * @retval None
  ***********************************************************************************************************/
void I2C_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  I2C_InitTypeDef  I2C_InitStructure;

  /* I2C configuration                                                                                      */
  I2C_InitStructure.I2C_GeneralCall = DISABLE;
  I2C_InitStructure.I2C_AddressingMode = I2C_ADDRESSING_7BIT;
  I2C_InitStructure.I2C_Acknowledge = ENABLE;
  I2C_InitStructure.I2C_OwnAddress = I2C_SLAVE_ADDRESS_IAP;
  I2C_InitStructure.I2C_Speed = I2C_CLOCK_SPEED;
  I2C_InitStructure.I2C_SpeedOffset = 0;
  #if (LIBCFG_I2C_NOSTRETCH)
  I2C_InitStructure.I2C_StretchMode = I2C_STRETCH_YES;
  #endif
  I2C_Init(HTCFG_IAPI2C_PORT, &I2C_InitStructure);

  /* Enable I2C                                                                                             */
  I2C_Cmd(HTCFG_IAPI2C_PORT, ENABLE);

  /* Enable I2C interrupts                                                                                  */
  I2C_IntConfig(HTCFG_IAPI2C_PORT,
              I2C_INT_BUSERR |
              I2C_INT_ADRS |
              I2C_INT_TXDE |
              I2C_INT_RXNACK |
              I2C_INT_RXBF |
              I2C_INT_STO,
              ENABLE);

  I2C_CombFilterCmd(HTCFG_IAPI2C_PORT, ENABLE);
  I2C_SequentialFilterConfig(HTCFG_IAPI2C_PORT, SEQ_FILTER_2_PCLK);
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
