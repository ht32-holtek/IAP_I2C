/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_IAP/iap_handler.c
 * @version $Rev:: 608          $
 * @date    $Date:: 2025-06-18 #$
 * @brief   This file contains IAP handler.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board_config.h"
#include "i2c_config.h"
#include "iap_config.h"
#include "iap_handler.h"
#include "common\ring_buffer.h"
#include "iap_crc16.h"
#include "iap_wdt_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_handler IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_handler_IAP IAP example
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
typedef IAP_CODE_Enum (*pFunction)(void);

/* Private constants ---------------------------------------------------------------------------------------*/
#define __DBG_IAPPrintf(...)

#if (IAP_DEBUG_MODE == 1)
  #undef __DBG_IAPPrintf
  #define __DBG_IAPPrintf printf
  static void _IAP_DumpData(u32 uSatrt, u32 uLength);
  #warning "================================ IAP Debug Mode Warning ================================"
  #warning " 1. IAP debug mode has been enable which degrade the performance.                       "
  #warning " 2. Note that print debug message too much may cause the IAP command not synchronized.  "
  #warning " 3. Remember to modify Host/Device IAP_CODE_SIZE define according to the IAP Size       "
  #warning "    after enable IAP debug mode.                                                        "
  #warning " 4. After all debug operation is finished, please remember to turn off IAP debug mode.  "
  #warning "========================================================================================"
#endif

#define IAP_CMD_ERROR          (IAP_CMD_COUNT)

#define IAP_APFLASH_END        (IAP_APFLASH_SIZE - 1)
#define IAP_APSRAM_END         (HT_SRAM_BASE + IAP_APSRAM_SIZE)

#define LOADER_MODE            (0x1)
#define LOADER_FLASH_START     (IAP_CODE_SIZE)
#define LOADER_CHIP_NAME       (0)
#define LOADER_PAGE_SIZE       (HT_FLASH->PSSR)
#define LOADER_FLASH_NUM       ((LIBCFG_FLASH_SIZE - IAP_CODE_SIZE)/LIBCFG_FLASH_PAGESIZE)
#define LOADER_PPBIT_NUM       (0) /* Reserved for storing CRC16 in IAP_I2C Application */
#define LOADER_FULL_CHIP_NAME  ((HT_FLASH->DID) & 0x0FFFFFFF)

#define INF_COUNT              (5)
#define LOADER_INFO0           (u32)((LOADER_MODE      << 28) | (LOADER_VERSION     << 16) | LOADER_CHIP_NAME)
#define LOADER_INFO1           (u32)((LOADER_PAGE_SIZE << 16) | (LOADER_FLASH_START << 0))
#define LOADER_INFO2           (u32)((LOADER_FLASH_NUM << 16) | (LOADER_PPBIT_NUM   << 0))
#define LOADER_INFO3           (u32)(IAP_CODE_SIZE + IAP_VER_ADDR)
#define LOADER_INFO4           (u32)(LOADER_FULL_CHIP_NAME)

#define IAP_CMD_TIMEOUT_BUFFER_RELOAD_CMD     (29)
#define IAP_CMD_TIMEOUT_TX_DATA               (229)
#define IAP_CMD_TIMEOUT_RESULT                (19)
#define IAP_CMD_TIMEOUT_RX_DATA               (36)
#define IAP_CMD_TIMEOUT_RETURN_IDLE_TIMEROUT  (250)
#define IAP_CMD_TIMEOUT_IDLE_BUSBUSY_TIMEROUT (200)

#define IAP_FIRST_PROGRAM_SIZE                (56)

/* Private variables ---------------------------------------------------------------------------------------*/
static u32 gu32Infotable[INF_COUNT];
static IAP_CODE_Enum _IAP_GetCommand(s32 *cmdIndex);
static IAP_CODE_Enum _IAP_SendResult(IAP_CODE_Enum Result, u8* buffer, u32 len);
static IAP_CODE_Enum _IAP_CMDStartIAP(void);
static IAP_CODE_Enum _IAP_CMDStartAP(void);
static IAP_CODE_Enum _IAP_CMDErase(void);
static IAP_CODE_Enum _IAP_CMDFlash(void);
static IAP_CODE_Enum _IAP_CMDCRC(void);
static IAP_CODE_Enum _IAP_CMDGetInfo(void);

static IAP_CODE_Enum _IAP_DataFlash(void);
static IAP_CODE_Enum _IAP_DataCRC(void);

static bool _IAP_WaitTxBuffer(bool isBlocking);
static void _IAP_TimeoutHandler(bool bResetTx, bool bResetRx, bool bResetIP);

/* Private macro -------------------------------------------------------------------------------------------*/
#define _GET_BUFFER_ADDR()            ((IAP_Protocol_TypeDef *)&iapInfo.buffer[0])
#define ARRAY_SIZE(x)                 sizeof(x)/sizeof(x[0])

/* Private types -------------------------------------------------------------------------------------------*/
/**
 * @brief   IAP processing flow steps
 */
typedef enum {
    IAP_STEP_IDLE,             /**< No operation, waiting for new command    */
    IAP_STEP_GET_CMD,          /**< Read incoming command identifier         */
    IAP_STEP_EXEC_CMD,         /**< Execute the requested command            */
    IAP_STEP_GET_DATA,         /**< Retrieve response/data from command      */
    IAP_STEP_WAIT_RET,         /**< Wait until TX buffer is free             */
    IAP_STEP_WAIT_END,     /**< Finalize transmission and return to idle */
    IAP_STEP_RESET,
} IAPFlowStep;

/**
 * @brief   IAP context information
 */
typedef struct {
    u8               buffer[20];        /**< IAP Command Buffer              */
    IAPFlowStep      currentStep;       /**< Current step in the IAP flow    */
    s32              commandId;         /**< Index of the command to execute */
    u32              bufferPos;         /**< Position in the command buffer  */
    vs32            *pTimeout;          /**< Pointer to timeout counter      */
    bool             txEmpty;           /**< Flag: TX buffer empty           */
    bool             timeoutFlag;       /**< Flag: Timeout occurred          */
    IAP_CODE_Enum    lastResult;        /**< Result code of last operation   */
    IAP_CODE_Enum    cmd;               /**< IAP Command                     */
} IAPInfo;

/**
 * @brief   IAP Data handler
 */
typedef struct {
  IAP_CODE_Enum cmd;
  pFunction pFun;
}IAP_DataHandler_Type;

/* Exported typedef ----------------------------------------------------------------------------------------*/
typedef __PACKED_H struct
{
  u16 uVersionLength;
  u16 uHeader;
  u8 uVersion[12];
  u32 uFWID;
  u32 uChecksum;
} __PACKED_F InfoPage_TypeDef;


/* Global variables ----------------------------------------------------------------------------------------*/
vu32 isTxFinish = FALSE;
Buffer_TypeDef gTx;
Buffer_TypeDef gRx;

vs32 gIAPCmdTimeout;
vs32 gIAPFlowTimeout = -1;
vs32 gIAPBusbusyTimeout = -1;

/* Private variables ---------------------------------------------------------------------------------------*/
__ALIGN4 static u8 guTxBuffer[TX_BUFFER_SIZE + 1];
__ALIGN4 static u8 guRxBuffer[RX_BUFFER_SIZE + 1];

static const IAP_CODE_Enum guCommandSet[IAP_CMD_COUNT] =
{
  IAP_CMD_START_IAP,
  IAP_CMD_START_APP,
  IAP_CMD_ERASE,
  IAP_CMD_FLASH,
  IAP_CMD_CRC,
  IAP_CMD_GETINFO,
};

static const pFunction pFComHandlerTable[IAP_CMD_COUNT] =
{
  (pFunction)_IAP_CMDStartIAP,
  (pFunction)_IAP_CMDStartAP,
  (pFunction)_IAP_CMDErase,
  (pFunction)_IAP_CMDFlash,
  (pFunction)_IAP_CMDCRC,
  (pFunction)_IAP_CMDGetInfo
};

static const IAP_DataHandler_Type pFDataHandlerTable[]=
{
  {IAP_CMD_FLASH, (pFunction)_IAP_DataFlash},
  {IAP_CMD_CRC,   (pFunction)_IAP_DataCRC  }
};

__ALIGN4 IAPInfo iapInfo;
static u32 guFirstProgramData[IAP_FIRST_PROGRAM_SIZE/4];
static bool guIsFirstProgramCmd = FALSE;

#if (IAP_TIMEOUT_EN == 1)
s32 gIAPTimeout;
#endif
#if (IAP_DOUBLE_RESET_EN == 1)
s32 gDoubleTimeout;
#endif

/* Private macro -------------------------------------------------------------------------------------------*/
#if 0
  #define SET_CACHE_RESET_FLAG()
  #define CACHE_RESET()
#else
  bool gisNeedResetCache;

  #define SET_CACHE_RESET_FLAG() { \
    gisNeedResetCache = TRUE; \
  }

  #define CACHE_RESET() { \
    if(gisNeedResetCache == TRUE) \
    { \
      FLASH_CacheCmd(DISABLE); /* cache disable */ \
      FLASH_CacheCmd(ENABLE);  /* cache enable */ \
    } \
    gisNeedResetCache = FALSE; \
  }
#endif

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  IAP mode initialization.
  * @retval None
  ***********************************************************************************************************/
void IAP_Init(void)
{
  u16* pCRC = (u16*)&gu32Infotable[2];
  u16 uCRCResult;
  gu32Infotable[0] = LOADER_INFO0;
  gu32Infotable[1] = LOADER_INFO1;
  gu32Infotable[2] = LOADER_INFO2;
  gu32Infotable[3] = LOADER_INFO3;
  gu32Infotable[4] = LOADER_INFO4;
  uCRCResult = CRC16(0, (u8*)&gu32Infotable, sizeof(gu32Infotable));
  *pCRC = uCRCResult;
  Buffer_Init(&gTx, guTxBuffer, sizeof(guTxBuffer));
  Buffer_Init(&gRx, guRxBuffer, sizeof(guRxBuffer));

  FLASH_IntConfig(FLASH_INT_ALL, ENABLE);
  iapInfo.currentStep = IAP_STEP_IDLE;
  iapInfo.commandId = 0;
  iapInfo.bufferPos = 0;
  iapInfo.pTimeout = &gIAPCmdTimeout;
  iapInfo.txEmpty = TRUE;
  iapInfo.timeoutFlag = FALSE;
  iapInfo.lastResult = IAP_RET_OK;

  /* Reset BOOT_MODE which set by user's application, to avoid start IAP again                              */
  BOOT_MODE = 0x00000000;
}

/*********************************************************************************************************//**
  * @brief  IAP mode handler.
  * @retval None
  ***********************************************************************************************************/
void IAP_Handler(void)
{
  if(gIAPFlowTimeout == 0)
  {
    _IAP_TimeoutHandler(TRUE, TRUE, TRUE);
    iapInfo.currentStep = IAP_STEP_IDLE;
    gIAPFlowTimeout = IAP_TIMEOUT_OFF;
  }
  switch (iapInfo.currentStep)
  {
    case IAP_STEP_WAIT_END:
    {
      gIAPCmdTimeout = IAP_TIMEOUT_OFF;
      /* Wait for the final transmission to complete */
      if (_IAP_WaitTxBuffer(FALSE))
      {
        iapInfo.currentStep = IAP_STEP_IDLE;
        iapInfo.txEmpty = TRUE;
      }
      else
      {
        iapInfo.txEmpty = FALSE;
      }
    }
    case IAP_STEP_IDLE:
    {
      gIAPFlowTimeout = IAP_CMD_TIMEOUT_RETURN_IDLE_TIMEROUT;
      /* Check if any data arrived in RX buffer */
      if (Buffer_GetLength(&gRx) > 0)
      {
          /* If previous TX data still pending, clear it */
          if (!Buffer_isEmpty(&gTx))
          {
            Buffer_Discard(&gTx);
            iapInfo.txEmpty = TRUE;
          }
          iapInfo.bufferPos      = 0;
          gIAPCmdTimeout         = IAP_CMD_TIMEOUT_BUFFER_RELOAD_CMD;
          iapInfo.currentStep    = IAP_STEP_GET_CMD;
      }
      if((HTCFG_IAPI2C_PORT->IER & I2C_INT_TXDE) == 0)
      {
        gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESULT;
        _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
        iapInfo.currentStep = IAP_STEP_WAIT_END;
      }
      if(GPIO_ReadInBit(HTCFG_IAPI2C_SDA_GPIO_PORT,HTCFG_IAPI2C_SDA_GPIO_PIN) == SET && GPIO_ReadInBit(HTCFG_IAPI2C_SCL_GPIO_PORT,HTCFG_IAPI2C_SCL_GPIO_PIN) == SET)
      {
        gIAPBusbusyTimeout = IAP_CMD_TIMEOUT_IDLE_BUSBUSY_TIMEROUT;
      }
      if(gIAPBusbusyTimeout == 0)
      {
        _IAP_TimeoutHandler(TRUE, TRUE, TRUE);
      }
      break;
    }
    case IAP_STEP_GET_CMD:
    {
      /* Parse next command index from buffer */
      iapInfo.lastResult = _IAP_GetCommand(&iapInfo.commandId);
      if (iapInfo.lastResult == IAP_RET_OK)
      {
        iapInfo.currentStep = IAP_STEP_EXEC_CMD;
      }
      else if (iapInfo.lastResult == IAP_RET_CMDERROR)
      {
        iapInfo.currentStep = IAP_STEP_WAIT_END;
      }
      break;
    }
    case IAP_STEP_EXEC_CMD:
    {
      /* Call the function handler for this command */
      iapInfo.lastResult = (*pFComHandlerTable[iapInfo.commandId])();
      /* Decide next state based on readiness */
      if (iapInfo.lastResult == IAP_STATE_DATA_CONTINUE)
      {
        iapInfo.currentStep = IAP_STEP_WAIT_RET;
      }
      else if(iapInfo.lastResult == IAP_STATE_RESET)
      {
        iapInfo.currentStep = IAP_STEP_RESET;
      }
      else
      {
        iapInfo.currentStep = IAP_STEP_WAIT_END;
      }
      break;
    }
    case IAP_STEP_WAIT_RET:
    {
      /* Wait until TX buffer unlocks or timeout */
      if (_IAP_WaitTxBuffer(FALSE))
      {
        iapInfo.currentStep = IAP_STEP_GET_DATA;
      }
      else if (gIAPCmdTimeout == IAP_TIMEOUT_OFF)
      {
        iapInfo.currentStep = IAP_STEP_IDLE;
      }
      break;
    }
    case IAP_STEP_GET_DATA:
    {
      int i;
      iapInfo.lastResult = IAP_RET_OK;
      for(i=0;i<ARRAY_SIZE(pFDataHandlerTable);i++)
      {
        if(pFDataHandlerTable[i].cmd == iapInfo.cmd)
        {
          iapInfo.lastResult = pFDataHandlerTable[i].pFun();
          break;
        }
      }

      if (iapInfo.lastResult == IAP_STATE_BUFF_NOT_READY)
      {
        iapInfo.currentStep = IAP_STEP_GET_DATA;
      }
      else if (iapInfo.lastResult == IAP_STATE_DATA_CONTINUE)
      {
        iapInfo.currentStep = IAP_STEP_WAIT_RET;
      }
      else
      {
        iapInfo.currentStep = IAP_STEP_WAIT_END;
      }
      break;
    }
    case IAP_STEP_RESET:
    {
      if (_IAP_WaitTxBuffer(FALSE))
      {
        if(iapInfo.cmd == IAP_CMD_START_IAP)
        {
          IAP_Reset(BOOT_MODE_IAP);
          while(1);
        }
        else if(iapInfo.cmd == IAP_CMD_START_APP)
        {
          IAP_Reset(BOOT_MODE_AP);
          while(1);
        }
        else
        {
          iapInfo.currentStep = IAP_STEP_IDLE;
        }
      }
    }
  }
}


/*********************************************************************************************************//**
  * @brief  Check version is valid or not.
  * @retval FALSE or TRUE
  ***********************************************************************************************************/
u32 IAP_isVersionValid(void)
{
  unsigned int i, *pVer;
  InfoPage_TypeDef *pInfoPage = (InfoPage_TypeDef *)(IAP_VERFLASH_START);
  if (pInfoPage->uHeader == 0xFFFF)
  {
    return FALSE;
  }

  if (pInfoPage->uVersionLength > 12)
  {
    return FALSE;
  }
  for (i = 0; i < pInfoPage->uVersionLength; i += 4)
  {
    pVer = (unsigned int*)(&pInfoPage->uVersion[i]);
    if (*pVer == 0xFFFFFFFF)
    {
      __DBG_IAPPrintf("Version Err[%08X]\n\r", *pVer);
      return FALSE;
    }
  }

  return TRUE;
}

/*********************************************************************************************************//**
  * @brief  Check if the checksum is valid or not.
  * @retval FALSE or TRUE
  ***********************************************************************************************************/
u32 IAP_isChecksumValid(void)
{
  u32 *ptr = (u32 *)IAP_VERFLASH_START;
  InfoPage_TypeDef *pInfoPage = (InfoPage_TypeDef *)(IAP_VERFLASH_START);
  u32 uChecksum = 0;
  u32 i;

  for (i = 0; i < 5; i++)
  {
    uChecksum += *(ptr + i);
  }

  return (uChecksum == pInfoPage->uChecksum) ? TRUE : FALSE;
}

/*********************************************************************************************************//**
  * @brief  Reset Command.
  * @param  uMode: Mode after reset
  *         @arg BOOT_MODE_APP: Reset and start Application
  *         @arg BOOT_MODE_IAP: Reset and start IAP
  * @retval FALSE or TRUE
  ***********************************************************************************************************/
u32 IAP_Reset(u32 uMode)
{
  if (uMode == BOOT_MODE_AP)
  {
    if ((IAP_isAPValid() == FALSE) || (IAP_isVersionValid() == FALSE) || IAP_isChecksumValid() == FALSE)
    {
      /* AP image is invalid. Jump to AP is not allow                                                       */
      __DBG_IAPPrintf("AP incorrect\n\r");
      return FALSE;
    }
  }

  BOOT_MODE = uMode;
  NVIC_SystemReset();

  return TRUE;
}

/*********************************************************************************************************//**
  * @brief  Check AP is valid or not.
  * @retval FALSE or TRUE
  ***********************************************************************************************************/
u32 IAP_isAPValid(void)
{
  unsigned int SP, PC;

  /* Check Stack Point in range                                                                             */
  SP = rw(IAP_APFLASH_START);
  if (SP < IAP_APSRAM_START || SP > IAP_APSRAM_END)
  {
    __DBG_IAPPrintf("AP SP Err[%08X]\n\r", SP);
    return FALSE;
  }

  /* Check PC in range                                                                                      */
  PC = rw(IAP_APFLASH_START + 0x4);
  if (PC < IAP_APFLASH_START || PC > IAP_APFLASH_END)
  {
    __DBG_IAPPrintf("AP PC Err[%08X]\n\r", PC);
    return FALSE;
  }

  #if IAP_CRC_CHECK_EN
  {
    unsigned int uCRC;
    signed int sLength;
    unsigned int uCRCResult;
    /* !!! NOTICE !!!
       "uPadding" value : Please confirm the empty vector value of startup.s file.
    */
    u32 uPadding = 0xFFFFFFFF;
    uCRC = rw(IAP_APFLASH_START + IAP_CRC_ADDR);
    sLength = rw(IAP_APFLASH_START + IAP_APEND_ADDR);
    #if (IAP_CRC_SAVETYPE == 1) // 1 for Save End Addrss, 0 for Save Length
    sLength = sLength + 1 - IAP_APFLASH_START;
    #endif
    if (sLength < 0)
    {
      return FALSE;
    }
    if ((uCRC & 0xFFFF0000) == IAP_CRC_KEY)
    {
      #if 1
      {
        CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
        CKCUClock.Bit.CRC        = 1;
        CKCU_PeripClockConfig(CKCUClock, ENABLE);
      }
      uCRCResult = CRC_CCITT(0, (u8 *)IAP_APFLASH_START, 40);
      uCRCResult = CRC_CCITT(uCRCResult, (u8 *)&uPadding, 4);
      uCRCResult = CRC_CCITT(uCRCResult, (u8 *)IAP_APFLASH_START + 44, 8);
      uCRCResult = CRC_CCITT(uCRCResult, (u8 *)&uPadding, 4);
      uCRCResult = CRC_CCITT(uCRCResult, (u8 *)IAP_APFLASH_START + 56, sLength - 56);
      #else
      /* Bit 31 ~ 16 match the IAP_CRC_KEY, inform IAP loader to check AP CRC value before start application*/
      uCRCResult = CRC16(0, (u8 *)IAP_APFLASH_START, 40);
      uCRCResult = CRC16(uCRCResult, (u8 *)&uPadding, 4);
      uCRCResult = CRC16(uCRCResult, (u8 *)IAP_APFLASH_START + 44, 8);
      uCRCResult = CRC16(uCRCResult, (u8 *)&uPadding, 4);
      uCRCResult = CRC16(uCRCResult, (u8 *)IAP_APFLASH_START + 56, sLength - 56);
      #endif
      if ((uCRC & 0x0000FFFF) != uCRCResult)
      {
        __DBG_IAPPrintf("AP CRC Err[%08X][%08X][%d]\n\r", uCRC, uCRCResult, sLength);
        return FALSE;
      }
    }
  }
  #endif
  return TRUE;
}

/*********************************************************************************************************//**
  * @brief  After checking that the AP is valid, jump to the user AP.
  * @param  address: Start address of user application
  * @retval None
  ***********************************************************************************************************/
void IAP_JumpToAP(u32 address)
{
  if ((IAP_isAPValid() == TRUE) && (IAP_isVersionValid() == TRUE) && (IAP_isChecksumValid() == TRUE))
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* Start user application when                                                                          */
    /*   1. SP and PC of user's application is in range and                                                 */
    /*   2. This version is valid                                                                           */
    /*------------------------------------------------------------------------------------------------------*/
    IAP_GoCMD(address);
  }
}

#if defined (__CC_ARM)
/*********************************************************************************************************//**
  * @brief  Jump to user application by change PC.
  * @param  address: Start address of user application
  * @retval None
  ***********************************************************************************************************/
__asm void IAP_GoCMD(u32 address)
{
  LDR R1, [R0]
  MOV SP, R1
  LDR R1, [R0, #4]
  BX R1
}
#elif defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050) || (__GNUC__)
__attribute__((noinline)) void IAP_GoCMD(u32 address)
{
  __ASM volatile ("LDR R1, [%0]" : : "r" (address) : );
  __ASM volatile ("MOV SP, R1");
  __ASM volatile ("LDR R1, [%0, #4]" : : "r" (address) : );
  __ASM volatile ("BX R1");
}
#elif defined (__ICCARM__)
void IAP_GoCMD(u32 address)
{
  __asm("LDR R1, [R0]");
  __asm("MOV SP, R1");
  __asm("LDR R1, [R0, #4]");
  __asm("BX R1");
}
#endif

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Get Command.
  * @param  cmdIndex: Command index
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_GetCommand(s32 *cmdIndex)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  u32 uRxindex;
  s32 i;
  *cmdIndex = -1;
  uRxindex = Buffer_GetLength(&gRx);
  if((uRxindex + iapInfo.bufferPos) >= sizeof(iapInfo.buffer))
  {
    /* Buffer Size out of range */
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    Buffer_Discard(&gRx);
    return IAP_RET_CMDERROR;
  }
  if (uRxindex > 0)
  {
    Buffer_Read(&gRx, &iapInfo.buffer[iapInfo.bufferPos], uRxindex);
    iapInfo.bufferPos += uRxindex;
  }
  if(iapInfo.bufferPos >= IAP_CODE_LENGTH)
  {
    int paraLength = 1;
    /* Check complement of Code is valid                                                                    */
    if (pCMD->Code + pCMD->Check != IAP_CMDVALID)
    {
      _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
      return IAP_RET_CMDERROR;
    }
    /* Find out command index                                                                               */
    for (i = IAP_CMD_COUNT - 1; i >= 0; i--)
    {
      if (pCMD->Code == guCommandSet[i])
      {
        *cmdIndex = i;
      }
    }
    if(IAP_CMD_ERROR == *cmdIndex)
    {
      _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
      return IAP_RET_CMDERROR;
    }
    iapInfo.cmd = pCMD->Code;
    if((pCMD->Code == IAP_CMD_START_IAP) || (pCMD->Code == IAP_CMD_START_APP) || (pCMD->Code == IAP_CMD_GETINFO))
    {
      return IAP_RET_OK;
    }

    if(iapInfo.bufferPos >= (IAP_CODE_LENGTH+1))
    {
      paraLength = iapInfo.buffer[IAP_CODE_LENGTH];
    }

    if(iapInfo.bufferPos >= (IAP_CODE_LENGTH + paraLength))
    {
      /* Check the CRC value of Parameter.                                                                  */
      u16 uCRCValue = pCMD->uCRC;
      u16 uCRCResult;
      pCMD->uCRC = 0;         /* Reset CRC field of Parameter for calculate CRC value                       */
      uCRCResult = CRC16(0, &iapInfo.buffer[IAP_CODE_LENGTH], pCMD->uLength);
      if (uCRCResult == uCRCValue)
      {
        return IAP_RET_OK;
      }
      else
      {
        #if (IAP_DEBUG_MODE == 1)
        __DBG_IAPPrintf("P:");
        _IAP_DumpData(IAP_CODE_LENGTH, pCMD->uLength);
        __DBG_IAPPrintf("CRC Failed[%04X]\n\r", uCRCResult);
        #endif
        _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
        return IAP_RET_CMDERROR;
      }
    }
  }

  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    _IAP_TimeoutHandler(FALSE, TRUE, FALSE);
    return IAP_RET_CMDERROR;
  }

  return IAP_STATE_DATA_CONTINUE;
}

/*********************************************************************************************************//**
  * @brief  _IAP_WaitTxBuffer
  * @param  isBlocking: Blocking or Not
  * @retval TRUE: Tx Buffer empty; FAIL: Tx Buffer not empty or timeout
  ***********************************************************************************************************/
static bool _IAP_WaitTxBuffer(bool isBlocking)
{
  if(gIAPCmdTimeout == IAP_TIMEOUT_OFF)
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESULT;

  while (!Buffer_isEmpty(&gTx) || isTxFinish == FALSE)
  {
    if (gIAPCmdTimeout == 0)
    {
      _IAP_TimeoutHandler(TRUE, FALSE, TRUE);
      gIAPCmdTimeout = IAP_TIMEOUT_OFF;
      return FALSE;
    }
    if (!isBlocking)
    {
      return FALSE;
    }
    WDT_RST();
  }
  gIAPCmdTimeout = IAP_TIMEOUT_OFF;
  return TRUE;
}

/*********************************************************************************************************//**
  * @brief  Send RETURN to Host.
  * @param  Result: IAP Result code
  *         @arg IAP_RET_OK:        Command operation Okey
  *         @arg IAP_RET_FAIL:      Command operation failed
  *         @arg IAP_RET_CMDERROR:  Command or Parameter error (not support, Check, or uCRC error)
  * @param  buffer
  * @param  len
  * @retval None
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_SendResult(IAP_CODE_Enum Result, u8* buffer, u32 len)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  u32 RingBufferSize;
  pCMD->Code = Result;
  pCMD->Check = (IAP_CODE_Enum)~Result;

  isTxFinish = FALSE;
  RingBufferSize = Buffer_GetLength(&gTx);
  if(!Buffer_isEmpty(&gTx))
  {
    I2C_AckCmd(HTCFG_IAPI2C_PORT, ENABLE);
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESULT;
    while(!Buffer_isEmpty(&gTx))
    {
      RingBufferSize = Buffer_GetLength(&gTx);
      if((gTx.uSize - RingBufferSize) < IAP_CODE_LENGTH)
      {
        break;
      }
      if(gIAPCmdTimeout == 0)
      {
        _IAP_TimeoutHandler(FALSE, FALSE, TRUE);
        return IAP_RET_FAIL;
      }
    }
  }
  Buffer_Write(&gTx, iapInfo.buffer, IAP_CODE_LENGTH);

  if(buffer != NULL)
  {
    RingBufferSize = Buffer_GetLength(&gTx);
    if((gTx.uSize - RingBufferSize) < len)
    {
      I2C_AckCmd(HTCFG_IAPI2C_PORT, ENABLE);
      gIAPCmdTimeout = IAP_CMD_TIMEOUT_RX_DATA;
      while(!Buffer_isEmpty(&gTx))
      {
        RingBufferSize = Buffer_GetLength(&gTx);
        if((gTx.uSize - RingBufferSize) < len)
        {
          break;
        }
        if(gIAPCmdTimeout == 0)
        {
          _IAP_TimeoutHandler(FALSE, FALSE, TRUE);
          return IAP_RET_FAIL;
        }
      }
    }
    gIAPCmdTimeout += IAP_CMD_TIMEOUT_RX_DATA;
    Buffer_Write(&gTx, buffer, len);
  }
  gIAPCmdTimeout = IAP_TIMEOUT_OFF;
  I2C_AckCmd(HTCFG_IAPI2C_PORT, ENABLE);
  I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_TXDE, ENABLE);
  return IAP_RET_OK;
}

#if (IAP_DEBUG_MODE == 1)
/*********************************************************************************************************//**
  * @brief  Dump data for debug mode.
  * @param  uLength: Data length
  * @retval None
  ***********************************************************************************************************/
static void _IAP_DumpData(u32 uSatrt, u32 uLength)
{
 u32 i;
  for (i = 0; i < uLength; i++)
  {
    __DBG_IAPPrintf("%02X ", iapInfo.buffer[uSatrt + i]);
  }
  __DBG_IAPPrintf("\n\r");
}
#endif

/*********************************************************************************************************//**
  * @brief  Start IAP Command.
  * @retval IAP_RET_OK
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDStartIAP(void)
{
  __DBG_IAPPrintf("F:SIAP\n\r");

  _IAP_SendResult(IAP_RET_OK, NULL, 0);

  return IAP_STATE_RESET;
}

/*********************************************************************************************************//**
  * @brief  Start AP Command.
  * @retval IAP_RET_FAIL or IAP_RET_OK
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDStartAP(void)
{
  __DBG_IAPPrintf("F:SAP\n\r");

  /* Set slave busy.
     I2C well send a NACK signal after a byte is received.
     It prevent the I2C bus halt by I2C slave.                                                            */
  I2C_AckCmd(HTCFG_IAPI2C_PORT, DISABLE);

  if ((IAP_isAPValid() == FALSE) || (IAP_isVersionValid() == FALSE) || IAP_isChecksumValid() == FALSE)
  {
    /* AP image is invalid. Jump to AP is not allow                                                         */
    __DBG_IAPPrintf("AP incorrect\n\r");

    _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
    return IAP_RET_FAIL;
  }
  else
  {
    /* Send RETURN code to Host here since IAP_Reset function will not return back to IAP Handler           */
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
  }
  return IAP_STATE_RESET;
}

/*********************************************************************************************************//**
  * @brief  Erase command.
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDErase(void)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  unsigned int i;

  if (pCMD->uStAddr < IAP_APFLASH_START)
  {
    __DBG_IAPPrintf("F:uStAddr Err[%08X]\n\r", pCMD->uStAddr);
    Buffer_Discard(&gRx);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }

  /* Set I2C slave busy.
     I2C well send a NACK signal after a byte is received.
     It prevent the I2C bus halt by I2C slave.                                                               */
  I2C_AckCmd(HTCFG_IAPI2C_PORT, DISABLE);

  #if 0
  __DBG_IAPPrintf("F:Erase\n\r");
  __DBG_IAPPrintf("uLength  [0x%X]\n\r", pCMD->uLength);
  __DBG_IAPPrintf("uPara    [0x%X]\n\r", pCMD->uPara);
  __DBG_IAPPrintf("uCRC     [0x%X]\n\r", pCMD->uCRC);
  __DBG_IAPPrintf("uStAddr  [0x%X]\n\r", pCMD->uStAddr);
  __DBG_IAPPrintf("uEndAddr [0x%X]\n\r", pCMD->uEndAddr);
  #endif

  /* Erase Page according to the parameter uStAddr and uEndAddr                                             */
  for (i = pCMD->uStAddr; i <= pCMD->uEndAddr; i += FLASH_PAGE_SIZE)
  {
    __DBG_IAPPrintf("Erase %08X...", i);
    if (FLASH_ErasePage(i) != FLASH_COMPLETE)
    {
      __DBG_IAPPrintf("Fail\n\r");
      _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
      return IAP_RET_FAIL;
    }
    WDT_RST();
    __DBG_IAPPrintf("OK\n\r");
  }

  guIsFirstProgramCmd = FALSE;
  _IAP_SendResult(IAP_RET_OK, NULL, 0);
  SET_CACHE_RESET_FLAG();
  return IAP_RET_OK;
}

/*********************************************************************************************************//**
  * @brief  Flash command (Program or Verify).
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDFlash(void)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();

  if (pCMD->uStAddr < IAP_APFLASH_START)
  {
    __DBG_IAPPrintf("F:uStAddr Err[%08X]\n\r", pCMD->uStAddr);
      Buffer_Discard(&gRx);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }

  __DBG_IAPPrintf("F:Flash\n\r");
  #if 0
  __DBG_IAPPrintf("uLength  [0x%X]\n\r", pCMD->uLength);
  __DBG_IAPPrintf("uPara    [0x%X]\n\r", pCMD->uPara);
  __DBG_IAPPrintf("uCRC     [0x%X]\n\r", pCMD->uCRC);
  __DBG_IAPPrintf("uStAddr  [0x%X]\n\r", pCMD->uStAddr);
  __DBG_IAPPrintf("uEndAddr [0x%X]\n\r", pCMD->uEndAddr);
  #endif

  if(pCMD->uPara == IAP_PARA_READ)
  {
    u32 data[5], i=0;

    CACHE_RESET();
    while (pCMD->uStAddr <= pCMD->uEndAddr)
    {
      __DBG_IAPPrintf("F:Read[%08X]...\r\n", pCMD->uStAddr);
      if (pCMD->uStAddr == (IAP_VERFLASH_START      + 0x00)) /* ---, 04, 0x010, INFO_0                      */
      {
        data[i] = rw(IAP_VERFLASH_START + 0);
      }
      else if (pCMD->uStAddr == (IAP_VERFLASH_START + 0x04)) /* ---, 04, 0x010, INFO_1                      */
      {
        data[i] = rw(IAP_VERFLASH_START + 4);
      }
      else if (pCMD->uStAddr == (IAP_VERFLASH_START + 0x08)) /* ---, 04, 0x010, INFO_2                      */
      {
        data[i] = rw(IAP_VERFLASH_START + 8);
      }
      else if (pCMD->uStAddr == (IAP_VERFLASH_START + 0x0C)) /* ---, 04, 0x010, INFO_3                      */
      {
        data[i] = rw(IAP_VERFLASH_START + 0xC);
      }
      else if (pCMD->uStAddr == (IAP_VERFLASH_START + 0x10)) /* ---, 04, 0x010, _HT32FWID                   */
      {
        data[i] = rw(IAP_VERFLASH_START + 0x10);
      }
      else if (pCMD->uStAddr == (IAP_VERFLASH_START + 0x14)) /* ---, 04, 0x010, INFO_CK                     */
      {
        data[i] = rw(IAP_VERFLASH_START + 0x14);
      }
      else
      {
        data[i] = 0;
      }
      i++;
      if (i  == (IAP_TX_DATA_PACKET_SIZE/4))
      {
        if(_IAP_SendResult(IAP_RET_OK, (u8*)data, IAP_TX_DATA_PACKET_SIZE) != IAP_RET_OK)
        {
          return IAP_RET_FAIL;
        }
        __DBG_IAPPrintf("Done\n\r");
        i = 0;
      }
      pCMD->uStAddr += 4;
    }
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
  }
  else /* Program or Verify */
  {
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
    return IAP_STATE_DATA_CONTINUE;
  }
  return IAP_RET_OK;
}

/*********************************************************************************************************//**
  * @brief  CRC command.
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDCRC(void)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  if (pCMD->uStAddr < IAP_APFLASH_START)
  {
    __DBG_IAPPrintf("F:uStAddr Err[%08X]\n\r", pCMD->uStAddr);
      Buffer_Discard(&gRx);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }
  _IAP_SendResult(IAP_RET_OK, NULL, 0);

  __DBG_IAPPrintf("F:CRC\n\r");
  #if 0
  __DBG_IAPPrintf("uLength  [0x%X]\n\r", pCMD->uLength);
  __DBG_IAPPrintf("uPara    [0x%X]\n\r", pCMD->uPara);
  __DBG_IAPPrintf("uCRC     [0x%X]\n\r", pCMD->uCRC);
  __DBG_IAPPrintf("uStAddr  [0x%X]\n\r", pCMD->uStAddr);
  __DBG_IAPPrintf("uEndAddr [0x%X]\n\r", pCMD->uEndAddr);
  #endif

  return IAP_STATE_DATA_CONTINUE;
}

/*********************************************************************************************************//**
  * @brief  Get Info RC command.
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_CMDGetInfo(void)
{
  __DBG_IAPPrintf("F:GetInfo\n\r");
  _IAP_SendResult(IAP_RET_OK, (u8*)gu32Infotable, IAP_TX_DATA_PACKET_SIZE);
  _IAP_SendResult(IAP_RET_OK, NULL, 0);
  __DBG_IAPPrintf("Done\n\r");
  return IAP_RET_OK;
}

/*********************************************************************************************************//**
  * @brief  Handle data retrieval for Flash commands (Program or Verify).
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_DataFlash(void)
{
    IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  __ALIGN4 u8 uDataBuffer[IAP_RX_DATA_PACKET_SIZE + 2];
  u32 uRxindex;
  u32 i;
  u16 uCRCResult;
  /*--------------------------------------------------------------------------------------------------------*/
  /* Program or Verify                                                                                      */
  /*--------------------------------------------------------------------------------------------------------*/
  /* Finish           */
  if (pCMD->uStAddr > pCMD->uEndAddr)
  {
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
    return IAP_RET_OK;
  }

  /* Check Timeout */
  if (gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    _IAP_TimeoutHandler(FALSE, TRUE, FALSE);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }

  uRxindex = Buffer_GetLength(&gRx);
  if(uRxindex<(IAP_RX_DATA_PACKET_SIZE + 2))
  {
    return IAP_STATE_BUFF_NOT_READY;
  }

  gIAPCmdTimeout      = IAP_CMD_TIMEOUT_TX_DATA;
  gIAPFlowTimeout = IAP_CMD_TIMEOUT_RETURN_IDLE_TIMEROUT;
  I2C_AckCmd(HTCFG_IAPI2C_PORT, DISABLE);
  Buffer_Read(&gRx, uDataBuffer,IAP_RX_DATA_PACKET_SIZE+2);

  /* Check CRC Value                                                                                      */
  uCRCResult = CRC16(0, uDataBuffer, IAP_RX_DATA_PACKET_SIZE);
  if (uCRCResult != *(u16 *)&uDataBuffer[IAP_RX_DATA_PACKET_SIZE])
  {
    Buffer_Discard(&gRx);
    __DBG_IAPPrintf("F:CRC Err[%04X][%04X]\n\r", *(u16 *)&uDataBuffer[IAP_RX_DATA_PACKET_SIZE], uCRCResult);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }

  if (pCMD->uPara == IAP_PARA_PROGRAM)
  {
    /* Program 128 Bytes Data into Flash                                                                  */
    __DBG_IAPPrintf("F:Program[%08X]...", pCMD->uStAddr);
    for (i = 0; i < IAP_RX_DATA_PACKET_SIZE; i += 4)
    {
      if (pCMD->uStAddr <= pCMD->uEndAddr)
      {
        if(pCMD->uStAddr < (IAP_APFLASH_START + IAP_FIRST_PROGRAM_SIZE))
        {
          guFirstProgramData[(pCMD->uStAddr - IAP_APFLASH_START)>>2] = *(u32 *)(uDataBuffer + i);
          guIsFirstProgramCmd = TRUE;
        }
        else
        {
          if(*(u32 *)(uDataBuffer + i) != 0xFFFFFFFF)
          {
            if (FLASH_ProgramWordData(pCMD->uStAddr, *(u32 *)(uDataBuffer + i)) != FLASH_COMPLETE)
            {
              /* Set slave free                                                                             */
              _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
              guIsFirstProgramCmd = FALSE;
              return IAP_RET_FAIL;
            }
          }
        }
      }
      pCMD->uStAddr += 4;
    }
    SET_CACHE_RESET_FLAG();
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
    __DBG_IAPPrintf("Done\n\r");
  }
  else
  {
    /* Verify 128 Bytes Data                                                                              */
    __DBG_IAPPrintf("F:Verify[%08X]...", pCMD->uStAddr);
    CACHE_RESET();
    for (i = 0; i < IAP_RX_DATA_PACKET_SIZE; i += 4)
    {
      if(pCMD->uStAddr < (IAP_APFLASH_START + IAP_FIRST_PROGRAM_SIZE))
      {
        if (*(u32 *)(uDataBuffer + i) != guFirstProgramData[(pCMD->uStAddr-IAP_APFLASH_START)>>2])
        {
          /* Set slave fress                                                                                */
          _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
          __DBG_IAPPrintf("\n\rF:Err A[%08X]E[%08X]R[%08X]\n\r", pCMD->uStAddr, *(unsigned int *)(uDataBuffer + i), (unsigned int)rw(pCMD->uStAddr));
          guIsFirstProgramCmd = FALSE;
          return IAP_RET_FAIL;
        }
      }
      else
      {
        if (*(u32 *)(uDataBuffer + i) != rw(pCMD->uStAddr))
        {
          /* Set slave fress                                                                                */
          _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
          __DBG_IAPPrintf("\n\rF:Err A[%08X]E[%08X]R[%08X]\n\r", pCMD->uStAddr, *(unsigned int *)(uDataBuffer + i), (unsigned int)rw(pCMD->uStAddr));
          guIsFirstProgramCmd = FALSE;
          return IAP_RET_FAIL;
        }
      }
      pCMD->uStAddr += 4;
      if (pCMD->uStAddr > pCMD->uEndAddr)
      {
        break;
      }
    }
    _IAP_SendResult(IAP_RET_OK, NULL, 0);
    __DBG_IAPPrintf("Done\n\r");
  }
  return IAP_STATE_DATA_CONTINUE;
}

/*********************************************************************************************************//**
  * @brief  Handle data retrieval for CRC commands.
  * @retval IAP_RET_OK, IAP_RET_FAIL, IAP_RET_CMDERROR or IAP_STATE_DATA_CONTINUE
  ***********************************************************************************************************/
static IAP_CODE_Enum _IAP_DataCRC(void)
{
  IAP_Protocol_TypeDef *pCMD = _GET_BUFFER_ADDR();
  __ALIGN4 u8 uDataBuffer[2];
  u8* pu8FisrtProgramData = (u8*)guFirstProgramData;
  u8 *puSource;
  u16 uCRCResult;
  u32 length;
  u32 uRxindex;
  u32 uFisrtProgramSize;
  u32 uOffset;

  /* Check Timeout */
  if(gIAPCmdTimeout == 0)
  {
    /* Timeout, Rest Rxbuffer                                                                               */
    _IAP_TimeoutHandler(FALSE, TRUE, FALSE);
    _IAP_SendResult(IAP_RET_CMDERROR, NULL, 0);
    return IAP_RET_CMDERROR;
  }

  uRxindex = Buffer_GetLength(&gRx);
  if(uRxindex< 2)
  {
    return IAP_STATE_BUFF_NOT_READY;
  }
  gIAPCmdTimeout      = IAP_CMD_TIMEOUT_TX_DATA;
  gIAPFlowTimeout = IAP_CMD_TIMEOUT_RETURN_IDLE_TIMEROUT;

  I2C_AckCmd(HTCFG_IAPI2C_PORT, DISABLE);
  Buffer_Read(&gRx, uDataBuffer,2);

  /* Calculate CRC value according to the parameter uStAddr and uEndAddr                                    */
  pCMD->uStAddr &= ~ 0x03; // 4-byte align
  puSource = (u8 *)pCMD->uStAddr;
  /* length minimum size is IAP_FIRST_PROGRAM_SIZE*/
  length = ((pCMD->uEndAddr - pCMD->uStAddr + 1) > (IAP_FIRST_PROGRAM_SIZE)) ? 
            (pCMD->uEndAddr - pCMD->uStAddr + 1) : 
            IAP_FIRST_PROGRAM_SIZE;

  /* Compute offset from the IAP AP flash start */
  uOffset = pCMD->uStAddr -IAP_APFLASH_START;

  if(uOffset < IAP_FIRST_PROGRAM_SIZE)
  {
    /* CRC over the data stored in RAM (from buffer) */
    uFisrtProgramSize = IAP_FIRST_PROGRAM_SIZE - uOffset;
    uCRCResult = CRC16(0, &pu8FisrtProgramData[uOffset], uFisrtProgramSize); 
  }
  else
  {
    uCRCResult = 0;
    uFisrtProgramSize = 0; // All data will come from Flash
  }

  /* If there's remaining data, calculate CRC from Flash directly */
  if((length - uFisrtProgramSize) > 0)
    uCRCResult = CRC16(uCRCResult,&puSource[uFisrtProgramSize],length - uFisrtProgramSize);

  /* Check Calculated CRC value with received one                                                           */
  if (uCRCResult != *(u16 *)uDataBuffer)
  {
    __DBG_IAPPrintf("F:CRC R[%04X]C[%04X]\n\r", *(u16 *)uDataBuffer, uCRCResult);
    __DBG_IAPPrintf("F:CRC Err\n\r");

    _IAP_SendResult(IAP_RET_FAIL, NULL, 0);
    return IAP_RET_FAIL;
  }
  _IAP_SendResult(IAP_RET_OK, NULL, 0);
  if(guIsFirstProgramCmd)
  {
    int i,j;
    guIsFirstProgramCmd = FALSE;
    for (i = IAP_FIRST_PROGRAM_SIZE - 4, j = (IAP_FIRST_PROGRAM_SIZE / 4) - 1; i >= 0; i -= 4)
    {
      if((IAP_APFLASH_START + i) != 0xFFFFFFFF)
      {
        FLASH_ProgramWordData(IAP_APFLASH_START + i, guFirstProgramData[j--]);
      }
    }
  }
  __DBG_IAPPrintf("Done\n\r");
  return IAP_RET_OK;
}

/*********************************************************************************************************//**
  * @brief  Handles timeout events
  * @param  If TRUE, clears the Tx buffer and marks transmission as finished.
  * @param  If TRUE, clears the Rx buffer.
  * @param  If TRUE, or if the I2C bus is busy, resets the I2C.
  * @retval None
  ***********************************************************************************************************/
void _IAP_TimeoutHandler(bool bResetTx, bool bResetRx, bool bResetIP)
{
  iapInfo.timeoutFlag = TRUE;
  if(bResetTx)
  {
    Buffer_Discard(&gTx);
    isTxFinish = TRUE;
  }
  if(bResetRx)
  {
    Buffer_Discard(&gRx);
  }
  if(bResetIP && (I2C_GetFlagStatus(HTCFG_IAPI2C_PORT, I2C_FLAG_BUSBUSY) == SET))
  {
    I2C_DeInit(HTCFG_IAPI2C_PORT);
    I2C_Configuration();
  }
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
