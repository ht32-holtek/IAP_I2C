/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/iap_config.h
 * @version $Rev:: 587          $
 * @date    $Date:: 2025-06-06 #$
 * @brief   The configuration file of IAP.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_CONFIG_H
#define __IAP_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
/* IAP                                                                                                      */
#define LOADER_VERSION                            (0x100)

/* IAP                                                                                                      */
//    <e0> IAP Command Timeout
//    <i> Entry IAP mode by default, if IAP Loader did not received any valid IAP command after specific timeout time, it starts AP automatically.
//    <o1> IAP Command Timeout Value (ms) <1-5000:1>
#define IAP_TIMEOUT_EN                            (0)
#define IAP_TIMEOUT                               (1000)            /* IAP Command timeout based on ms      */
//    </e>

//    <e0> Start IAP by Double Reset (External nRST)
//    <i> After the processor resets, the IAP mode starts, remaining active for about IAP_DOUBLE_TIMEOUT Time. If press reset again, program will stay in IAP mode.
//    <o1> IAP Command Timeout Value (ms) <1-5000:1>
#define IAP_DOUBLE_RESET_EN                       (0)
#define IAP_DOUBLE_TIMEOUT                        (1000) /* IAP double timeout based on ms                  */
//    </e>

//<o0.0> IAP CRC Checking on Boot
#define IAP_CRC_CHECK_EN                          (0)           /* 0: Disable (Default), 1: Enable          */
#define IAP_CRC_SAVETYPE                          (0)           /* 1: End Address, 0: Length                */
#define IAP_CRC_ADDR                              (0x00000028)  /* Addr for Start AP CRC check (4 Bytes)    */
#define IAP_APEND_ADDR                            (0x00000034)  /* Addr for AP End Address     (4 Bytes)    */
#define IAP_CRC_KEY                               (0x1A0C0000)  /* key for enable Start AP CRC check        */

#ifdef __cplusplus
}
#endif

#endif
