;********************************************************************************
;* @file        target_ap.s
;* @version     $Rev:: 1097         $
;* @date        $Date:: 2015-11-19 #$
;* @brief       Include AP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************

        AREA    TARGET_AP, DATA, READONLY

        INCBIN  ../../IAP_I2C_Device/Tools/AP_CRC.bin

        END
