/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/iap_host.h
 * @version $Rev:: 541          $
 * @date    $Date:: 2025-05-20 #$
 * @brief   The header file of IAP Host - I2c example code.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_HOST_H
#define __IAP_HOST_H

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "iap_protocol.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */

/* Settings ------------------------------------------------------------------------------------------------*/
//<o0.0> Enable IAP Debug mode
// <i> Enable IAP Debug mode which output debug message to retarget COM port or SWV (ITM).
#define IAP_DEBUG_MODE            (0)

#define AP_IMAGE_ADDRESS          (0x4000)

#define ENGINNER_MODE1                 (1)
#define ENGINNER_MODE2                 (0)
#if ENGINNER_MODE2
  #define ENGINNER_MODE2_MODE          (0)     /* 0: Reset Host Test, 1: Change IO AFIO Mode */
#endif
#define ENGINNER_MODE3                 (0)

#define IAP_SKIP_VECTOR               (40)                          /* Skip Vector size since AP_CRC and    */
                                                                    /* AP_LENGTH locate in it               */

/* Exported typedef ----------------------------------------------------------------------------------------*/
typedef enum
{
  IAP_OK = 0,
  IAP_TIMEOUT,
  IAP_FAIL,
  IAP_CMDERROR,
  IAP_RETERROR,
  IAP_RETDUMMY
} IAP_Status;

/* Exported constants --------------------------------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported variables --------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/
IAP_Status IAP_StartIAP(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_StartAP(u32 uI2CSlaveAddress, u32 uTimeout);

IAP_Status IAP_Erase(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_EraseOB(u32 uI2CSlaveAddress, u32 uTimeout);

IAP_Status IAP_FlashProgramAP(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_FlashVerifyAP(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_FlashDummy(u32 uI2CSlaveAddress, u32 uTimeout, IAP_PARA_Enum uType);
IAP_Status IAP_FlashData(u32 uI2CSlaveAddress, u32 uTimeout, IAP_PARA_Enum uType);

IAP_Status IAP_CRCAP(u32 uI2CSlaveAddress, u32 uTimeout, u32 skipByte);
IAP_Status IAP_CRCDummy(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_CRCData(u32 uI2CSlaveAddress, u32 uTimeout);

IAP_Status IAP_SubmitCRCAP(u32 uI2CSlaveAddress, u32 uTimeout);

IAP_Status IAP_SendCommand(u32 uI2CSlaveAddress, IAP_Protocol_TypeDef *pCmd, u32 uTimeout);
IAP_Status IAP_SendData(u32 uI2CSlaveAddress, u8 *puBuffer, u32 uLength, u32 uTimeout);
IAP_Status IAP_GetRET(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_CheckDeviceReady(u32 uI2CSlaveAddress, u32 uTimeout);

IAP_Status IAP_GetInfo(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_GetVersion(u32 uI2CSlaveAddress, u32 uTimeout);
IAP_Status IAP_GetData(u32 uI2CSlaveAddress, u8 *puBuffer, u32 uLength, u32 uTimeout);

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* __IAP_HOST_H -------------------------------------------------------------------------------------*/
