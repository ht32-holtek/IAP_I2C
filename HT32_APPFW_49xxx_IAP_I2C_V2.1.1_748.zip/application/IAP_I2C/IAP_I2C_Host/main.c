/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/main.c
 * @version $Rev:: 727          $
 * @date    $Date:: 2025-06-25 #$
 * @brief   Main program of IAP I2C Host example code.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "iap_host.h"
#include "iap_config.h"
#include "i2c_buffer.h"
#include "i2c_buffer.h"
#include "common\ht32_misc.h"

/* Dependency check ----------------------------------------------------------------------------------------*/
#if defined(__HT32F490x1_H)
#define MIN_HT32_FWLIB_VER              (0x01001002) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x78)
#endif
#if defined(__HT32F491x3_H)
#define MIN_HT32_FWLIB_VER              (0x01000006) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x131)
#endif
#include "ht32_dependency.h" // Not exist means the version of HT32 Firmware Library is older than the module required.

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define TIMER_BASE                    (SystemCoreClock * 1 / 1000)  /* 1 ms                                 */

#define IAP_CMD_TIMEOUT               (500)      /* Command timeout value based on ms                       */
#define IAP_ERASE_TIMEOUT             (1500)     /* Erase timeout value based on ms                         */

/* Private function prototypes -----------------------------------------------------------------------------*/
static void I2C_Configuration(void);

static void ChangeSlaveAddress(void);
static void ShowMenu(void);
static void FunStartIAP(void);
static void FunStartAP(void);

static void FunErase(void);
#if ENABLE_OB_ERASE
static void FunEraseOP(void);
#endif

static void FunProgramAP(void);
static void FunProgramDummy(void);

static void FunVerifyAP(void);
#if !ENGINNER_MODE2
static void FunVerifyDummy(void);
#endif

static void FunCRCAP(void);
#if !ENGINNER_MODE2
static void FunCRCDummy(void);
#endif
static void FunGetInfo(void);
#if ENGINNER_MODE3
static void TestUnexpectedRead(void);
#endif

void UxART_Configuration(void);

/* Private macro -------------------------------------------------------------------------------------------*/
/* Global variables ----------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
static unsigned int SlaveAddressIAP = I2C_SLAVE_ADDRESS_IAP;
static unsigned int SlaveAddressAP  = I2C_SLAVE_ADDRESS_AP;
static u32 uTarget = 0;
static u8 uTargetName[2][12] =
{
 "Application",
 "Dummy",
};

#if ENGINNER_MODE2
volatile u32 *pgTimeoutTestMode         = ((u32 volatile *) (SRAM_BASE+LIBCFG_RAM_SIZE - 4));
volatile s32 *pgTimeoutTestResetTime    = ((s32 volatile *) (SRAM_BASE+LIBCFG_RAM_SIZE - 8));
volatile s32 *pgTimeoutTestErrorCounter = ((s32 volatile *) (SRAM_BASE+LIBCFG_RAM_SIZE - 12));

#define TIMEOUT_RESET_TEST_START       (0x5AA55AA1)
#define TIMEOUT_IAP_TEST_MASK          (0x5AA55AA0)
s32 gTimeroutTestSystemResetCounter  = -1;
s32 gTimeroutTestAFIOChangeI2CMode   = -1;
s32 gTimeroutResetCounter  = -1;
extern vs32 gsI2CBuffer_TimerCount;
#endif

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  system_clock_config();

  SYSTICK_ClockSourceConfig(SYSTICK_SRC_FCLK);
  SYSTICK_SetReloadValue(TIMER_BASE);
  SYSTICK_IntConfig(TRUE);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);

  UxART_Configuration();

  I2C_Configuration();
  #if ENGINNER_MODE2
  {
    u32 testMode = *pgTimeoutTestMode;
    ht32_led_init(LED4);
    ht32_led_off(LED4);
    if((testMode & TIMEOUT_IAP_TEST_MASK) != TIMEOUT_IAP_TEST_MASK)
    {
      *pgTimeoutTestResetTime = 1;
      *pgTimeoutTestErrorCounter = 0;
    }
    else
    {
      gsI2CBuffer_TimerCount = 500;
      while(gsI2CBuffer_TimerCount);
      gsI2CBuffer_TimerCount = -1;
    }
  }

  #endif
  ShowMenu();
  while (1)
  {
    if (usart_flag_get(PRINT_UART, USART_RDBF_FLAG) == SET)
    {
      unsigned int  uInput;
      #if ENGINNER_MODE2
      if((*pgTimeoutTestMode & TIMEOUT_IAP_TEST_MASK) == TIMEOUT_IAP_TEST_MASK)
      {
        uInput = 'j';
      }
      else
      {
        uInput = UART_RetargetRecieve(PRINT_UART);
      }
      #else
      uInput = usart_data_receive(PRINT_UART);
      #endif
      printf("%c\n\r", uInput);
      switch (uInput)
      {
        case '0':
        {
          ChangeSlaveAddress();
          break;
        }
        case '1':
        {
          FunStartIAP();
          FunGetInfo();
          break;
        }
        case '2':
        {
          FunStartAP();
          break;
        }
        case '3':
        {
          FunStartIAP();
          FunGetInfo();
          FunErase();
          FunProgramAP();
          FunVerifyAP();
          FunCRCAP();
          FunStartAP();
          break;
        }
        case '4':
        {
          FunErase();
          break;
        }
        case '5':
        {
        }
        case '6':
        {
          uTarget = (uTarget + 1) % 2;
          break;
        }
        case '7':
        {
          if(uTarget == 0)
          {
            FunProgramAP();
          }
          else if(uTarget == 1)
          {
            FunProgramDummy();
          }
          break;
        }
        #if !ENGINNER_MODE2
        case '8':
        {
          if(uTarget == 0)
          {
            FunVerifyAP();
          }
          else if(uTarget == 1)
          {
            FunVerifyDummy();
          }
          break;
        }
        case '9':
        {
          if(uTarget == 0)
          {
            FunCRCAP();
          }
          else if(uTarget == 1)
          {
            FunCRCDummy();
          }
          break;
        }
        case 'i':
        case 'I':
          FunGetInfo();
          break;
        #endif
        #if ENGINNER_MODE1
        case 'T':
        case 't':
        {
          for (uInput = 0; uInput < 10; uInput++)
          {
            printf("\n\rRound %02d\n\r", uInput);
            printf("=============================================\n\r");
            FunStartIAP();
            FunErase();
            FunProgramAP();
            FunVerifyAP();
            FunCRCAP();
            FunStartAP();
            I2CBuffer_Delay(2000);
          }
          break;
        }
        #endif
        #if ENGINNER_MODE2
        case 'j':
        case 'J':
        {
          if((*pgTimeoutTestMode & TIMEOUT_IAP_TEST_MASK) != TIMEOUT_IAP_TEST_MASK)
          {
            *pgTimeoutTestMode = TIMEOUT_RESET_TEST_START;
            *pgTimeoutTestResetTime = 0;
            FunStartIAP();
          }

          (*pgTimeoutTestResetTime)++;
          printf("****Test Counter: Reset Test[%d]*****************:\n\r", *pgTimeoutTestResetTime);
          gTimeroutTestSystemResetCounter = *pgTimeoutTestResetTime;
          gTimeroutResetCounter = 3000;
          gTimeroutTestAFIOChangeI2CMode = -1;
          FunGetInfo();
          FunErase();
          FunProgramAP();
          FunVerifyAP();
          FunCRCAP();
          #if ENGINNER_MODE2_MODE
          if(gTimeroutTestSystemResetCounter > 0)
          {
            *pgTimeoutTestMode = 0;
            printf("****Test Finish*****\r\n");
          }
          else
          {
            NVIC_SystemReset();
          }
          #else
          gTimeroutTestSystemResetCounter = -1;
          *pgTimeoutTestMode = 0;
          FunStartAP();
          printf("****Test Finish*****\r\n");
          #endif
          break;
        }
        #endif
        #if ENGINNER_MODE3
        case 'z':
        case 'Z':
          TestUnexpectedRead();
          break;
        #endif
        default:
        {
          break;
        }
      }
      ShowMenu();
    }
  }
}

/* Private functions ---------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Show Menu.
  * @retval None
  ***********************************************************************************************************/
static void ShowMenu(void)
{
  printf("\n\r\n\r");
  printf("Holtek IAP Host Example Code\n\r");
  printf("=============================================\n\r");
  printf(" [0] Change I2C slave address IAP:0x%02X AP:0x%02X\n\r", SlaveAddressIAP, SlaveAddressAP);
  printf(" [1] Start IAP\n\r");
  printf(" [2] Start Application\n\r");
  printf(" [3] Update Application automatically\n\r");
  printf("---------------------------------------------\n\r");
  printf(" [4] Erase All Page\n\r");
  printf("---------------------------------------------\n\r");
  printf(" [6] Select Target: Application / Dummy\n\r");
  printf(" [7] Program %s\n\r", uTargetName[uTarget]);
  printf(" [8] Verify  %s\n\r", uTargetName[uTarget]);
  printf(" [9] CRC     %s\n\r", uTargetName[uTarget]);
  printf("=============================================\n\r");
  printf(" [i] Get Chip Info and Version\n\r");
  printf("=============================================\n\r");
  printf(" >");

  return;
}

/*********************************************************************************************************//**
  * @brief  Change I2C Slave address.
  * @retval None
  ***********************************************************************************************************/
static void ChangeSlaveAddress(void)
{
  printf("Input I2C salve address for IAP[0x%02X]:", SlaveAddressIAP);
  SlaveAddressIAP = usart_data_receive(PRINT_UART);
  printf("0x%02X\n\r", SlaveAddressIAP);
  printf("Input I2C salve address for AP[0x%02X]:", SlaveAddressAP);
  SlaveAddressAP = usart_data_receive(PRINT_UART);
  printf("0x%02X\n\r", SlaveAddressAP);

  return;
}

/*********************************************************************************************************//**
  * @brief  Start IAP.
  * @retval None
  ***********************************************************************************************************/
static void FunStartIAP(void)
{
  if (IAP_StartIAP(SlaveAddressAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    if (IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
    {
      printf("Start IAP mode Success!\n\r");
    }
    else
    {
      printf("Start IAP mode Failed!\n\r");
    }
    #endif
  }
  else
  {
    #if !ENGINNER_MODE2
    printf("Start IAP mode Failed!\n\r");
    return;
    #endif
  }
}

/*********************************************************************************************************//**
  * @brief  Start AP.
  * @retval None
  ***********************************************************************************************************/
static void FunStartAP(void)
{
  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Start AP mode Success!\n\r");
  }
  else
  {
    printf("Start AP mode Failed!\n\r");
  }
}

/*********************************************************************************************************//**
  * @brief  Erase.
  * @retval None
  ***********************************************************************************************************/
static void FunErase(void)
{
  if (IAP_Erase(SlaveAddressIAP, IAP_ERASE_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("Erase Success!\n\r");
    #endif
  }
  else
  {
    #if ENGINNER_MODE2
    (*pgTimeoutTestErrorCounter)++;
    #else
    printf("Erase Failed!\n\r");
    #endif
    return;
  }

  #if ENABLE_OB_ERASE
  if (IAP_EraseOB(SlaveAddressIAP, IAP_ERASE_TIMEOUT) == IAP_OK)
  {
    printf("Erase Option Success!\n\r");
  }
  else
  {
    printf("Erase Option Failed!\n\r");
    return;
  }
  #endif

  #if !ENGINNER_MODE2
  printf("Reset to IAP....\n\r");
  #endif
  if (IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("Reset Success!\n\r");
    #endif
  }
  else
  {
    #if ENGINNER_MODE2
    (*pgTimeoutTestErrorCounter)++;
    #else
    printf("Reset Failed!\n\r");
    #endif
  }
}

#if ENABLE_OB_ERASE
/*********************************************************************************************************//**
  * @brief  Erase Option Byte.
  * @retval None
  ***********************************************************************************************************/
static void FunEraseOP(void)
{

  if (IAP_EraseOB(SlaveAddressIAP, IAP_ERASE_TIMEOUT) == IAP_OK)
  {
    printf("Erase Option Success!\n\r");
  }
  else
  {
    printf("Erase Option Failed!\n\r");
    return;
  }

  printf("Reset to IAP....\n\r");
  if (IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Reset Success!\n\r");
  }
  else
  {
    printf("Reset Failed!\n\r");
  }
}
#endif

/*********************************************************************************************************//**
  * @brief  Program AP.
  * @retval None
  ***********************************************************************************************************/
static void FunProgramAP(void)
{
  #if (0)
  /*--------------------------------------------------------------------------------------------------------*/
  /* Program Application's CRC value to device first. It informs IAP loader to check AP CRC value before    */
  /* start application. It prevents IAP loader to start a invalid application image when the following      */
  /* programming operation of AP image is not finished successfully .                                       */
  /*--------------------------------------------------------------------------------------------------------*/
  if (IAP_SubmitCRCAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Submit CRC AP Success!\n\r");
  }
  else
  {
    printf("Submit CRC AP Failed!\n\r");
    return;
  }
  #endif

  /* Start program Application image into device after AP CRC value is submitted                            */
  if (IAP_FlashProgramAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("Program AP Success!\n\r");
    #endif
  }
  else
  {
    #if ENGINNER_MODE2
    (*pgTimeoutTestErrorCounter)++;
    #else
    printf("Program AP Failed!\n\r");
    #endif
  }
}

/*********************************************************************************************************//**
  * @brief  Program Dummy data.
  * @retval None
  ***********************************************************************************************************/
static void FunProgramDummy(void)
{
  if (IAP_FlashDummy(SlaveAddressIAP, IAP_CMD_TIMEOUT, IAP_PARA_PROGRAM) == IAP_OK)
  {
    printf("Program Dummy Success!\n\r");
  }
  else
  {
    printf("Program Dummy Failed!\n\r");
  }
}

/*********************************************************************************************************//**
  * @brief  Verify AP.
  * @retval None
  ***********************************************************************************************************/
static void FunVerifyAP(void)
{
  if (IAP_FlashVerifyAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("Verify AP Success!\n\r");
    #endif
  }
  else
  {
    #if ENGINNER_MODE2
    (*pgTimeoutTestErrorCounter)++;
    #else
    printf("Verify AP Failed!\n\r");
    #endif
  }
}

#if !ENGINNER_MODE2
/*********************************************************************************************************//**
  * @brief  Verify Dummy data.
  * @retval None
  ***********************************************************************************************************/
static void FunVerifyDummy(void)
{
  if (IAP_FlashDummy(SlaveAddressIAP, IAP_CMD_TIMEOUT, IAP_PARA_VERIFY) == IAP_OK)
  {
    printf("Verify Dummy Success!\n\r");
  }
  else
  {
    printf("Verify Dummy Failed!\n\r");
  }
}
#endif

/*********************************************************************************************************//**
  * @brief  CRC AP.
  * @retval None
  ***********************************************************************************************************/
static void FunCRCAP(void)\
{
  if (IAP_CRCAP(SlaveAddressIAP, IAP_CMD_TIMEOUT, 0) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("CRC AP Success!\n\r");
    #endif
  }
  else
  {
    /* To ensure compatibility with V1 Slaves, vector calculation must be skipped */
    if (IAP_CRCAP(SlaveAddressIAP, IAP_CMD_TIMEOUT, IAP_SKIP_VECTOR) == IAP_OK)
    {
      #if !ENGINNER_MODE2
      printf("CRC AP [Skip Vector] Success!\n\r");
      #endif
    }
    else
    {
      #if ENGINNER_MODE2
      (*pgTimeoutTestErrorCounter)++;
      #else
      printf("CRC AP Failed!\n\r");
      #endif
    }
  }
}

#if !ENGINNER_MODE2
/*********************************************************************************************************//**
  * @brief  CRC Dummy Data.
  * @retval None
  ***********************************************************************************************************/
static void FunCRCDummy(void)
{
  if (IAP_CRCDummy(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("CRC Dummy Success!\n\r");
  }
  else
  {
    printf("CRC Dummy Failed!\n\r");
  }
}
#endif

/*********************************************************************************************************//**
  * @brief  Configures I2C.
  * @retval None
  ***********************************************************************************************************/
void I2C_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  gpio_init_type gpio_init_structure;
  i2c_reset(HTCFG_IAPI2C_PORT);

  /* i2c periph clock enable */
  crm_periph_clock_enable(HTCFG_IAPI2C_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SCL_GPIO_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SDA_GPIO_CLK, TRUE);

  /* gpio configuration */
  gpio_pin_mux_config(HTCFG_IAPI2C_SCL_GPIO_PORT, HTCFG_IAPI2C_SCL_GPIO_PinsSource, HTCFG_IAPI2C_SCL_GPIO_MUX);
  gpio_pin_mux_config(HTCFG_IAPI2C_SDA_GPIO_PORT, HTCFG_IAPI2C_SDA_GPIO_PinsSource, HTCFG_IAPI2C_SDA_GPIO_MUX);

  /* configure i2c pins: scl */
  gpio_init_structure.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_structure.gpio_mode           = GPIO_MODE_MUX;
  gpio_init_structure.gpio_out_type       = GPIO_OUTPUT_OPEN_DRAIN;
  gpio_init_structure.gpio_pull           = GPIO_PULL_NONE;

  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SCL_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SCL_GPIO_PORT, &gpio_init_structure);

  /* configure i2c pins: sda */
  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SDA_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SDA_GPIO_PORT, &gpio_init_structure);

  /* configure and enable i2c interrupt */
  nvic_irq_enable(HTCFG_IAPI2C_EVT_IRQn, 0, 0);

  /* config i2c */
  i2c_init(HTCFG_IAPI2C_PORT, 0x0F, I2C_CLOCK_SPEED);

  i2c_own_address1_set(HTCFG_IAPI2C_PORT, I2C_ADDRESS_MODE_7BIT, I2C_MASTER_ADDRESS);

  /* i2c peripheral enable */
  i2c_enable(HTCFG_IAPI2C_PORT, TRUE);
  i2c_interrupt_enable(HTCFG_IAPI2C_PORT, (I2C_ADDR_INT | I2C_ACKFIAL_INT | I2C_RD_INT | I2C_TDC_INT), TRUE);
}

/*********************************************************************************************************//**
  * @brief  FunGetInfo.
  * @retval None
  ***********************************************************************************************************/
static void FunGetInfo(void)
{
  if (IAP_GetInfo(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    #if !ENGINNER_MODE2
    printf("Get Information Success!\n\r");
    #endif
    if (IAP_GetVersion(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
    {
      #if !ENGINNER_MODE2
      printf("Get AP Version Success!\n\r");
      #endif
    }
    else
    {
      #if !ENGINNER_MODE2
      printf("Get Information Failed!\n\r");
      #else
      (*pgTimeoutTestErrorCounter)++;
      #endif
      return;
    }
  }
  else
  {
    #if !ENGINNER_MODE2
    printf("Get Information NOT Support!\n\r");
    #endif
    return;
  }
}

#if ENGINNER_MODE3
/*********************************************************************************************************//**
  * @brief  Test UnexpectedRead.
  * @retval None
  ***********************************************************************************************************/
static void TestUnexpectedRead(void)
{
  extern u8 ENGINNER_MODE3_GetRET_Length;
  extern u8 ENGINNER_MODE3_IAP_DATA_PACKET_SIZE;
  IAP_Protocol_TypeDef Command;

  IAP_StartIAP(SlaveAddressAP, IAP_CMD_TIMEOUT);
  IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT);
  while(i2c_flag_get(HTCFG_IAPI2C_PORT, I2C_BUSYF_FLAG) == SET);
  i2c_transfer_addr_set(HTCFG_IAPI2C_PORT,SlaveAddressIAP<<1);
  i2c_transfer_dir_set(HTCFG_IAPI2C_PORT,I2C_DIR_RECEIVE);
  i2c_start_generate(HTCFG_IAPI2C_PORT);
  i2c_stop_generate(HTCFG_IAPI2C_PORT);
  I2CBuffer_Delay(100);
  i2c_reset(HTCFG_IAPI2C_PORT);
  I2C_Configuration();
  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Test Read Stop Success!\n\r");
  }
  else
  {
    printf("Test Read Stop Failed!\n\r");
    return;
  }

  IAP_StartIAP(SlaveAddressAP, IAP_CMD_TIMEOUT);
  IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT);
  IAP_GetRET(SlaveAddressIAP, IAP_CMD_TIMEOUT);
  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Test No COMMAND Read Success!\n\r");
  }
  else
  {
    printf("Test No COMMAND Read Failed!\n\r");
    return;
  }
  IAP_StartIAP(SlaveAddressAP, IAP_CMD_TIMEOUT);
  IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT);
  Command.Code = (IAP_CODE_Enum)0x8888;
  Command.uLength = 0;
  IAP_SendCommand(SlaveAddressIAP, &Command, IAP_CMD_TIMEOUT);
  IAP_GetRET(SlaveAddressIAP, IAP_CMD_TIMEOUT);
  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Test Error COMMAND Read Success!\n\r");
  }
  else
  {
    printf("Test Error COMMAND Read Failed!\n\r");
    return;
  }

  IAP_StartIAP(SlaveAddressAP, IAP_CMD_TIMEOUT);
  ENGINNER_MODE3_GetRET_Length = 5;
  IAP_StartIAP(SlaveAddressIAP, IAP_CMD_TIMEOUT);

  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Test RETURN: 5B Requested / 4B Available Success!\n\r");
  }
  else
  {
    printf("Test RETURN: 5B Requested / 4B Available Failed!\n\r");
    return;
  }
  
  ENGINNER_MODE3_GetRET_Length = IAP_CODE_LENGTH;
  FunStartIAP();
  FunGetInfo();
  FunErase();
  ENGINNER_MODE3_IAP_DATA_PACKET_SIZE = 20;
  FunProgramAP();
  FunStartIAP();
  FunGetInfo();
  FunErase();
  ENGINNER_MODE3_IAP_DATA_PACKET_SIZE = IAP_DATA_PACKET_SIZE;
  FunProgramAP();
  FunVerifyAP();
  FunCRCAP();
  if (IAP_StartAP(SlaveAddressIAP, IAP_CMD_TIMEOUT) == IAP_OK)
  {
    printf("Test DATA: 20 Byte Read Success!\n\r");
  }
  else
  {
    printf("Test DATA: 20 Byte Read Failed!\n\r");
    return;
  }
}
#endif

/*********************************************************************************************************//**
  * @brief  UxART configuration.
  * @retval None
  ***********************************************************************************************************/
void UxART_Configuration(void)
{
  uart_print_init(115200);

  #if defined(USE_HT32F49041_SK) || defined(USE_HT32F49163_SK)
  // initialize UxART RX MUX config.
  {
    gpio_init_type gpio_init_struct;
    gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
    gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
    gpio_init_struct.gpio_pins = HTCFG_RX_PIN;
    gpio_init_struct.gpio_pull = GPIO_PULL_UP;
    gpio_init(HTCFG_RX_GPIO, &gpio_init_struct);

    gpio_pin_mux_config(HTCFG_RX_GPIO, HTCFG_RX_PIN_SOURCE, HTCFG_RX_PIN_MUX_NUM);
  }
  #endif

  usart_receiver_enable(PRINT_UART, TRUE);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
