/*********************************************************************************************************//**
 * @file    ht32f490x1_int.c
 * @version $Rev:: 565         $
 * @date    $Date:: 2025-05-28 #$
 * @brief   main interrupt service routines.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* includes ------------------------------------------------------------------*/
#include "ht32f490x1_int.h"
#include "ht32f490x1_board.h"
#include "ht32f490x1_clock.h"
#include "ht32_board_config.h"
#include "i2c_buffer.h"
#include "iap_host.h"

/** @addtogroup HT32F490x1_periph_template
  * @{
  */

/** @addtogroup HT32F490x1_LED_toggle
  * @{
  */


/**
  * @brief  this function handles nmi exception.
  * @param  none
  * @retval none
  */
void NMI_Handler(void)
{
}

/**
  * @brief  this function handles hard fault exception.
  * @param  none
  * @retval none
  */
void HardFault_Handler(void)
{
  /* go to infinite loop when hard fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles memory manage exception.
  * @param  none
  * @retval none
  */
void MemManage_Handler(void)
{
  /* go to infinite loop when memory manage exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles bus fault exception.
  * @param  none
  * @retval none
  */
void BusFault_Handler(void)
{
  /* go to infinite loop when bus fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles usage fault exception.
  * @param  none
  * @retval none
  */
void UsageFault_Handler(void)
{
  /* go to infinite loop when usage fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles svcall exception.
  * @param  none
  * @retval none
  */
void SVC_Handler(void)
{
}

/**
  * @brief  this function handles debug monitor exception.
  * @param  none
  * @retval none
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  this function handles pendsv_handler exception.
  * @param  none
  * @retval none
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  this function handles systick handler.
  * @param  none
  * @retval none
  */
void SysTick_Handler(void)
{
  extern vs32 gsI2CBuffer_TimerCount;
  if (gsI2CBuffer_TimerCount > 0)
  {
    gsI2CBuffer_TimerCount--;
  }
  #if ENGINNER_MODE2
  {
    extern  volatile s32 *pgTimeoutTestResetTime;
    extern s32 gTimeroutTestSystemResetCounter ;
    extern s32 gTimeroutTestAFIOChangeI2CMode ;
    extern s32 gTimeroutResetCounter;
    if(gTimeroutTestSystemResetCounter > 0)
    {
      gTimeroutTestSystemResetCounter--;
    }
    else if (gTimeroutTestSystemResetCounter == 0)
    {
      ht32_led_on(LED4);
      #if ENGINNER_MODE2_MODE
      {
        gpio_init_type gpio_init_structure;
        crm_periph_clock_enable(HTCFG_IAPI2C_SCL_GPIO_CLK, FALSE);
        crm_periph_clock_enable(HTCFG_IAPI2C_SDA_GPIO_CLK, FALSE);
        gTimeroutTestSystemResetCounter = -1;
        gTimeroutTestAFIOChangeI2CMode  = 2;
      }
      #else
      NVIC_SystemReset();
      #endif
    }
    if(gTimeroutResetCounter>0)
    {
      gTimeroutResetCounter--;
    }
    else if(gTimeroutResetCounter == 0)
    {
      NVIC_SystemReset();
    }
    #if ENGINNER_MODE2_MODE
    if(gTimeroutTestAFIOChangeI2CMode > 0)
    {
      gTimeroutTestAFIOChangeI2CMode--;
    }
    else if (gTimeroutTestAFIOChangeI2CMode == 0)
    {
      gpio_init_type gpio_init_structure;
      ht32_led_off(LED4);
      crm_periph_clock_enable(HTCFG_IAPI2C_SCL_GPIO_CLK, TRUE);
      crm_periph_clock_enable(HTCFG_IAPI2C_SDA_GPIO_CLK, TRUE);
      gTimeroutTestAFIOChangeI2CMode = -1;
    }
    #endif
    
  }
  #endif
}

/**
  * @brief  this function handles i2c event interrupt request.
  * @param  none
  * @retval none
  */
void I2Cx_EVT_IRQHandler(void)
{
  HTCFG_IAPI2C_IRQHandler();
}

/**
  * @brief  this function handles i2c error interrupt request.
  * @param  none
  * @retval none
  */
void I2Cx_ERR_IRQHandler(void)
{
}

/**
  * @}
  */

/**
  * @}
  */
