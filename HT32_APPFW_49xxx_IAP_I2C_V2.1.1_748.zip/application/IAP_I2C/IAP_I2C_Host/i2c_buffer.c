/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/i2c_buffer.c
 * @version $Rev:: 516          $
 * @date    $Date:: 2025-05-12 #$
 * @brief   The buffer of I2C interrupt mode.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "i2c_buffer.h"


/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/**
 * @brief I2C Buffer global variables
 */
typedef struct
{
  u32 uIndex;
  u32 uLength;
  u8 *puBuffer;
  u32 uSlaveAddress;
  u32 uCommand;
  vu32 IsBusy;
  vu32 uIsNACK;
} I2CBuffer_TypeDef;

/* Private constants ---------------------------------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Global variables ----------------------------------------------------------------------------------------*/
vs32 gsI2CBuffer_TimerCount;

/* Private variables ---------------------------------------------------------------------------------------*/
static I2CBuffer_TypeDef gI2CBuffer;

/* Global functions ----------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Start Read or Write of I2C buffer.
  * @param  pI2CBuffer: Pointer of I2CBuffer_InitTypedef
  * @retval None
  ***********************************************************************************************************/
void I2CBuffer_Start(I2CBuffer_InitTypedef *pI2CBuffer)
{
  gI2CBuffer.uIndex = 0;
  gI2CBuffer.uLength = pI2CBuffer->uLength;
  gI2CBuffer.puBuffer = pI2CBuffer->puBuffer;
  gI2CBuffer.uSlaveAddress = pI2CBuffer->uSlaveAddress;
  gI2CBuffer.IsBusy = TRUE;
  gI2CBuffer.uIsNACK = FALSE;
  gsI2CBuffer_TimerCount = pI2CBuffer->uTimeout;

  while (i2c_flag_get(HTCFG_IAPI2C_PORT, I2C_BUSYF_FLAG) == SET);

  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ACKFAIL_FLAG);
  i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_ACKFIAL_INT, TRUE);

  if (pI2CBuffer->Command == I2C_BUFFER_WRITE)
  {
    i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_TD_INT, TRUE);
    gI2CBuffer.uCommand = I2C_BUFFER_WRITE;
  }
  else
  {
    gI2CBuffer.uCommand = I2C_BUFFER_READ;
  }

  if (gI2CBuffer.uCommand == I2C_BUFFER_WRITE)
  {
    i2c_transmit_set(HTCFG_IAPI2C_PORT, pI2CBuffer->uSlaveAddress << 1, pI2CBuffer->uLength, I2C_SOFT_STOP_MODE, I2C_GEN_START_WRITE);
  }
  else
  {
    i2c_transmit_set(HTCFG_IAPI2C_PORT, pI2CBuffer->uSlaveAddress << 1, pI2CBuffer->uLength, I2C_SOFT_STOP_MODE, I2C_GEN_START_READ);
  }
  return;
}

/*********************************************************************************************************//**
  * @brief  Get I2C buffer statue.
  * @retval Result: I2C_BUFFER_FINISH or I2C_BUFFER_TIMEOUT
  ***********************************************************************************************************/
I2CBuffer_Status_Enum I2CBuffer_GetStatus(void)
{
  I2CBuffer_Status_Enum Result = I2C_BUFFER_GOING;
  vu32 i;

  if (gI2CBuffer.IsBusy == FALSE)
  {
    Result = I2C_BUFFER_FINISH;
  }
  else if (gsI2CBuffer_TimerCount == 0)
  {
    Result = I2C_BUFFER_TIMEOUT;

    i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_ACKFIAL_INT, FALSE);
    i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ACKFAIL_FLAG);

    i2c_stop_generate(HTCFG_IAPI2C_PORT);
  }
  else if (gI2CBuffer.uIsNACK == TRUE)
  {
    gI2CBuffer.uIsNACK = FALSE;

    /* Release I2C bus for other master by adding a delay                                                   */
    for (i = 0; i < 500; i++);

    if (gI2CBuffer.uCommand == I2C_BUFFER_WRITE)
    {
      i2c_transmit_set(HTCFG_IAPI2C_PORT, gI2CBuffer.uSlaveAddress << 1, gI2CBuffer.uLength, I2C_SOFT_STOP_MODE, I2C_GEN_START_WRITE);
    }
    else
    {
      i2c_transmit_set(HTCFG_IAPI2C_PORT, gI2CBuffer.uSlaveAddress << 1, gI2CBuffer.uLength, I2C_SOFT_STOP_MODE, I2C_GEN_START_READ);
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Delay based on ms.
  * @param  ms: Delay time based on ms
  * @retval None
  ***********************************************************************************************************/
void I2CBuffer_Delay(u32 ms)
{
  gsI2CBuffer_TimerCount = ms;
  SysTick->VAL = 0;
  while (gsI2CBuffer_TimerCount != 0);
}

/*********************************************************************************************************//**
 * @brief   This function handles I2C interrupt.
 * @retval  None
 ************************************************************************************************************/
#define TESTMASK ~(I2C_ADDRF_FLAG | I2C_STOPF_FLAG)
void HTCFG_IAPI2C_IRQHandler(void)
{
  u32 uResult;

  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ADDRF_FLAG);
  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_STOPF_FLAG);
  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_BUSERR_FLAG);

  uResult = HTCFG_IAPI2C_PORT->sts & 0x1FFFF;
  switch (uResult)
  {
    /*-----------------------------Master Receiver ---------------------------------------------------------*/
    case I2C_MST_RX_RDBF:
    {
      /* Receive data sent from I2C                                                                         */
      *(gI2CBuffer.puBuffer + gI2CBuffer.uIndex) = i2c_data_receive(HTCFG_IAPI2C_PORT);
      gI2CBuffer.uIndex++;
      gI2CBuffer.uLength--;

      if (gI2CBuffer.uLength == 1)
      {
        i2c_ack_enable(HTCFG_IAPI2C_PORT, FALSE);
      }
      else if (gI2CBuffer.uLength == 0)
      {
        i2c_stop_generate(HTCFG_IAPI2C_PORT);

        /* Clear IsBusy flag to terminate polling of I2CBuffer_GetStatus                                    */
        gI2CBuffer.IsBusy = FALSE;
      }
      break;
    }

    /*-----------------------------Master Transmitter ------------------------------------------------------*/
    case I2C_MST_TX_TDC:
    case I2C_MST_TX_TDIS:
    {
      if (gI2CBuffer.uLength != 0)
      {
        i2c_data_send(HTCFG_IAPI2C_PORT, *(gI2CBuffer.puBuffer + gI2CBuffer.uIndex));
        gI2CBuffer.uIndex++;
        gI2CBuffer.uLength--;
      }
      else
      {
        i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_TD_INT, FALSE);
        i2c_stop_generate(HTCFG_IAPI2C_PORT);

        /* Clear IsBusy flag to terminate polling of I2CBuffer_GetStatus                                    */
        gI2CBuffer.IsBusy = FALSE;
      }
      break;
    }

    /* Received NACK when Read or Write mode                                                                */
    case I2C_MST_BUSY_ACKFAIL:
    case I2C_MST_ACKFAIL:
    {
      i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ACKFAIL_FLAG);
      i2c_stop_generate(HTCFG_IAPI2C_PORT);

      /* Set uIsNACK flag for re-try by I2CBuffer_GetStatus                                                 */
      gI2CBuffer.uIsNACK = TRUE;
      break;
    }
  }
}

/* Private functions ---------------------------------------------------------------------------------------*/

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
