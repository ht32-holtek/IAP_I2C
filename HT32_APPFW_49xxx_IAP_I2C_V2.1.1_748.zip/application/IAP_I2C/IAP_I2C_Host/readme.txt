/**
 @page IAP_I2C_Host

 @verbatim
 * @file    IAP_I2C/IAP_I2C_Host/readme.txt
 * @version V0.01
 * @date    2016-04-14
 * @brief   Description of In-Application Programming I2C Host example (IAP I2C Host).
 @endverbatim

@par Example Description:

<PRE>
The example code of IAP I2C Host which is connected with a IAP Device to download user's image
into main Flash via I2C interface. This example acts as a I2C master and supports the following
protocol:

- Protocol Flow:

                             -----------
                             |  IDLE   |  <--------|
                             -----------           |
  Direction                       |                |
  ===============            -----------           |
  Host to Device             | COMMAND |           |
                             -----------           |
                                  |                |
                             -----------           |
  Device to Host             | RETURN  |  -------->|
                             -----------           |
                                  |                |
                  ---------  -----------           |
  Host to Device  |          |  DATA   |  <----|   |
                  |          -----------       |   |
                  | Option        |            |   |
                  |          -----------       |   |
  Device to Host  |          | RETURN  |  ---->|   |
                  ---------  -----------           |
                                  |                |
                                  |--------------->|


- Command Synchronous:

  After device received and executed a command, Host can obtain a RETURN code via I2C Master Read.
  Since the erase command shall take long time, Device will change it salve address during erase operation.
  The IAP protocol uses the following steps to ensure the IAP Host and Device can keep synchronous during
  multiple operations of IAP COMMAND/RETURN.

  1. Master starts a I2C Write for sending IAP COMMAND
     a  If Master received NAK, STOP the I2C Write transfer and re-try after a short delay.
     b. If Master did not receive ACK after specific time (timeout), STOP the I2C Write and terminate IAP
        command. Report this situation as send command timeout.
     c. If Master received ACK, STOP the I2C Write transfer. It means Device received the IAP command.

  2. Add a short delay
     This delay ensures that Device is ready for response or already change its slave address for waiting
     mode (Erase command). We recommend 2 ms for this delay.

  3. Master starts a I2C Write with zero length data for checking Device is ready or not.
     a. If Master received NAK, STOP the I2C Write transfer and re-try after a short delay.
     b. If Master did not receive ACK after specific time (timeout), STOP the I2C Write and terminate IAP
        command. Report this situation as check Device ready timeout.
     c. If Master received ACK, STOP the I2C Write transfer. It means Device is ready for transmit RETURN.

  4. Master starts a I2C Read to obtain RETURN code.

  5. Add a longer delay
     This delay ensure that all operation of device is finished. Especially for device reset. We recommend
     10 ms for this delay.


- COMMAND Format:

    0                   1                   2                   3
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  ----------|
   |              Code             |             Check             |   Required |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  ----------|
   |    uLength    |     uPara     |             uCRC              |            |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+            |
   |                            uStAddr                            |    Option  |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+            |
   |                            uEndAddr                           |            |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  ----------|

    Field       Size (Bytes)       Descriptions
    ========    ===============    ======================
    Code        2                  Command Code.
    Check       2                  The complement of Code. For example, Check = 0x7EFE when Code = 0x8101.
    uLength     1 (Option)         Total length including uLength, uPara, uCRC, uStaddr, and uEndAddr.
    uPara       1 (Option)         Parameter of command.
    uCRC        2 (Option)         CRC16 value of (uLength, uPara, 0x0000, uStaddr, and uEndAddr).
    uStAddr     4 (Option)         Start address of command.
    uEndAddr    4 (Option)         End address of command.


- COMMAND Code:

    Command            Code        Option    Para      Descriptions
    ========           =========   =======   =======   ======================
    IAP_CMD_START_IAP  0x8101      No        None      Reset and start IAP mode.
    IAP_CMD_START_APP  0x8102      No        None      Reset and start AP mode.
    IAP_CMD_ERASE      0x8103      Yes       None      Erase specific page which assigned by uStAddr and
                                                       uEndAddr.
    IAP_CMD_FLASH      0x8104      Yes       0         Program specific Flash Memory which assigned by
                                                       uStAddr and uEndAddr.
                                             1         Verify specific Flash Memory which assigned by
                                                       uStAddr and uEndAddr.
                                             2         Read specific Flash Memory which assigned by
                                                       uStAddr and uEndAddr.
    IAP_CMD_CRC        0x8105      Yes       None      Apply CRC16 checking of specific Flash Memory which
                                                       assigned by uStAddr and uEndAddr.
    IAP_CMD_GETINFO    0x8106      No        None      Return 4 words information.


- DATA Format (option):

    0                   1                   2                   3
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |     Byte 0    |     Byte 1    |     Byte 2    |     Byte 3    |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |                              ...                              |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |    Byte 124   |    Byte 125   |    Byte 126   |    Byte 127   |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |             uCRC              |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

    Field       Size (Bytes)       Descriptions
    ========    ===============    ======================
    Byte n      128 (Option)       Data for Flash command. Only valid for IAP_CMD_FLASH.
    uCRC        2                  CRC16 value. For IAP_CMD_FLASH command, this field indicates the CRC16
                                   value of Byte0 ~ Byte127. For IAP_CMD_CRC command, this field indicates
                                   the expected CRC value of specific Flash Memory range which assigned
                                   by uStAddr and uEndAddr. The selected polynomial of CRC algorithm is
                                   CRC-16-CCITT (0x1021).


- RETURN Format:

    0                   1                   2                   3
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  ----------|
   |              Code             |             Check             |   Required |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  ----------|

    Field       Size (Bytes)       Descriptions
    ========    ===============    ======================
    Code        2                  Return Code
    Check       2                  The complement of Code


- RETURN Code:

    Return              Code               Descriptions
    ========            ===============    ======================
    IAP_RET_OK          0x5A01             Command operation Okey
    IAP_RET_FAIL        0x5A02             Command operation failed
    IAP_RET_CMDERROR    0x5A03             Command or Parameter error (not support, Check, or uCRC error)


- How to Change Application Start Address:

  The application start address shall be modified if the IAP code size is changed. For example, if you
  add more functions into IAP loader which causes the IAP code size changed from 3700 bytes to 4700 bytes
  (large then 4096 Bytes), you shall modify application start address from 0x1000 (4096 Bytes) to 0x1400
  (5120 Bytes). Note that the step of application start address is based on the Flash Page size. Following
  description shows how to modify RO base address of IAP Device, application, and IAP Host.

  IAP Loader (IAP):
  ==========================================
    1. Modify the define value of "IAP_CODE_SIZE" in "IAP_I2C/IAP_I2C_Device/iap_config.h" file.
       IAP loader uses this define to confirm PC/SP, apply AP CRC Checking, ensure parameter uStAddr
       from Host is valid.

      |    ....
      |
      |    #define IAP_CODE_SIZE                 (1024 * 4)                    /* IAP code size in Bytes    */
      |
      |    ....

  Application (AP):
  ==========================================
    For application, you shall change both IAP_CODE_SIZE define and RO base address. IAP_CODE_SIZE define
    is using for NVIC VTO setting since the vector is not locate at 0x00000000. In addition, RO base address
    tell linker the layout and addressing of image.

    1. Modify the define value of "IAP_CODE_SIZE" in "IAP_I2C/IAP_I2C_Device/iap_config.h" file.
       This step is the same with IAP Loader (IAP) point 1.

    2. Following linker script files define the RO base address. The format of link script is different
       between various compiling tools. If your application did not use link script instead of using project
       setting, you need find out the RO Base address setting of linker and modify it. Please refer to the
       document of compiling tools for more information.

       IAP_I2C/IAP_I2C_Device/MDK_ARM/linker.lin

         |   ....
         |
         |   IAP 0x00000000 0x00001000         ; 4 kB for IAP
         |   {
         |
         |   ....
         |
         |   }
         |
         |   AP 0x00001000                     ; User application start from 0x1000
         |   {
         |
         |   ....

  IAP Host:
  ==========================================
    Modify the define value of "IAP_CODE_SIZE" in "IAP_I2C/IAP_I2C_Host/iap_config.h" file. IAP Host
    uses this define to assign the parameter, uStAddr.

      |    ....
      |
      |    /* IAP                                                                                           */
      |    #define IAP_CODE_SIZE                 (1024 * 4)                    /* IAP code size in Bytes    */
      |
      |    ....


</PRE>


@par Directory Contents:

- IAP_I2C/IAP_I2C_Host/main.c                              Main program of application
- IAP_I2C/IAP_I2C_Host/ht32f49xxx_int.c                    Interrupt handlers
- IAP_I2C/IAP_I2C_Host/ht32f49xxx_int.h                    Header file of Interrupt handlers
- IAP_I2C/IAP_I2C_Host/ht32f49xxx_conf.h                   Firmware library configuration file
- IAP_I2C/IAP_I2C_Host/system_ht32f49xxx.c                 System configuration file
- IAP_I2C/IAP_I2C_Host/system_ht32f49xxx.c                 Header file of System configuration file
- IAP_I2C/IAP_I2C_Host/ht32f49xxx_clock.c                  system clock config program
- IAP_I2C/IAP_I2C_Host/ht32f49xxx_clock.h                  header file of clock program
- IAP_I2C/IAP_I2C_Host/ht32_board_config.h                 IAP I2C Host configuration file
- IAP_I2C/IAP_I2C_Host/iap_protocol.h                      Header file of the IAP protocol
- IAP_I2C/IAP_I2C_Host/iap_config.h                        The configuration file of IAP
- IAP_I2C/IAP_I2C_Host/iap_host.c                          IAP handler who control the image update procedural
- IAP_I2C/IAP_I2C_Host/iap_host.h                          Header file of the IAP host
- IAP_I2C/IAP_I2C_Host/i2c_buffer.c                        Buffer function for I2C
- IAP_I2C/IAP_I2C_Host/i2c_buffer.h                        Header file of I2C buffer
- IAP_I2C/IAP_I2C_Host/crc16.c                             CRC algorithm for Xmodem and Flash checksum
- IAP_I2C/IAP_I2C_Host/crc16.h                             Header file of CRC algorithm
- IAP_I2C/IAP_I2C_Host/target_ap.s                         ASM file for include AP binary into application
- IAP_I2C/IAP_I2C_Host/linker.lin                          Link script file of MDK-ARM

@par Hardware and Software Environment:

This example runs on HT32 Series Development board. Please connect I2C_SCL and I2C_SDA with
target Device's I2C interface.

@par Firmware Disclaimer Information

1. The customer hereby acknowledges and agrees that the program technical documentation, including the
   code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
   proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
   other intellectual property laws.

2. The customer hereby acknowledges and agrees that the program technical documentation, including the
   code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
   other than HOLTEK and the customer.

3. The program technical documentation, including the code, is provided "as is" and for customer reference
   only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
   the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
   the warranties of merchantability, satisfactory quality and fitness for a particular purpose.

 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 */
