/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/ht32_board_config.h
 * @version $Rev:: 625          $
 * @date    $Date:: 2025-06-17 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

#define I2C_MST_ACKFAIL        (I2C_ACKFAIL_FLAG | I2C_TDBE_FLAG)                  // 0x0011
#define I2C_MST_BUSY_ACKFAIL   (I2C_BUSYF_FLAG | I2C_ACKFAIL_FLAG | I2C_TDBE_FLAG) // 0x8011

#define I2C_MST_RX_RDBF        (I2C_BUSYF_FLAG | I2C_RDBF_FLAG | I2C_TDBE_FLAG)    // 0x8005
#define I2C_MST_TX_TDC         (I2C_BUSYF_FLAG | I2C_TDC_FLAG | I2C_TDBE_FLAG)     // 0x8041

#define I2C_MST_TX_TDIS        (I2C_BUSYF_FLAG | I2C_TDIS_FLAG | I2C_TDBE_FLAG)    // 0x8003

/* Settings ------------------------------------------------------------------------------------------------*/
#if defined(USE_HT32F49041_SK)
//  #define I2C_CLOCK_SPEED                    0x80E02E2E      //100KHz
  #define I2C_CLOCK_SPEED                    0x10B0233E      //400KHz

  #define HTCFG_IAPI2C_PORT                       I2C1
  #define HTCFG_IAPI2C_CLK                        CRM_I2C1_PERIPH_CLOCK

  #define HTCFG_IAPI2C_SCL_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SCL_GPIO_PIN               GPIO_PINS_6
  #define HTCFG_IAPI2C_SCL_GPIO_PinsSource        GPIO_PINS_SOURCE6
  #define HTCFG_IAPI2C_SCL_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SCL_GPIO_MUX               GPIO_MUX_1

  #define HTCFG_IAPI2C_SDA_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SDA_GPIO_PIN               GPIO_PINS_7
  #define HTCFG_IAPI2C_SDA_GPIO_PinsSource        GPIO_PINS_SOURCE7
  #define HTCFG_IAPI2C_SDA_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SDA_GPIO_MUX               GPIO_MUX_1

  #define HTCFG_IAPI2C_EVT_IRQn                   I2C1_EVT_IRQn
  #define HTCFG_IAPI2C_ERR_IRQn                   I2C1_ERR_IRQn

  #define I2Cx_EVT_IRQHandler                     I2C1_EVT_IRQHandler
  #define I2Cx_ERR_IRQHandler                     I2C1_ERR_IRQHandler

  #define HTCFG_RX_GPIO                           GPIOA
  #define HTCFG_RX_PIN                            GPIO_PINS_10
  #define HTCFG_RX_PIN_SOURCE                     GPIO_PINS_SOURCE10
  #define HTCFG_RX_PIN_MUX_NUM                    GPIO_MUX_1
#endif

#if defined(USE_HT32F49163_SK)
//  #define I2C_CLOCK_SPEED                    0x60E02C2C      //100KHz
  #define I2C_CLOCK_SPEED                    0x10C0172A      //400KHz

  #define HTCFG_IAPI2C_PORT                       I2C1
  #define HTCFG_IAPI2C_CLK                        CRM_I2C1_PERIPH_CLOCK

  #define HTCFG_IAPI2C_SCL_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SCL_GPIO_PIN               GPIO_PINS_6
  #define HTCFG_IAPI2C_SCL_GPIO_PinsSource        GPIO_PINS_SOURCE6
  #define HTCFG_IAPI2C_SCL_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SCL_GPIO_MUX               GPIO_MUX_4

  #define HTCFG_IAPI2C_SDA_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SDA_GPIO_PIN               GPIO_PINS_7
  #define HTCFG_IAPI2C_SDA_GPIO_PinsSource        GPIO_PINS_SOURCE7
  #define HTCFG_IAPI2C_SDA_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SDA_GPIO_MUX               GPIO_MUX_4

  #define HTCFG_IAPI2C_EVT_IRQn                   I2C1_EVT_IRQn
  #define HTCFG_IAPI2C_ERR_IRQn                   I2C1_ERR_IRQn

  #define I2Cx_EVT_IRQHandler                     I2C1_EVT_IRQHandler
  #define I2Cx_ERR_IRQHandler                     I2C1_ERR_IRQHandler

  #define HTCFG_RX_GPIO                           GPIOA
  #define HTCFG_RX_PIN                            GPIO_PINS_10
  #define HTCFG_RX_PIN_SOURCE                     GPIO_PINS_SOURCE10
  #define HTCFG_RX_PIN_MUX_NUM                    GPIO_MUX_7
#endif

#ifdef __cplusplus
}
#endif

#endif
