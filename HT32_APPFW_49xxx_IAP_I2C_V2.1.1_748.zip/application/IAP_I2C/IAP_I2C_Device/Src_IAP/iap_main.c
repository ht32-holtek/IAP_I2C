/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_IAP/iap_main.c
 * @version $Rev:: 560          $
 * @date    $Date:: 2025-05-28 #$
 * @brief   The main program of IAP example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "i2c_config.h"
#include "iap_config.h"
#include "iap_handler.h"
#include "iap_wdt_config.h"
#include "common\ring_buffer.h"
#include "common\ht32_misc.h"

/* Dependency check ----------------------------------------------------------------------------------------*/
#if defined(__HT32F490x1_H)
#define MIN_HT32_FWLIB_VER              (0x01001002) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x78)
#endif
#if defined(__HT32F491x3_H)
#define MIN_HT32_FWLIB_VER              (0x01000006) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x131)
#endif
#include "ht32_dependency.h" // Not exist means the version of HT32 Firmware Library is older than the module required.

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_IAP IAP example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define TIMER_BASE                    (SystemCoreClock / 8 / 1000)  /* 1 ms                                 */

/* Private function prototypes -----------------------------------------------------------------------------*/
void IAPUser_BootProcess(void);
void NVIC_Configuration(void);
void CKCU_Configuration(void);
void GPIO_Configuration(void);
void I2C_Configuration(void);

/* Global variables ----------------------------------------------------------------------------------------*/
#if (IAP_TIMEOUT_EN == 1)
s32 gIAPTimeout = IAP_TIMEOUT;
#endif
#if (IAP_DOUBLE_RESET_EN == 1)
s32 gDoubleTimeout = IAP_DOUBLE_TIMEOUT;
#endif

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  system_clock_config();

  #if (IAP_DEBUG_MODE == 1)
  uart_print_init(115200);
  #endif
  IAPUser_BootProcess();

  #if ENABLE_WDT
  wdt_register_write_enable(TRUE);
  wdt_divider_set(WDT_CLK_DIV_64);
  /* set reload value

   timeout = reload_value * (divider / lick_freq )    (s)

   lick_freq    = 40000 Hz
   divider      = 64
   reload_value = 2500

   timeout = 2500 * (64 / 40000 ) = 4s
  */
  wdt_reload_value_set(2500);
  wdt_counter_reload();
  wdt_enable();
  #endif

  NVIC_Configuration();

  CKCU_Configuration();

  GPIO_Configuration();

  I2C_Configuration();

  IAP_Init();

  while (1)
  {
    IAP_Handler();                      /* Start IAP mode                                                   */
    WDT_RST();
  }
}

/*********************************************************************************************************//**
  * @brief  IAP User level boot process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_BootProcess(void)
{
  #if 0
  /* !!! NOTICE !!!
        Modify it if you want to use another GPIO pin.
  */
  /*--------------------------------------------------------------------------------------------------------*/
  /* Example that using GPIO to force the IAP mode.                                                         */
  /* GPIO = 0: Normal boot flow, GPIO = 1: IAP mode                                                         */
  /*--------------------------------------------------------------------------------------------------------*/
  {
    gpio_init_type gpio_init_struct;
    crm_periph_clock_enable(USER_BUTTON_CRM_CLK, TRUE);
    gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
    gpio_init_struct.gpio_pins = USER_BUTTON_PIN;
    gpio_init_struct.gpio_pull = GPIO_PULL_DOWN;
    gpio_init(USER_BUTTON_PORT, &gpio_init_struct);
  }
  if ( gpio_input_data_bit_read(USER_BUTTON_PORT, USER_BUTTON_PIN) == RESET)
  #endif
  {
    #if (IAP_TIMEOUT_EN == 1)
    if (BOOT_MODE == BOOT_MODE_APP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 and                                                                                    */
      /*   2. BOOT_MODE == BOOT_MODE_AP (Default IAP) and                                                   */
      /*   3. SP and PC of user's application is in range                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_GoCMD(IAP_APFLASH_START);
    }
    #elif (IAP_DOUBLE_RESET_EN == 1)
    if (CRM->ctrlsts_bit.nrstf == TRUE && CRM->ctrlsts_bit.swrstf == FALSE)
    {
      /* External IO reset.                                                                                 */
      if (HARDWAVE_RESET == HARDWAVE_RESET_FIRST)
      {
        /* The second external IO reset.                                                                    */
        HARDWAVE_RESET = 0;
      }
      else
      {
        /* The first external IO reset, stay in IAP mode.                                                   */
        HARDWAVE_RESET = HARDWAVE_RESET_FIRST;
      }
      crm_flag_clear(CRM_ALL_RESET_FLAG);
    }
    else
    {
      if (BOOT_MODE != BOOT_MODE_IAP)
      {
        crm_flag_clear(CRM_SW_RESET_FLAG);
        /*--------------------------------------------------------------------------------------------------*/
        /* Start user application when                                                                      */
        /*   1. BOOT_MODE != BOOT_MODE_IAP (Default AP) and                                                 */
        /*   2. SP and PC of user's application is in range                                                 */
        /*--------------------------------------------------------------------------------------------------*/
        IAP_JumpToAP(IAP_APFLASH_START);
      }
    }
    #else
    if (BOOT_MODE != BOOT_MODE_IAP)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Start user application when                                                                        */
      /*   1. IO = 1 and                                                                                    */
      /*   2. BOOT_MODE != BOOT_MODE_IAP (Default AP) and                                                   */
      /*   3. SP and PC of user's application is in range                                                   */
      /*----------------------------------------------------------------------------------------------------*/
      IAP_JumpToAP(IAP_APFLASH_START);
    }
    #endif
    SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);
    SYSTICK_SetReloadValue(TIMER_BASE);
    SYSTICK_IntConfig(TRUE);
    SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
    SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
  }
}

/*********************************************************************************************************//**
  * @brief  This function is used to configure NVIC.
  * @retval None
  ***********************************************************************************************************/
void NVIC_Configuration(void)
{
  /* Enable NVIC I2C interrupt                                                                              */
  nvic_irq_enable(HTCFG_IAPI2C_EVT_IRQn, 0, 0);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  crm_periph_clock_enable(HTCFG_IAPI2C_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SCL_GPIO_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SDA_GPIO_CLK, TRUE);
}

/*********************************************************************************************************//**
  * @brief  Configure the GPIO ports.
  * @retval None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
  gpio_pin_mux_config(HTCFG_IAPI2C_SCL_GPIO_PORT, HTCFG_IAPI2C_SCL_GPIO_PinsSource, HTCFG_IAPI2C_SCL_GPIO_MUX);
  gpio_pin_mux_config(HTCFG_IAPI2C_SDA_GPIO_PORT, HTCFG_IAPI2C_SDA_GPIO_PinsSource, HTCFG_IAPI2C_SDA_GPIO_MUX);
}

/*********************************************************************************************************//**
  * @brief  Configures I2C.
  * @retval None
  ***********************************************************************************************************/
void I2C_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  gpio_init_type gpio_init_structure;
  i2c_reset(HTCFG_IAPI2C_PORT);

  /* configure i2c pins: scl */
  gpio_init_structure.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_structure.gpio_mode           = GPIO_MODE_MUX;
  gpio_init_structure.gpio_out_type       = GPIO_OUTPUT_OPEN_DRAIN;
  gpio_init_structure.gpio_pull           = GPIO_PULL_NONE;

  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SCL_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SCL_GPIO_PORT, &gpio_init_structure);

  /* configure i2c pins: sda */
  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SDA_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SDA_GPIO_PORT, &gpio_init_structure);

  /* config i2c */
  i2c_init(HTCFG_IAPI2C_PORT, 0x0F, I2C_CLOCK_SPEED);

  i2c_own_address1_set(HTCFG_IAPI2C_PORT, I2C_ADDRESS_MODE_7BIT, I2C_SLAVE_ADDRESS_IAP << 1);

  /* i2c peripheral enable */
  i2c_enable(HTCFG_IAPI2C_PORT, TRUE);
  i2c_interrupt_enable(HTCFG_IAPI2C_PORT, 
                    I2C_ADDR_INT |
                    I2C_ACKFIAL_INT |
                    I2C_RD_INT,
                    TRUE);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
