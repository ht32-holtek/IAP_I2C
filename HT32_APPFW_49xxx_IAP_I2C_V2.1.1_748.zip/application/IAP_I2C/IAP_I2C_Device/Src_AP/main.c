/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_AP/Src_AP/main.c
 * @version $Rev:: 734          $
 * @date    $Date:: 2025-06-25 #$
 * @brief   The main program of IAP I2C Device example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "iap_protocol.h"
#include "i2c_config.h"
#include "wdt_config.h"
#include "common\ring_buffer.h"
#include "common\ht32_misc.h"

/* Dependency check ----------------------------------------------------------------------------------------*/
#if defined(__HT32F490x1_H)
#define MIN_HT32_FWLIB_VER              (0x01001002) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x78)
#endif
#if defined(__HT32F491x3_H)
#define MIN_HT32_FWLIB_VER              (0x01000006) //0xmmnnnrrr -> Vm.n.r
#define MIN_HT32_FWLIB_SVN              (0x131)
#endif
#include "ht32_dependency.h" // Not exist means the version of HT32 Firmware Library is older than the module required.

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_AP Application example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define TIMER_BASE                    (SystemCoreClock / 8 / 1000)       /* 1 ms                            */
#define IAP_CMD_TIMEOUT_RESULT        50

/* Private function prototypes -----------------------------------------------------------------------------*/
void NVIC_Configuration(void);
void CKCU_Configuration(void);
void GPIO_Configuration(void);
void I2C_Configuration(void);
void CheckIAPCommand(void);

/* Global variables ----------------------------------------------------------------------------------------*/
vu32 isTxFinish = FALSE;
__ALIGN4 u8 guTxBuffer[TX_BUFFER_SIZE + 1];
__ALIGN4 u8 guRxBuffer[RX_BUFFER_SIZE + 1];
Buffer_TypeDef gTx;
Buffer_TypeDef gRx;

vs32 gIAPCmdTimeout;

/* Private variables ---------------------------------------------------------------------------------------*/
__ALIGN4 static u8 gu8CommandBuffer[IAP_CODE_LENGTH];
static u32 u32CommandIndex = 0;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  system_clock_config();
  #if ENABLE_WDT
  wdt_register_write_enable(TRUE);
  wdt_divider_set(WDT_CLK_DIV_64);
  /* set reload value

   timeout = reload_value * (divider / lick_freq )    (s)

   lick_freq    = 40000 Hz
   divider      = 64
   reload_value = 2500

   timeout = 2500 * (64 / 40000 ) = 4s
  */
  wdt_reload_value_set(2500);
  wdt_counter_reload();
  wdt_enable();
  #endif
  /*--------------------------------------------------------------------------------------------------------*/
  /* Reset BOOT_MODE which set by IAP, to avoid start AP again                                              */
  /*--------------------------------------------------------------------------------------------------------*/
  BOOT_MODE = 0;

  /*--------------------------------------------------------------------------------------------------------*/
  /* Init Buffer for I2C slave transmission                                                                 */
  /*--------------------------------------------------------------------------------------------------------*/
  Buffer_Init(&gTx, guTxBuffer, sizeof(guTxBuffer));
  Buffer_Init(&gRx, guRxBuffer, sizeof(guRxBuffer));

  NVIC_Configuration();
  CKCU_Configuration();
  GPIO_Configuration();
  I2C_Configuration();
  uart_print_init(115200);

  ht32_led_init(LED2);

  SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);
  SYSTICK_SetReloadValue(TIMER_BASE);
  SYSTICK_IntConfig(TRUE);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);

  while (1)
  {
    WDT_RST();
    CheckIAPCommand();
    printf("Hello World!\n\r");
  }
}

/*********************************************************************************************************//**
  * @brief  Check IAP command.
  * @retval None
  ***********************************************************************************************************/
void CheckIAPCommand(void)
{
  u8 uData;
  u32 uResult;
  IAP_Protocol_TypeDef *pCMD = (IAP_Protocol_TypeDef *)gu8CommandBuffer;

  uResult = Buffer_ReadByte(&gRx, &uData);
  if (uResult)
  {
    gu8CommandBuffer[u32CommandIndex++] = uData;
    while (u32CommandIndex < IAP_CODE_LENGTH)
    if (Buffer_ReadByte(&gRx, &uData))
    {
      gu8CommandBuffer[u32CommandIndex++] = uData;
    }
  }
  if (u32CommandIndex == IAP_CODE_LENGTH)
  {
    bool result = TRUE;
    /*------------------------------------------------------------------------------------------------------*/
    /* Check command after received enough bytes                                                            */
    /*------------------------------------------------------------------------------------------------------*/
    u32CommandIndex = 0;            /* Reset Command index for next command                                 */
    if ((pCMD->Code == IAP_CMD_START_IAP) && (pCMD->Code + pCMD->Check) == IAP_CMDVALID)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Command is valid, Response to Host and start IAP mode                                              */
      /*----------------------------------------------------------------------------------------------------*/
      pCMD->Code = IAP_RET_OK;
      pCMD->Check = (IAP_CODE_Enum)(~IAP_RET_OK);
      isTxFinish = FALSE;

      gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESULT;
      Buffer_Write(&gTx, gu8CommandBuffer, IAP_CODE_LENGTH);
      i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_TD_INT, TRUE);
      while (!Buffer_isEmpty(&gTx) || isTxFinish == FALSE)
      {
        if(gIAPCmdTimeout == 0)
        {
          i2c_reset(HTCFG_IAPI2C_PORT);
          I2C_Configuration();
          result = FALSE;
          break;
        }
        WDT_RST();
      }
      if(result == TRUE)
      {
        i2c_enable(HTCFG_IAPI2C_PORT, FALSE);

        /*----------------------------------------------------------------------------------------------------*/
        /* Set BOOT_MODE as BOOT_MODE_IAP and trigger a reset to start IAP mode. BOOT_MODE only reset by      */
        /* Power-on-reset.                                                                                    */
        /*----------------------------------------------------------------------------------------------------*/
        BOOT_MODE = BOOT_MODE_IAP;
        NVIC_SystemReset();           /* Trigger reset                                                        */
      }
    }
  }
}

/*********************************************************************************************************//**
  * @brief  Configure NVIC vector table.
  * @retval None
  ***********************************************************************************************************/
void NVIC_Configuration(void)
{
  nvic_vector_table_set(FLASH_BASE, IAP_APFLASH_START); /* Set Vector Table Offset                  */

  /* Enable NVIC I2C interrupt                                                                              */
  nvic_irq_enable(HTCFG_IAPI2C_EVT_IRQn, 0, 0);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  crm_periph_clock_enable(HTCFG_IAPI2C_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SCL_GPIO_CLK, TRUE);
  crm_periph_clock_enable(HTCFG_IAPI2C_SDA_GPIO_CLK, TRUE);
}

/*********************************************************************************************************//**
  * @brief  Configure the GPIO ports.
  * @retval None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
  /* Configure GPIO as I2C mode                                                                             */
  gpio_pin_mux_config(HTCFG_IAPI2C_SCL_GPIO_PORT, HTCFG_IAPI2C_SCL_GPIO_PinsSource, HTCFG_IAPI2C_SCL_GPIO_MUX);
  gpio_pin_mux_config(HTCFG_IAPI2C_SDA_GPIO_PORT, HTCFG_IAPI2C_SDA_GPIO_PinsSource, HTCFG_IAPI2C_SDA_GPIO_MUX);
}

/*********************************************************************************************************//**
  * @brief  Configure I2C.
  * @retval None
  ***********************************************************************************************************/
void I2C_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  gpio_init_type gpio_init_structure;
  i2c_reset(HTCFG_IAPI2C_PORT);

  /* configure i2c pins: scl */
  gpio_init_structure.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_structure.gpio_mode           = GPIO_MODE_MUX;
  gpio_init_structure.gpio_out_type       = GPIO_OUTPUT_OPEN_DRAIN;
  gpio_init_structure.gpio_pull           = GPIO_PULL_NONE;

  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SCL_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SCL_GPIO_PORT, &gpio_init_structure);

  /* configure i2c pins: sda */
  gpio_init_structure.gpio_pins           = HTCFG_IAPI2C_SDA_GPIO_PIN;
  gpio_init(HTCFG_IAPI2C_SDA_GPIO_PORT, &gpio_init_structure);

  /* config i2c */
  i2c_init(HTCFG_IAPI2C_PORT, 0x0F, I2C_CLOCK_SPEED);

  i2c_own_address1_set(HTCFG_IAPI2C_PORT, I2C_ADDRESS_MODE_7BIT, I2C_SLAVE_ADDRESS_AP << 1);

  /* i2c peripheral enable */
  i2c_enable(HTCFG_IAPI2C_PORT, TRUE);
  i2c_interrupt_enable(HTCFG_IAPI2C_PORT,
                      I2C_ADDR_INT |
                      I2C_ACKFIAL_INT |
                      I2C_RD_INT,
                      TRUE);
  i2c_ack_enable(HTCFG_IAPI2C_PORT, TRUE);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
