/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_AP/ht32f491x3_int.c
 * @version $Rev:: 560         $
 * @date    $Date:: 2025-05-28 #$
 * @brief   This file provides all interrupt service routine.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32f491x3_board.h"
#include "ht32_board_config.h"
#include "i2c_config.h"
#include "common\ring_buffer.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_IAP IAP example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define LED_DELAY_COUNTER       500 /* 500ms */

/* Global variables ----------------------------------------------------------------------------------------*/
extern vs32 gIAPCmdTimeout;

/* Private variables ---------------------------------------------------------------------------------------*/
volatile bool gRestartFlag = FALSE;

/* Global functions ----------------------------------------------------------------------------------------*/
/**
  * @brief  this function handles nmi exception.
  * @param  none
  * @retval none
  */
void NMI_Handler(void)
{
}

/**
  * @brief  this function handles hard fault exception.
  * @param  none
  * @retval none
  */
void HardFault_Handler(void)
{
  /* go to infinite loop when hard fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles memory manage exception.
  * @param  none
  * @retval none
  */
void MemManage_Handler(void)
{
  /* go to infinite loop when memory manage exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles bus fault exception.
  * @param  none
  * @retval none
  */
void BusFault_Handler(void)
{
  /* go to infinite loop when bus fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles usage fault exception.
  * @param  none
  * @retval none
  */
void UsageFault_Handler(void)
{
  /* go to infinite loop when usage fault exception occurs */
  while(1)
  {
  }
}

/**
  * @brief  this function handles svcall exception.
  * @param  none
  * @retval none
  */
void SVC_Handler(void)
{
}

/**
  * @brief  this function handles debug monitor exception.
  * @param  none
  * @retval none
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  this function handles pendsv_handler exception.
  * @param  none
  * @retval none
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  this function handles systick handler.
  * @param  none
  * @retval none
  */
void SysTick_Handler(void)
{
  static u32 LedFlag = 0;
  static u32 uLEDDelayCounter = LED_DELAY_COUNTER;
  if(uLEDDelayCounter >0)
  {
    uLEDDelayCounter--;
  }
  else
  {
    if(LedFlag == 0)
    {
      LedFlag = 1;
    ht32_led_on(LED2);
    }
    else
    {
      LedFlag = 0;
    ht32_led_off(LED2);
    }
    uLEDDelayCounter = LED_DELAY_COUNTER;
  }
  if(gIAPCmdTimeout>0)
    gIAPCmdTimeout--;
}

/**
  * @brief  this function handles i2c event interrupt request.
  * @param  none
  * @retval none
  */
void HTCFG_IAPI2C_EVT_IRQHandler(void)
{
  extern Buffer_TypeDef gTx;
  extern Buffer_TypeDef gRx;
  extern vu32 isTxFinish;
  u8 uData;
  u32 uResult;

  uResult = HTCFG_IAPI2C_PORT->sts & 0x1FFFF;
  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ADDRF_FLAG);
  i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_STOPF_FLAG);

  /*----------------------------- Error Process ------------------------------------------------------------*/
  if(uResult & I2C_BUSERR_FLAG)
  {
    Buffer_Discard(&gRx);
    Buffer_Discard(&gTx);
    i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_BUSERR_FLAG);
  }
  /*----------------------------- Stop Process -------------------------------------------------------------*/
  if(uResult & I2C_STOPF_FLAG)
  {
    if(uResult & I2C_RDBF_FLAG)
    {
      /* Rx not empty                                                                                       */
      gRestartFlag = FALSE;
      /* Receive data sent from I2C                                                                         */
      Buffer_WriteByte(&gRx, i2c_data_receive(HTCFG_IAPI2C_PORT));
    }
    if((uResult == I2C_STOPF_FLAG) ||
       (uResult ==  (I2C_BUSYF_FLAG|I2C_STOPF_FLAG|I2C_ADDRF_FLAG)) ||
       (uResult & I2C_RDBF_FLAG))
    {
      gRestartFlag = FALSE;
    }
  }
  else if (uResult & I2C_ACKFAIL_FLAG)
  {
    /* Clear RXNACK flag                                                                                    */
    i2c_flag_clear(HTCFG_IAPI2C_PORT, I2C_ACKFAIL_FLAG);
    isTxFinish = TRUE;
  }
  /*-----------------------------Rx Process ----------------------------------------------------------------*/
  else if(uResult & I2C_RDBF_FLAG)
  {
    if((uResult&I2C_ADDRF_FLAG) || (uResult&I2C_TDBE_FLAG)==0)
    {
      /* Restart Mode                                                                                       */
      gRestartFlag = TRUE;
      Buffer_WriteByte(&gRx, i2c_data_receive(HTCFG_IAPI2C_PORT));
    }
    else if(uResult&I2C_RDBF_FLAG)
    {
      /* Rx buffer full                                                                                     */
      Buffer_WriteByte(&gRx, i2c_data_receive(HTCFG_IAPI2C_PORT));
    }
  }
  /*-----------------------------Tx Process ----------------------------------------------------------------*/
  else if(uResult & I2C_TDBE_FLAG && !(uResult & I2C_ADDRF_FLAG))
  {
    if(gRestartFlag == TRUE)
    {
      /* Restart Mode                                                                                       */
      gRestartFlag = FALSE;
    }
    if (Buffer_ReadByte(&gTx, &uData))
    {
      /* Send the remainder data to Master                                                                  */
      i2c_data_send(HTCFG_IAPI2C_PORT, uData);
    }
    else
    {
      /* Tx Buffer is empty                                                                                 */
      #if (I2C_ENABLE_DUMMY_DATA == 1)
        i2c_data_send(HTCFG_IAPI2C_PORT, I2C_DUMMY_DATA_VALUE);
      #else
        i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_TD_INT, FALSE);
      #endif
    }
  }
  else if(uResult & (I2C_ADDRF_FLAG | I2C_SDIR_FLAG)){
    i2c_interrupt_enable(HTCFG_IAPI2C_PORT, I2C_TD_INT, TRUE);
  }
}


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
