/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/ht32_board_config.h
 * @version $Rev:: 583          $
 * @date    $Date:: 2025-06-09 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
#define IAP_CODE_SIZE                             (1024 * 10)        /* IAP code size in Bytes              */

#define IAP_APFLASH_SIZE                          (LIBCFG_FLASH_SIZE)
#define IAP_APSRAM_SIZE                           (LIBCFG_RAM_SIZE)

#define IAP_APFLASH_START                         (FLASH_BASE + IAP_CODE_SIZE)
#define IAP_APSRAM_START                          (SRAM_BASE)

#define IAP_VER_ADDR                              (0x00000010)       /* AP Version address                  */
#define IAP_VERFLASH_START                        (IAP_APFLASH_START + IAP_VER_ADDR)

#define BOOT_MODE_AP                              (0x55AAFAF0)
#define BOOT_MODE_IAP                             (0x55AAFAF5)
#define BOOT_MODE_ID_ADDR                         (SRAM_BASE)

#define BOOT_MODE                                 ((*((u32 volatile *) (BOOT_MODE_ID_ADDR))))

#define HARDWAVE_RESET_FIRST                      (0x55AAFBF0)
#define HARDWAVE_RESET                            ((*((u32 volatile *) (BOOT_MODE_ID_ADDR + 4))))

#if defined(USE_HT32F49041_SK)
//  #define I2C_CLOCK_SPEED                    0x80E02E2E      //100KHz
  #define I2C_CLOCK_SPEED                    0x10B0233E      //400KHz

  #define HTCFG_IAPI2C_PORT                       I2C1
  #define HTCFG_IAPI2C_CLK                        CRM_I2C1_PERIPH_CLOCK

  #define HTCFG_IAPI2C_SCL_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SCL_GPIO_PIN               GPIO_PINS_6
  #define HTCFG_IAPI2C_SCL_GPIO_PinsSource        GPIO_PINS_SOURCE6
  #define HTCFG_IAPI2C_SCL_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SCL_GPIO_MUX               GPIO_MUX_1

  #define HTCFG_IAPI2C_SDA_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SDA_GPIO_PIN               GPIO_PINS_7
  #define HTCFG_IAPI2C_SDA_GPIO_PinsSource        GPIO_PINS_SOURCE7
  #define HTCFG_IAPI2C_SDA_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SDA_GPIO_MUX               GPIO_MUX_1

  #define HTCFG_IAPI2C_EVT_IRQn                   I2C1_EVT_IRQn
  #define HTCFG_IAPI2C_ERR_IRQn                   I2C1_ERR_IRQn

  #define HTCFG_IAPI2C_EVT_IRQHandler             I2C1_EVT_IRQHandler
  #define HTCFG_IAPI2C_ERR_IRQHandler             I2C1_ERR_IRQHandler
#endif

#if defined(USE_HT32F49163_SK)
//  #define I2C_CLOCK_SPEED                    0x60E02C2C      //100KHz
  #define I2C_CLOCK_SPEED                    0x10C0172A      //400KHz

  #define HTCFG_IAPI2C_PORT                       I2C1
  #define HTCFG_IAPI2C_CLK                        CRM_I2C1_PERIPH_CLOCK

  #define HTCFG_IAPI2C_SCL_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SCL_GPIO_PIN               GPIO_PINS_6
  #define HTCFG_IAPI2C_SCL_GPIO_PinsSource        GPIO_PINS_SOURCE6
  #define HTCFG_IAPI2C_SCL_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SCL_GPIO_MUX               GPIO_MUX_4

  #define HTCFG_IAPI2C_SDA_GPIO_CLK               CRM_GPIOB_PERIPH_CLOCK
  #define HTCFG_IAPI2C_SDA_GPIO_PIN               GPIO_PINS_7
  #define HTCFG_IAPI2C_SDA_GPIO_PinsSource        GPIO_PINS_SOURCE7
  #define HTCFG_IAPI2C_SDA_GPIO_PORT              GPIOB
  #define HTCFG_IAPI2C_SDA_GPIO_MUX               GPIO_MUX_4

  #define HTCFG_IAPI2C_EVT_IRQn                   I2C1_EVT_IRQn
  #define HTCFG_IAPI2C_ERR_IRQn                   I2C1_ERR_IRQn

  #define HTCFG_IAPI2C_EVT_IRQHandler             I2C1_EVT_IRQHandler
  #define HTCFG_IAPI2C_ERR_IRQHandler             I2C1_ERR_IRQHandler
#endif

#ifdef __cplusplus
}
#endif

#endif
