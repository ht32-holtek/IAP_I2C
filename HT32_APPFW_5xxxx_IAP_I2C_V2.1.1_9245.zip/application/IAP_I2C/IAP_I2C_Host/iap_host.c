/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/iap_host.c
 * @version $Rev:: 9241         $
 * @date    $Date:: 2025-06-26 #$
 * @brief   The IAP Host - I2c example code.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board_config.h"
#include "iap_host.h"
#include "iap_config.h"
#include "i2c_buffer.h"
#include "crc16.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define __DBG_IAPPrintf(...)

#if (IAP_DEBUG_MODE == 1)
  #undef __DBG_IAPPrintf
  #define __DBG_IAPPrintf printf
#endif

#define IAP_PARA_START                (IAP_CODE_LENGTH)
#define IAP_APFLASH_START             (IAP_CODE_SIZE)
#define IAP_APFLASH_SIZE              (1024 * 10)

#define IAP_DATA_START                (0x1FF00050)
#define IAP_DATA_SIZE                 (944)


#if defined(__ARMCC_VERSION)   // Keil
#define AP_CODE_SIZE                  (Image$$AP$$Length)
extern void AP_CODE_SIZE;
#define GET_AP_CODE_SIZE    ((uint32_t)&AP_CODE_SIZE)
#elif defined(__GNUC__)        // HT32-IDE
extern unsigned char AP_CODE_SIZE_START;
extern unsigned char AP_CODE_SIZE_END;
#define GET_AP_CODE_SIZE    ((uint32_t)(&AP_CODE_SIZE_END - &AP_CODE_SIZE_START))
#endif


#define IAP_CRC_ADDR                  (0x00000020)                  /* Addr for Start AP CRC check (2 Word) */
#define IAP_CRC_KEY                   (0x1A0C0000)                  /* key for enable Start AP CRC check    */

#define IAP_PROGRAM_FLOW             (2)
#define IAP_FIRST_PROGRAM_SIZE       (56)

/* Private function prototypes -----------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Global variables ----------------------------------------------------------------------------------------*/
u32 gTargetMCUPageSize;
u32 gTargetVerAddr;
u32 gTargetAPAddr = IAP_APFLASH_START;

#if ENGINNER_MODE3
u8 ENGINNER_MODE3_GetRET_Length        = IAP_CODE_LENGTH;
u8 ENGINNER_MODE3_IAP_DATA_PACKET_SIZE = IAP_DATA_PACKET_SIZE;
#endif

/* Private variables ---------------------------------------------------------------------------------------*/
/* Global functions ----------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Start IAP.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_StartIAP(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;

  __DBG_IAPPrintf("Start IAP mode.....\n\r");

  Command.Code = IAP_CMD_START_IAP;
  Command.uLength = 0;

  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Start Application.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_StartAP(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;

  __DBG_IAPPrintf("Start AP mode.....\n\r");

  Command.Code = IAP_CMD_START_APP;
  Command.uLength = 0;

  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Erase.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_Erase(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;

  __DBG_IAPPrintf("Erase.....\n\r");

  Command.Code = IAP_CMD_ERASE;
  Command.uLength = 12;
  Command.uPara = 0;
  Command.uStAddr = gTargetAPAddr;
  Command.uEndAddr = gTargetAPAddr + (u32)(GET_AP_CODE_SIZE) - 1;

  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Erase Option Byte.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_EraseOB(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;

  __DBG_IAPPrintf("Erase Option.....\n\r");

  Command.Code = IAP_CMD_ERASE;
  Command.uLength = 12;
  Command.uPara = 0;
  Command.uStAddr = 0x1FF00000;
  /* Option Byte EndAddr is determined by SLAVE_FLASH_PAGE_SIZE value, please configure from iap_config.h   */
  Command.uEndAddr = Command.uStAddr + SLAVE_FLASH_PAGE_SIZE - 1;

  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Program AP.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_FlashProgramAP(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE + 2];
  u32 *puSource;
  u32 *puDes;
  u16 *puCRC = (u16 *)&uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 i,j;
  u32 uTotalLength = 0;
  u32 ProgramFlowStartAddrEndAddrTable[IAP_PROGRAM_FLOW][2];

  /* Row 0: Application (AP) code: IAP_FIRST_PROGRAM_SIZE ~ End of AP code                                  */
  ProgramFlowStartAddrEndAddrTable[0][0] = IAP_FIRST_PROGRAM_SIZE;    /* Start addr: IAP_FIRST_PROGRAM_SIZE */
  ProgramFlowStartAddrEndAddrTable[0][1] = (u32)(GET_AP_CODE_SIZE) - 1;  /* End addr: end of AP code, defined  */
                                                                      /* in the linker script.              */

  /* Row 1: Application (AP) code: 0 ~ (IAP_FIRST_PROGRAM_SIZE - 1)                                         */
  ProgramFlowStartAddrEndAddrTable[1][0] = 0;                          /* Start address: 0 (beginning of AP code) */
  ProgramFlowStartAddrEndAddrTable[1][1] = IAP_FIRST_PROGRAM_SIZE - 1; /* End address: IAP_FIRST_PROGRAM_SIZE - 1 */

  __DBG_IAPPrintf("Program AP.....\n\r");
  for(j = 0; j < IAP_PROGRAM_FLOW ; j++)
  {
    Command.uStAddr = gTargetAPAddr + ProgramFlowStartAddrEndAddrTable[j][0];
    puSource = (u32 *)(AP_IMAGE_ADDRESS + ProgramFlowStartAddrEndAddrTable[j][0]);

    Command.Code = IAP_CMD_FLASH;
    Command.uLength = 12;
    Command.uPara = IAP_PARA_PROGRAM;
    Command.uEndAddr = gTargetAPAddr + ProgramFlowStartAddrEndAddrTable[j][1];
    Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
    if (Result != IAP_OK)
    {
      return Result;
    }

    while (1)
    {
      puDes = (u32 *)uDataBuffer;

      /* Read one packet of AP image from Flash to buffer                                                   */
      for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
      {
        *puDes = *puSource;
        puDes++;
        puSource++;
      }

      /* Calculate CRC value of data                                                                        */
      *puCRC = CRC16(0, uDataBuffer, IAP_DATA_PACKET_SIZE);
      #if ENGINNER_MODE3
      Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, ENGINNER_MODE3_IAP_DATA_PACKET_SIZE + 2, uTimeout);
      #else
      Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, IAP_DATA_PACKET_SIZE + 2, uTimeout);
      #endif
      if (Result != IAP_OK)
      {
        return Result;
      }
      uTotalLength += IAP_DATA_PACKET_SIZE;
      if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
      {
        break;
      }
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Verify AP.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_FlashVerifyAP(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE + 2];
  u32 *puSource;
  u32 *puDes;
  u16 *puCRC = (u16 *)&uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 i;
  u32 uTotalLength = 0;

  __DBG_IAPPrintf("Verify AP.....\n\r");
  Command.uStAddr = gTargetAPAddr;
  puSource = (u32 *)(AP_IMAGE_ADDRESS);

  Command.Code = IAP_CMD_FLASH;
  Command.uLength = 12;
  Command.uPara = IAP_PARA_VERIFY;
  Command.uEndAddr = gTargetAPAddr + (u32)(GET_AP_CODE_SIZE) - 1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  while (1)
  {
    puDes = (u32 *)uDataBuffer;

    /* Read one packet of AP image from Flash to buffer                                                     */
    for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
    {
      *puDes = *puSource;
      puDes++;
      puSource++;
    }

    /* Calculate CRC value of data                                                                          */
    *puCRC = CRC16(0, uDataBuffer, IAP_DATA_PACKET_SIZE);
    #if ENGINNER_MODE3
    Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, ENGINNER_MODE3_IAP_DATA_PACKET_SIZE + 2, uTimeout);
    #else
    Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, IAP_DATA_PACKET_SIZE + 2, uTimeout);
    #endif
    if (Result != IAP_OK)
    {
      return Result;
    }
    uTotalLength += IAP_DATA_PACKET_SIZE;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Submit CRC value to User Data in Option Byte Area
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_SubmitCRCAP(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE + 2];
  /* Skip first 40 Bytes since AP_CRC and AP_LENGTH locate in it                                            */
  u8 *puSource = (u8 *)AP_IMAGE_ADDRESS;
  unsigned int uLength = (u32)GET_AP_CODE_SIZE;
  u16 *puCRC = (u16 *)&uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 *ptr = (u32 *)&uDataBuffer[0];
  u16 uCRC;

  uCRC = CRC16(0, puSource, uLength);
  __DBG_IAPPrintf("Submit CRC AP[%04X][%d].....\n\r", uCRC, uLength);

  *ptr = IAP_CRC_KEY | uCRC;
  ptr++;
  *ptr = uLength;

  Command.Code = IAP_CMD_FLASH;
  Command.uLength = 12;
  Command.uPara = 0;
  Command.uStAddr  = gTargetAPAddr + IAP_CRC_ADDR;
  Command.uEndAddr = Command.uStAddr + 8 - 1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  *puCRC = CRC16(0, uDataBuffer, IAP_DATA_PACKET_SIZE);
  Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, IAP_DATA_PACKET_SIZE + 2, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Program or Verify Dummy.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @param  uType: Operation type
  *         @arg IAP_PARA_PROGRAM: Program
  *         @arg IAP_PARA_VERIFY: Verify
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_FlashDummy(u32 uI2CSlaveAddress, u32 uTimeout, IAP_PARA_Enum uType)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE + 2];
  u32 *puDes;
  u16 *puCRC = (u16 *)&uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 i;
  u32 uTotalLength = 0;

  if (uType == IAP_PARA_PROGRAM)
  {
    __DBG_IAPPrintf("Program Dummy.....\n\r");
  }
  else
  {
    __DBG_IAPPrintf("Verify Dummy.....\n\r");
  }

  Command.Code = IAP_CMD_FLASH;
  Command.uLength = 12;
  Command.uPara = uType;
  Command.uStAddr = gTargetAPAddr + 0x400;
  Command.uEndAddr = gTargetAPAddr + 0x800 - 1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  while (1)
  {
    puDes = (u32 *)uDataBuffer;
    for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
    {
      *puDes = gTargetAPAddr + uTotalLength + i;
      puDes++;
    }
    *puCRC = CRC16(0, uDataBuffer, IAP_DATA_PACKET_SIZE);

    Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, IAP_DATA_PACKET_SIZE + 2, uTimeout);
    if (Result != IAP_OK)
    {
      return Result;
    }

    uTotalLength += IAP_DATA_PACKET_SIZE;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Program or Verify Data.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @param  uType: Operation type
  *         @arg IAP_PARA_PROGRAM: Program
  *         @arg IAP_PARA_VERIFY: Verify
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_FlashData(u32 uI2CSlaveAddress, u32 uTimeout, IAP_PARA_Enum uType)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE + 2];
  u32 *puDes;
  u16 *puCRC = (u16 *)&uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 i;
  u32 uTotalLength = 0;

  if (uType == IAP_PARA_PROGRAM)
  {
    __DBG_IAPPrintf("Program Data.....\n\r");
  }
  else
  {
    __DBG_IAPPrintf("Verify Data.....\n\r");
  }

  Command.Code = IAP_CMD_FLASH;
  Command.uLength = 12;
  Command.uPara = uType;
  Command.uStAddr = IAP_DATA_START;
  Command.uEndAddr = Command.uStAddr + 128 * 7 - 1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  while (1)
  {
    puDes = (u32 *)uDataBuffer;
    for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
    {
      *puDes = Command.uStAddr + uTotalLength + i;
      puDes++;
    }
    *puCRC = CRC16(0, uDataBuffer, IAP_DATA_PACKET_SIZE);

    Result = IAP_SendData(uI2CSlaveAddress, uDataBuffer, IAP_DATA_PACKET_SIZE + 2, uTimeout);
    if (Result != IAP_OK)
    {
      return Result;
    }

    uTotalLength += IAP_DATA_PACKET_SIZE;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  CRC Checking for AP.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_CRCAP(u32 uI2CSlaveAddress, u32 uTimeout, u32 skipByte)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;

  /* Skip first 40 Bytes since AP_CRC and AP_LENGTH locate in it                                            */
  u8 *puSource = (u8 *)AP_IMAGE_ADDRESS + skipByte;
  unsigned int uLength = (u32)GET_AP_CODE_SIZE;
  u16 uCRC;

  uLength -= skipByte;
  uCRC = CRC16(0, puSource, uLength);
  __DBG_IAPPrintf("CRC AP[%04X][%d].....\n\r", uCRC, uLength);

  Command.Code = IAP_CMD_CRC;
  Command.uLength = 12;
  Command.uPara = 0;

  /* Skip first 40 Bytes since AP_CRC and AP_LENGTH locate in it                                            */
  Command.uStAddr = gTargetAPAddr + skipByte;
  Command.uEndAddr = gTargetAPAddr + (u32)(GET_AP_CODE_SIZE) - 1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }
  Result = IAP_SendData(uI2CSlaveAddress, (u8 *)&uCRC, 2, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  CRC Checking for Dummy.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_CRCDummy(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 *puDes;
  unsigned int uCRC = 0;
  u32 i;
  u32 uTotalLength = 0;

  Command.Code = IAP_CMD_CRC;
  Command.uLength = 12;
  Command.uPara = 0;
  Command.uStAddr = gTargetAPAddr + 0x400;
  Command.uEndAddr = gTargetAPAddr + 0x800 - 1;

  while (1)
  {
    puDes = (u32 *)uDataBuffer;
    for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
    {
      *puDes = gTargetAPAddr + uTotalLength + i;
      puDes++;
    }
    uCRC = CRC16(uCRC, uDataBuffer, IAP_DATA_PACKET_SIZE);

    uTotalLength += IAP_DATA_PACKET_SIZE;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
  }

  __DBG_IAPPrintf("CRC Dummy[%04X].....\n\r", uCRC);
  
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }
  Result = IAP_SendData(uI2CSlaveAddress, (u8 *)&uCRC, 2, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  CRC Checking for Data.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_CRCData(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u8 uDataBuffer[IAP_DATA_PACKET_SIZE];
  u32 *puDes;
  unsigned int uCRC = 0;
  u32 i;
  u32 uTotalLength = 0;

  Command.Code = IAP_CMD_CRC;
  Command.uLength = 12;
  Command.uPara = 0;
  Command.uStAddr = IAP_DATA_START;
  Command.uEndAddr = Command.uStAddr + 128 * 7 - 1;

  while (1)
  {
    puDes = (u32 *)uDataBuffer;
    for (i = 0; i < IAP_DATA_PACKET_SIZE; i += 4)
    {
      *puDes = IAP_DATA_START + uTotalLength + i;
      puDes++;
    }
    uCRC = CRC16(uCRC, uDataBuffer, IAP_DATA_PACKET_SIZE);

    uTotalLength += IAP_DATA_PACKET_SIZE;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
  }

  __DBG_IAPPrintf("CRC Data[%04X].....\n\r", uCRC);


  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }
  Result = IAP_SendData(uI2CSlaveAddress, (u8 *)&uCRC, 2, uTimeout);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Send Command.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  pCmd: Pointer of IAP_Protocol_TypeDef
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_SendCommand(u32 uI2CSlaveAddress, IAP_Protocol_TypeDef *pCmd, u32 uTimeout)
{
  IAP_Status Result;
  I2CBuffer_Status_Enum BufferResult;
  I2CBuffer_InitTypedef I2CBuffer;
  u8* puBuffer = (u8 *)pCmd;
  #if ENGINNER_MODE2
  u8 retryNum = 0;
  #else
  u8 retryNum = 3;
  #endif
  do
  {
    __DBG_IAPPrintf("Send IAP Command.....");

    pCmd->Check = (IAP_CODE_Enum)(~pCmd->Code);
    if (pCmd->uLength != 0)
    {
      pCmd->uCRC = 0;
      pCmd->uCRC = CRC16(0, &puBuffer[IAP_PARA_START], pCmd->uLength);
    }

    I2CBuffer.uTimeout = uTimeout;
    I2CBuffer.uSlaveAddress = uI2CSlaveAddress;
    I2CBuffer.puBuffer = (u8 *)pCmd;
    I2CBuffer.uLength = IAP_CODE_LENGTH + pCmd->uLength;
    I2CBuffer.Command = I2C_BUFFER_WRITE;

    I2CBuffer_Start(&I2CBuffer);
    while (1)
    {
      BufferResult = I2CBuffer_GetStatus();
      if (BufferResult != I2C_BUFFER_GOING)
      {
        break;
      }
    }

    if (BufferResult == I2C_BUFFER_TIMEOUT)
    {
      __DBG_IAPPrintf("\t[Timeout]\n\r");
      Result = IAP_TIMEOUT;
    }
    else
    {
      __DBG_IAPPrintf("\t[Done]\n\r");
      /*------------------------------------------------------------------------------------------------------*/
      /* Add 2 ms delay to ensure that:                                                                       */
      /*   1. Device is ready for response or                                                                 */
      /*   2. Device already change its Slave address for waiting mode (Erase command)                        */
      /*------------------------------------------------------------------------------------------------------*/
      I2CBuffer_Delay(2);
      Result = IAP_CheckDeviceReady(uI2CSlaveAddress, uTimeout);
      if (Result == IAP_OK)
      {
        Result = IAP_GetRET(uI2CSlaveAddress, uTimeout);
      }
    }

    /* Add delay to ensure that all operation of device is finished. Especially for device reset.           */
    I2CBuffer_Delay(10);
  }while(Result == IAP_RETDUMMY && retryNum--);

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Send Data.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  puBuffer: Pointer of data
  * @param  uLength: Length of data
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_SendData(u32 uI2CSlaveAddress, u8 *puBuffer, u32 uLength, u32 uTimeout)
{
  IAP_Status Result;
  I2CBuffer_Status_Enum BufferResult;
  I2CBuffer_InitTypedef I2CBuffer;

  __DBG_IAPPrintf("Send Data .....");

  I2CBuffer.uTimeout = uTimeout;
  I2CBuffer.uSlaveAddress = uI2CSlaveAddress;
  I2CBuffer.puBuffer = puBuffer;
  I2CBuffer.uLength = uLength;
  I2CBuffer.Command = I2C_BUFFER_WRITE;
  I2CBuffer_Start(&I2CBuffer);
  while (1)
  {
    BufferResult = I2CBuffer_GetStatus();
    if (BufferResult != I2C_BUFFER_GOING)
    {
      break;
    }
  }

  if (BufferResult == I2C_BUFFER_TIMEOUT)
  {
    __DBG_IAPPrintf("\t[Timeout]\n\r");
    Result = IAP_TIMEOUT;
  }
  else
  {
    __DBG_IAPPrintf("\t\t[Done]\n\r");
    Result = IAP_CheckDeviceReady(uI2CSlaveAddress, uTimeout);
    if (Result == IAP_OK)
    {
      Result = IAP_GetRET(uI2CSlaveAddress, uTimeout);
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Get return value.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_GetRET(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result = IAP_OK;
  I2CBuffer_Status_Enum BufferResult;
  I2CBuffer_InitTypedef I2CBuffer;
  IAP_Protocol_TypeDef RetValue;

  __DBG_IAPPrintf("Receive response .....");

  I2CBuffer.uTimeout = uTimeout;
  I2CBuffer.uSlaveAddress = uI2CSlaveAddress;
  I2CBuffer.puBuffer = (u8 *)&RetValue;
  #if ENGINNER_MODE3
  I2CBuffer.uLength = ENGINNER_MODE3_GetRET_Length;
  #else
  I2CBuffer.uLength = IAP_CODE_LENGTH;
  #endif
  I2CBuffer.Command = I2C_BUFFER_READ;
  I2CBuffer_Start(&I2CBuffer);

  while (1)
  {
    BufferResult = I2CBuffer_GetStatus();
    if (BufferResult != I2C_BUFFER_GOING)
    {
      break;
    }
  }

  if (BufferResult == I2C_BUFFER_TIMEOUT)
  {
    Result = IAP_TIMEOUT;
    __DBG_IAPPrintf("\t[Timeout]\n\r");
  }
  else
  {
    if (RetValue.Code + RetValue.Check == IAP_CMDVALID)
    {
      switch (RetValue.Code)
      {
        case IAP_RET_OK:
        {
          __DBG_IAPPrintf("\t[OK][%x]\n\r", RetValue.Code);
          break;
        }
        case IAP_RET_FAIL:
        {
          Result = IAP_FAIL;
          __DBG_IAPPrintf("\t[FAIL][%x]\n\r", RetValue.Code);
          break;
        }
        case IAP_RET_CMDERROR:
        {
          Result = IAP_CMDERROR;
          __DBG_IAPPrintf("\t[CMDERR][%x]\n\r", RetValue.Code);
          break;
        }
        default:
        {
          Result = IAP_RETERROR;
          __DBG_IAPPrintf("\t[RETFAIL][%x]\n\r", RetValue.Code);
          break;
        }
      }
    }
    else
    {
      Result = IAP_RETERROR;
      __DBG_IAPPrintf("\t[RETFAIL][%x]\n\r", RetValue.Code);
    }
    if(RetValue.Code == 0xFFFF)
    {
      Result = IAP_RETDUMMY;
      __DBG_IAPPrintf("\t[RETFAIL][%x]\n\r", RetValue.Code);
    }
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Check Device Ready.
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_CheckDeviceReady(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result = IAP_OK;
  I2CBuffer_Status_Enum BufferResult;
  I2CBuffer_InitTypedef I2CBuffer;
  IAP_Protocol_TypeDef RetValue;

  __DBG_IAPPrintf("Check device ready.....");

  I2CBuffer.uTimeout = uTimeout;
  I2CBuffer.uSlaveAddress = uI2CSlaveAddress;
  I2CBuffer.puBuffer = (u8 *)&RetValue;
  I2CBuffer.uLength = 0;
  I2CBuffer.Command = I2C_BUFFER_WRITE;
  I2CBuffer_Start(&I2CBuffer);

  while (1)
  {
    BufferResult = I2CBuffer_GetStatus();
    if (BufferResult != I2C_BUFFER_GOING)
    {
      break;
    }
  }

  if (BufferResult == I2C_BUFFER_TIMEOUT)
  {
    Result = IAP_TIMEOUT;
    __DBG_IAPPrintf("\t[Timeout]\n\r");
  }
  else
  {
    __DBG_IAPPrintf("\t[OK]\n\r");
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  IAP_GetInfo
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_GetInfo(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  unsigned int u32Info[5];
  u16 uPacketCRCBackup;
  u16 *pCRC = (u16*)&u32Info[2];
  u16 uCRCResult;
  __DBG_IAPPrintf("Get Info.....\n\r");

  Command.Code = IAP_CMD_GETINFO;
  Command.uLength = 0;

  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  Result = IAP_GetData(uI2CSlaveAddress, (u8*)u32Info, sizeof(u32Info), uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  uPacketCRCBackup = *pCRC;
  *pCRC = 0;
  uCRCResult = CRC16(0, (u8*)&u32Info, sizeof(u32Info));
  if(uPacketCRCBackup == uCRCResult)
  {
    #if ENGINNER_MODE2
    #else
    printf("\tPage Size: \t%d\r\n", u32Info[1] >> 16);
    printf("\tVER. Address: \t0x%08X\r\n", u32Info[3]);
    printf("\tAP Address: \t0x%08X\r\n", u32Info[1] & 0xFFFF);
    printf("\tFlash Num: \t%d\r\n", u32Info[2] >> 16);
    printf("\tPPBIT Num: \t%d\r\n", u32Info[2] & 0xFFFF);
    #endif

    gTargetMCUPageSize = u32Info[1] >> 16;
    gTargetVerAddr = u32Info[3];
    gTargetAPAddr = u32Info[1] & 0xFFFF;
  }
  else
  {
    Result = IAP_RETERROR;
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  IAP_GetVersion
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_GetVersion(u32 uI2CSlaveAddress, u32 uTimeout)
{
  IAP_Status Result;
  IAP_Protocol_TypeDef Command;
  __ALIGN4 u32 uDataBuffer[10];
  u8 *pu8DataBuffer = (u8*)uDataBuffer;
  u32 uTotalLength = 0;
  int i;
  u32 uDataBufferIndex =0;
  u32 uInfoCk;

  Command.Code = IAP_CMD_FLASH;
  Command.uLength = 12;
  Command.uPara = IAP_PARA_READ;
  Command.uStAddr = gTargetVerAddr;
  Command.uEndAddr = gTargetVerAddr + 40 -1;
  Result = IAP_SendCommand(uI2CSlaveAddress, &Command, uTimeout);
  if (Result != IAP_OK)
  {
    return Result;
  }

  while (1)
  {
    Result = IAP_GetData(uI2CSlaveAddress, &pu8DataBuffer[uDataBufferIndex], 20, uTimeout);
    if (Result != IAP_OK)
    {
      return Result;
    }
    uTotalLength += 20;
    if (uTotalLength >= Command.uEndAddr - Command.uStAddr + 1)
    {
      break;
    }
    uDataBufferIndex += 20;
  }
  uInfoCk = 0;
  for(i=0;i<5;i++)
  {
    uInfoCk += uDataBuffer[i];
  }

  if(uInfoCk == uDataBuffer[5])
  {
    #if ENGINNER_MODE2
    #else
    unsigned int uVerLen = (*((u32 *)(&pu8DataBuffer[0])) & 0x0000FFFF);
    if (uVerLen <= 20)
    {
      pu8DataBuffer[uVerLen+4] = '\0';
      printf("\tAP VER. Len: \t%d\r\n", uVerLen);
      printf("\tAP VER.:\t%s\r\n", &pu8DataBuffer[4]);
    }
    #endif
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  IAP_GetData
  * @param  uI2CSlaveAddress: I2C Slave address
  * @param  puBuffer: Pointer of data
  * @param  uLength: Length of data
  * @param  uTimeout: Timeout based on 1 ms
  * @retval Result: IAP_OK, IAP_TIMEOUT, IAP_FAIL, IAP_CMDERROR, IAP_RETERROR
  ***********************************************************************************************************/
IAP_Status IAP_GetData(u32 uI2CSlaveAddress, u8 *puBuffer, u32 uLength, u32 uTimeout)
{
  IAP_Status Result;
  I2CBuffer_Status_Enum BufferResult;
  I2CBuffer_InitTypedef I2CBuffer;

  __DBG_IAPPrintf("Get Data .....");

  I2CBuffer.uTimeout = uTimeout;
  I2CBuffer.uSlaveAddress = uI2CSlaveAddress;
  I2CBuffer.puBuffer = puBuffer;
  I2CBuffer.uLength = uLength;
  I2CBuffer.Command = I2C_BUFFER_READ;
  I2CBuffer_Start(&I2CBuffer);
  while (1)
  {
    BufferResult = I2CBuffer_GetStatus();
    if (BufferResult != I2C_BUFFER_GOING)
    {
      break;
    }
  }

  if (BufferResult == I2C_BUFFER_TIMEOUT)
  {
    __DBG_IAPPrintf("\t[Timeout]\n\r");
    Result = IAP_TIMEOUT;
  }
  else
  {
    __DBG_IAPPrintf("\t\t[Done]\n\r");
    Result = IAP_CheckDeviceReady(uI2CSlaveAddress, uTimeout);
    if (Result == IAP_OK)
    {
      Result = IAP_GetRET(uI2CSlaveAddress, uTimeout);
    }
  }

  return Result;
}

/* Private functions ---------------------------------------------------------------------------------------*/

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
