/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/ht32f5xxxx_01_it.c
 * @version $Rev:: 8784         $
 * @date    $Date:: 2025-05-19 #$
 * @brief   This file provides all interrupt service routine.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */

/* Includes ------------------------------------------------------------------------------------------------*/
#include "iap_host.h"
/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
 * @brief   This function handles Hard Fault exception.
 * @retval  None
 ************************************************************************************************************/
void HardFault_Handler(void)
{
  #if 1

  static vu32 gIsContinue = 0;
  /*--------------------------------------------------------------------------------------------------------*/
  /* For development FW, MCU run into the while loop when the hardfault occurred.                           */
  /* 1. Stack Checking                                                                                      */
  /*    When a hard fault exception occurs, MCU push following register into the stack (main or process     */
  /*    stack). Confirm R13(SP) value in the Register Window and typing it to the Memory Windows, you can   */
  /*    check following register, especially the PC value (indicate the last instruction before hard fault).*/
  /*    SP + 0x00    0x04    0x08    0x0C    0x10    0x14    0x18    0x1C                                   */
  /*           R0      R1      R2      R3     R12      LR      PC    xPSR                                   */
  while (gIsContinue == 0)
  {
  }
  /* 2. Step Out to Find the Clue                                                                           */
  /*    Change the variable "gIsContinue" to any other value than zero in a Local or Watch Window, then     */
  /*    step out the HardFault_Handler to reach the first instruction after the instruction which caused    */
  /*    the hard fault.                                                                                     */
  /*--------------------------------------------------------------------------------------------------------*/

  #else

  /*--------------------------------------------------------------------------------------------------------*/
  /* For production FW, you shall consider to reboot the system when hardfault occurred.                    */
  /*--------------------------------------------------------------------------------------------------------*/
  NVIC_SystemReset();

  #endif
}

/*********************************************************************************************************//**
 * @brief   This function handles SysTick Handler.
 * @retval  None
 ************************************************************************************************************/
void SysTick_Handler(void)
{
  extern vs32 gsI2CBuffer_TimerCount;
  if (gsI2CBuffer_TimerCount > 0)
  {
    gsI2CBuffer_TimerCount--;
  }
  #if ENGINNER_MODE2
  {
    extern  volatile s32 *pgTimeoutTestResetTime;
    extern s32 gTimeroutTestSystemResetCounter ;
    extern s32 gTimeroutTestAFIOChangeI2CMode ;
    extern s32 gTimeroutResetCounter;
    if(gTimeroutTestSystemResetCounter > 0)
    {
      gTimeroutTestSystemResetCounter--;
    }
    else if (gTimeroutTestSystemResetCounter == 0)
    {
      HT32F_DVB_LEDOn(HT_LED3);
      #if ENGINNER_MODE2_MODE
      {
        AFIO_GPxConfig(HTCFG_IAPI2C_SCL_GPIO_ID, HTCFG_IAPI2C_SCL_AFIO_PIN, AFIO_FUN_GPIO);
        AFIO_GPxConfig(HTCFG_IAPI2C_SDA_GPIO_ID, HTCFG_IAPI2C_SDA_AFIO_PIN, AFIO_FUN_GPIO);
        gTimeroutTestSystemResetCounter = -1;
        gTimeroutTestAFIOChangeI2CMode  = 2;
      }
      #else
      NVIC_SystemReset();
      #endif
    }
    if(gTimeroutResetCounter>0)
    {
      gTimeroutResetCounter--;
    }
    else if(gTimeroutResetCounter == 0)
    {
      NVIC_SystemReset();
    }
    #if ENGINNER_MODE2_MODE
    if(gTimeroutTestAFIOChangeI2CMode > 0)
    {
      gTimeroutTestAFIOChangeI2CMode--;
    }
    else if (gTimeroutTestAFIOChangeI2CMode == 0)
    {
      HT32F_DVB_LEDOff(HT_LED3);
      AFIO_GPxConfig(HTCFG_IAPI2C_SCL_GPIO_ID, HTCFG_IAPI2C_SCL_AFIO_PIN, AFIO_FUN_I2C);
      AFIO_GPxConfig(HTCFG_IAPI2C_SDA_GPIO_ID, HTCFG_IAPI2C_SDA_AFIO_PIN, AFIO_FUN_I2C);
      gTimeroutTestAFIOChangeI2CMode = -1;
    }
    #endif
    
  }
  #endif
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
