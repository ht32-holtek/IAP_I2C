/*********************************************************************************************************//**
 * @file    iap_config.h
 * @version $Rev:: 9009         $
 * @date    $Date:: 2025-06-06 #$
 * @brief   The configuration file of IAP.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __IAP_CONFIG_H
#define __IAP_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/

/* I2C                                                                                                      */
//<o0> I2C Clock Speed (Hz) <1-1000000:1>
// <i> I2C Clock Speed in Hz.
//<o1> I2C Master address <0x01-0x7F:1>
//<o2> I2C Slave address for IAP mode <0x01-0x7F:1>
// <i> IAP Loader receive COMMAND and transmit RETURN via this slave address.
//<o3> I2C Slave address for AP mode <0x01-0x7F:1>
// <i> AP receive COMMAND and transmit RETURN via this slave address.
#define I2C_CLOCK_SPEED                (400000)                      /* I2C Clock speed                     */
#define I2C_MASTER_ADDRESS             (0x0A)                        /* I2C Master address                  */
#define I2C_SLAVE_ADDRESS_IAP          (0x70)                        /* I2C Slave address for IAP           */
#define I2C_SLAVE_ADDRESS_AP           (0x60)                        /* I2C Slave address for AP            */

/* IAP                                                                                                      */
/* !!! NOTICE !!!

 IAP_CODE_SIZE determines the start address of the AP.

 The IAP_CODE_SIZE value on the Host side and the Slave side MUST match,
 otherwise the following issues will occur:

 1. Host_AP_Start < Slave_AP_Start:
      The Host will attempt to program at an earlier address, while the Slave's actual AP begins at a later
      address. This mismatch will be detected; the programming process will return an error code.

 2. Host_AP_Start > Slave_AP_Start:
      The Host will start programming at a later address,skipping over the beginning of the Slave's actual
      AP. This mismatch cannot be detected; programming appears successful, but execution will jump to the
      wrong location, causing a system crash.
 */
#define IAP_CODE_SIZE                  (1024 * 10)                    /* IAP code size in Bytes              */

/* Option Byte Erase                                                                                        */
// <e0> Enable Option Byte Erase
//  <i> Default Option Byte Erase = DISABLE
//   <o1> Slave Flash Page Size <512-1024:512>
//    <i> Slave Flash Page Size Value
#define ENABLE_OB_ERASE                (0)
#define SLAVE_FLASH_PAGE_SIZE          (512)

#ifdef __cplusplus
}
#endif

#endif
