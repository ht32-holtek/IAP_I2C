/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/i2c_buffer.h
 * @version $Rev:: 2733         $
 * @date    $Date:: 2018-04-26 #$
 * @brief   The header file of I2C buffer interrupt.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __I2C_BUFFER_H
#define __I2C_BUFFER_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */

/* Settings ------------------------------------------------------------------------------------------------*/
/* Exported typedef ----------------------------------------------------------------------------------------*/
/**
 * @brief I2C Buffer status
 */
typedef enum
{
  I2C_BUFFER_GOING    = 0,
  I2C_BUFFER_FINISH   = 1,
  I2C_BUFFER_TIMEOUT  = 2
} I2CBuffer_Status_Enum;

/**
 * @brief I2C Buffer command
 */
typedef enum
{
  I2C_BUFFER_READ    = 0,
  I2C_BUFFER_WRITE   = 1
} I2CBuffer_CMD_Enum;

/**
 * @brief I2C Buffer Init struct
 */
typedef struct
{
  u32 uSlaveAddress;
  u8 *puBuffer;
  u32 uLength;
  u32 uTimeout;
  I2CBuffer_CMD_Enum Command;
} I2CBuffer_InitTypedef;


/* Exported constants --------------------------------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported variables --------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/
void I2CBuffer_Start(I2CBuffer_InitTypedef *pI2CBuffer);
I2CBuffer_Status_Enum I2CBuffer_GetStatus(void);
void I2CBuffer_Delay(u32 ms);
void I2C_IRQHandler(void);

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* __I2C_BUFFER_H -----------------------------------------------------------------------------------*/

