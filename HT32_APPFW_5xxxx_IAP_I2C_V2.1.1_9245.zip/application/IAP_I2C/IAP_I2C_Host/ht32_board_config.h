/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/ht32_board_config.h
 * @version $Rev:: 9225         $
 * @date    $Date:: 2025-06-25 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
#if defined(USE_HT32F52230_SK)
  #define HTCFG_IAPI2C_IPN                        I2C0
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 7
  #define _HTCFG_IAPI2C_SDA_GPIOX                 B
  #define _HTCFG_IAPI2C_SDA_GPION                 8
#endif

#if defined(USE_HT32F52241_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#if defined(USE_HT32F52341_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#if defined(USE_HT32F52352_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 A
  #define _HTCFG_IAPI2C_SCL_GPION                 0
  #define _HTCFG_IAPI2C_SDA_GPIOX                 A
  #define _HTCFG_IAPI2C_SDA_GPION                 1
#endif

#if defined(USE_HT32F52253_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 A
  #define _HTCFG_IAPI2C_SCL_GPION                 0
  #define _HTCFG_IAPI2C_SDA_GPIOX                 A
  #define _HTCFG_IAPI2C_SDA_GPION                 1
#endif

#if defined(USE_HT32F0008_SK)
  #define HTCFG_IAPI2C_IPN                        I2C0
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#if defined(USE_HT32F50230_SK)
  #define HTCFG_IAPI2C_IPN                        I2C0
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#if defined(USE_HT32F50241_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#if defined(USE_HT32F54241_SK)
  #define HTCFG_IAPI2C_IPN                        I2C0
  #define _HTCFG_IAPI2C_SCL_GPIOX                 C
  #define _HTCFG_IAPI2C_SCL_GPION                 6
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 7
#endif

#if defined(USE_HT32F54253_SK)
  #define HTCFG_IAPI2C_IPN                        I2C1
  #define _HTCFG_IAPI2C_SCL_GPIOX                 B
  #define _HTCFG_IAPI2C_SCL_GPION                 15
  #define _HTCFG_IAPI2C_SDA_GPIOX                 C
  #define _HTCFG_IAPI2C_SDA_GPION                 0
#endif

#define HTCFG_IAPI2C_SCL_GPIO_ID                  STRCAT2(GPIO_P,    _HTCFG_IAPI2C_SCL_GPIOX)
#define HTCFG_IAPI2C_SCL_AFIO_PIN                 STRCAT2(AFIO_PIN_, _HTCFG_IAPI2C_SCL_GPION)

#define HTCFG_IAPI2C_SDA_GPIO_ID                  STRCAT2(GPIO_P,    _HTCFG_IAPI2C_SDA_GPIOX)
#define HTCFG_IAPI2C_SDA_AFIO_PIN                 STRCAT2(AFIO_PIN_, _HTCFG_IAPI2C_SDA_GPION)

#define HTCFG_IAPI2C_PORT                         STRCAT2(HT_, HTCFG_IAPI2C_IPN)
#define HTCFG_IAPI2C_IRQn                         STRCAT2(HTCFG_IAPI2C_IPN, _IRQn)
#define HTCFG_IAPI2C_IRQHandler                   STRCAT2(HTCFG_IAPI2C_IPN, _IRQHandler)

#ifdef __cplusplus
}
#endif

#endif
