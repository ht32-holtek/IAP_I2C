/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_AP/Src_AP/main.c
 * @version $Rev:: 9235         $
 * @date    $Date:: 2025-06-25 #$
 * @brief   The main program of IAP I2C Device example.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
#include "iap_protocol.h"
#include "i2c_config.h"
#include "wdt_config.h"
#include "common\ring_buffer.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_Device IAP - I2C Device application example
  * @{
  */

/** @addtogroup IAP_I2C_Device_AP Application example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define TIMER_BASE                    (SystemCoreClock / 8 / 1000)       /* 1 ms                            */
#define IAP_CMD_TIMEOUT_RESULT        50

/* Private function prototypes -----------------------------------------------------------------------------*/
void NVIC_Configuration(void);
void CKCU_Configuration(void);
void GPIO_Configuration(void);
void I2C_Configuration(void);
void CheckIAPCommand(void);

/* Global variables ----------------------------------------------------------------------------------------*/
vu32 isTxFinish = FALSE;
__ALIGN4 u8 guTxBuffer[TX_BUFFER_SIZE + 1];
__ALIGN4 u8 guRxBuffer[RX_BUFFER_SIZE + 1];
Buffer_TypeDef gTx;
Buffer_TypeDef gRx;

vs32 gIAPCmdTimeout;

/* Private variables ---------------------------------------------------------------------------------------*/
__ALIGN4 static u8 gu8CommandBuffer[IAP_CODE_LENGTH];
static u32 u32CommandIndex = 0;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  #if !ENABLE_WDT
    WDT_DeInit();
  #endif
  /*--------------------------------------------------------------------------------------------------------*/
  /* Reset BOOT_MODE which set by IAP, to avoid start AP again                                              */
  /*--------------------------------------------------------------------------------------------------------*/
  BOOT_MODE = 0;

  /*--------------------------------------------------------------------------------------------------------*/
  /* Init Buffer for I2C slave transmission                                                                 */
  /*--------------------------------------------------------------------------------------------------------*/
  Buffer_Init(&gTx, guTxBuffer, sizeof(guTxBuffer));
  Buffer_Init(&gRx, guRxBuffer, sizeof(guRxBuffer));

  NVIC_Configuration();
  CKCU_Configuration();
  GPIO_Configuration();
  I2C_Configuration();
  RETARGET_Configuration();

  HT32F_DVB_LEDInit(HT_LED1);

  SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);
  SYSTICK_SetReloadValue(TIMER_BASE);
  SYSTICK_IntConfig(ENABLE);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
  SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);

  while (1)
  {
    WDT_RST();
    CheckIAPCommand();
    printf("Hello World!\n\r");
  }
}

/*********************************************************************************************************//**
  * @brief  Check IAP command.
  * @retval None
  ***********************************************************************************************************/
void CheckIAPCommand(void)
{
  u8 uData;
  u32 uResult;
  IAP_Protocol_TypeDef *pCMD = (IAP_Protocol_TypeDef *)gu8CommandBuffer;

  uResult = Buffer_ReadByte(&gRx, &uData);
  if (uResult)
  {
    gu8CommandBuffer[u32CommandIndex++] = uData;
    while (u32CommandIndex < IAP_CODE_LENGTH)
    if (Buffer_ReadByte(&gRx, &uData))
    {
      gu8CommandBuffer[u32CommandIndex++] = uData;
    }
  }
  if (u32CommandIndex == IAP_CODE_LENGTH)
  {
    bool result = TRUE;
    /*------------------------------------------------------------------------------------------------------*/
    /* Check command after received enough bytes                                                            */
    /*------------------------------------------------------------------------------------------------------*/
    u32CommandIndex = 0;            /* Reset Command index for next command                                 */
    if ((pCMD->Code == IAP_CMD_START_IAP) && (pCMD->Code + pCMD->Check) == IAP_CMDVALID)
    {
      /*----------------------------------------------------------------------------------------------------*/
      /* Command is valid, Response to Host and start IAP mode                                              */
      /*----------------------------------------------------------------------------------------------------*/
      pCMD->Code = IAP_RET_OK;
      pCMD->Check = (IAP_CODE_Enum)(~IAP_RET_OK);
      isTxFinish = FALSE;

      gIAPCmdTimeout = IAP_CMD_TIMEOUT_RESULT;
      Buffer_Write(&gTx, gu8CommandBuffer, IAP_CODE_LENGTH);
      I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_TXDE, ENABLE);
      while (!Buffer_isEmpty(&gTx) || isTxFinish == FALSE)
      {
        if(gIAPCmdTimeout == 0)
        {
          I2C_DeInit(HTCFG_IAPI2C_PORT);
          I2C_Configuration();
          result = FALSE;
          break;
        }
        WDT_RST();
      }
      if(result == TRUE)
      {
        I2C_Cmd(HTCFG_IAPI2C_PORT, DISABLE);

        /*----------------------------------------------------------------------------------------------------*/
        /* Set BOOT_MODE as BOOT_MODE_IAP and trigger a reset to start IAP mode. BOOT_MODE only reset by      */
        /* Power-on-reset.                                                                                    */
        /*----------------------------------------------------------------------------------------------------*/
        BOOT_MODE = BOOT_MODE_IAP;
        NVIC_SystemReset();           /* Trigger reset                                                        */
      }
    }
  }
}

/*********************************************************************************************************//**
  * @brief  Configure NVIC vector table.
  * @retval None
  ***********************************************************************************************************/
void NVIC_Configuration(void)
{
  NVIC_SetVectorTable(NVIC_VECTTABLE_FLASH, IAP_APFLASH_START); /* Set Vector Table Offset                  */

  /* Enable NVIC I2C interrupt                                                                              */
  NVIC_EnableIRQ(HTCFG_IAPI2C_IRQn);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{ 0 }};
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.HTCFG_IAPI2C_IPN = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}

/*********************************************************************************************************//**
  * @brief  Configure the GPIO ports.
  * @retval None
  ***********************************************************************************************************/
void GPIO_Configuration(void)
{
  /* Configure GPIO as I2C mode                                                                             */
  AFIO_GPxConfig(HTCFG_IAPI2C_SCL_GPIO_ID, HTCFG_IAPI2C_SCL_AFIO_PIN, AFIO_FUN_I2C);
  AFIO_GPxConfig(HTCFG_IAPI2C_SDA_GPIO_ID, HTCFG_IAPI2C_SDA_AFIO_PIN, AFIO_FUN_I2C);
}

/*********************************************************************************************************//**
  * @brief  Configure I2C.
  * @retval None
  ***********************************************************************************************************/
void I2C_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  I2C_InitTypeDef  I2C_InitStructure;

  /* I2C configuration                                                                                      */
  I2C_InitStructure.I2C_GeneralCall = DISABLE;
  I2C_InitStructure.I2C_AddressingMode = I2C_ADDRESSING_7BIT;
  I2C_InitStructure.I2C_Acknowledge = ENABLE;
  I2C_InitStructure.I2C_OwnAddress = I2C_SLAVE_ADDRESS_AP;
  I2C_InitStructure.I2C_Speed = I2C_CLOCK_SPEED;
  I2C_InitStructure.I2C_SpeedOffset = 0;
  #if (LIBCFG_I2C_NOSTRETCH)
  I2C_InitStructure.I2C_StretchMode = I2C_STRETCH_YES;
  #endif
  I2C_Init(HTCFG_IAPI2C_PORT, &I2C_InitStructure);

  /* Enable I2C                                                                                             */
  I2C_Cmd(HTCFG_IAPI2C_PORT, ENABLE);

  /* Enable I2C interrupts                                                                                  */
  I2C_IntConfig(HTCFG_IAPI2C_PORT,
              I2C_INT_BUSERR |
              I2C_INT_ADRS |
              I2C_INT_TXDE |
              I2C_INT_RXNACK |
              I2C_INT_RXBF |
              I2C_INT_STO,
              ENABLE);

  I2C_CombFilterCmd(HTCFG_IAPI2C_PORT, ENABLE);
  I2C_SequentialFilterConfig(HTCFG_IAPI2C_PORT, SEQ_FILTER_2_PCLK);
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
