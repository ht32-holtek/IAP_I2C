/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Host/i2c_buffer.c
 * @version $Rev:: 3021         $
 * @date    $Date:: 2024-01-30 #$
 * @brief   The buffer of I2C interrupt mode.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board_config.h"
#include "i2c_buffer.h"


/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_Examples IAP
  * @{
  */

/** @addtogroup IAP_I2C_HOST IAP - I2C host application example
  * @{
  */

/* Private typedef -----------------------------------------------------------------------------------------*/
/**
 * @brief I2C Buffer global variables
 */
typedef struct
{
  u32 uIndex;
  u32 uLength;
  u8 *puBuffer;
  u32 uSlaveAddress;
  u32 uCommand;
  vu32 IsBusy;
  vu32 uIsNACK;
} I2CBuffer_TypeDef;

/* Private constants ---------------------------------------------------------------------------------------*/
#define I2C_MASTER_RECEIVED_TXNACK            ((u32)0x003A0200)
#define I2C_MASTER_RECEIVED_RXNACK            ((u32)0x00180200)

/* Private function prototypes -----------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Global variables ----------------------------------------------------------------------------------------*/
vs32 gsI2CBuffer_TimerCount;

/* Private variables ---------------------------------------------------------------------------------------*/
static I2CBuffer_TypeDef gI2CBuffer;

/* Global functions ----------------------------------------------------------------------------------------*/

/*********************************************************************************************************//**
  * @brief  Start Read or Write of I2C buffer.
  * @param  pI2CBuffer: Pointer of I2CBuffer_InitTypedef
  * @retval None
  ***********************************************************************************************************/
void I2CBuffer_Start(I2CBuffer_InitTypedef *pI2CBuffer)
{
  gI2CBuffer.uIndex = 0;
  gI2CBuffer.uLength = pI2CBuffer->uLength;
  gI2CBuffer.puBuffer = pI2CBuffer->puBuffer;
  gI2CBuffer.uSlaveAddress = pI2CBuffer->uSlaveAddress;
  gI2CBuffer.IsBusy = TRUE;
  gI2CBuffer.uIsNACK = FALSE;
  gsI2CBuffer_TimerCount = pI2CBuffer->uTimeout;

  while (I2C_GetFlagStatus(HTCFG_IAPI2C_PORT, I2C_FLAG_BUSBUSY) == SET);

  I2C_ClearFlag(HTCFG_IAPI2C_PORT, I2C_FLAG_RXNACK);
  I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_RXNACK, ENABLE);

  if (pI2CBuffer->Command == I2C_BUFFER_WRITE)
  {
    I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_TXDE, ENABLE);
    gI2CBuffer.uCommand = I2C_MASTER_WRITE;
  }
  else
  {
    gI2CBuffer.uCommand = I2C_MASTER_READ;
  }

  I2C_TargetAddressConfig(HTCFG_IAPI2C_PORT, pI2CBuffer->uSlaveAddress, gI2CBuffer.uCommand);

  return;
}

/*********************************************************************************************************//**
  * @brief  Get I2C buffer statue.
  * @retval Result: I2C_BUFFER_FINISH or I2C_BUFFER_TIMEOUT
  ***********************************************************************************************************/
I2CBuffer_Status_Enum I2CBuffer_GetStatus(void)
{
  I2CBuffer_Status_Enum Result = I2C_BUFFER_GOING;
  vu32 i;

  if (gI2CBuffer.IsBusy == FALSE)
  {
    Result = I2C_BUFFER_FINISH;
  }
  else if (gsI2CBuffer_TimerCount == 0)
  {
    Result = I2C_BUFFER_TIMEOUT;

    I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_RXNACK, DISABLE);
    I2C_ClearFlag(HTCFG_IAPI2C_PORT, I2C_FLAG_RXNACK);

    I2C_GenerateSTOP(HTCFG_IAPI2C_PORT);
  }
  else if (gI2CBuffer.uIsNACK == TRUE)
  {
    gI2CBuffer.uIsNACK = FALSE;

    /* Release I2C bus for other master by adding a delay                                                   */
    for (i = 0; i < 500; i++);

    /* Re-Write Slave address for start Tx or Rx (re-try when Slave not ack)                                */
    I2C_TargetAddressConfig(HTCFG_IAPI2C_PORT, gI2CBuffer.uSlaveAddress, gI2CBuffer.uCommand);
  }

  return Result;
}

/*********************************************************************************************************//**
  * @brief  Delay based on ms.
  * @param  ms: Delay time based on ms
  * @retval None
  ***********************************************************************************************************/
void I2CBuffer_Delay(u32 ms)
{
  gsI2CBuffer_TimerCount = ms;
  SysTick->VAL = 0;
  while (gsI2CBuffer_TimerCount != 0);
}

/*********************************************************************************************************//**
 * @brief   This function handles I2C interrupt.
 * @retval  None
 ************************************************************************************************************/
void HTCFG_IAPI2C_IRQHandler(void)
{
  u32 uResult;

  uResult = I2C_ReadRegister(HTCFG_IAPI2C_PORT, I2C_REGISTER_SR);
  switch (uResult)
  {
    /*-----------------------------Master Receiver ---------------------------------------------------------*/
    case I2C_MASTER_RECEIVER_MODE:
    {
      /* Enable I2C0 ACK for receiving data                                                                 */
      I2C_AckCmd(HTCFG_IAPI2C_PORT, ENABLE);
      break;
    }
    case I2C_MASTER_RX_NOT_EMPTY:
    {
      /* Receive data sent from I2C                                                                         */
      *(gI2CBuffer.puBuffer + gI2CBuffer.uIndex) = I2C_ReceiveData(HTCFG_IAPI2C_PORT);
      gI2CBuffer.uIndex++;
      gI2CBuffer.uLength--;

      if (gI2CBuffer.uLength == 1)
      {
        I2C_AckCmd(HTCFG_IAPI2C_PORT, DISABLE);
      }
      else if (gI2CBuffer.uLength == 0)
      {
        I2C_GenerateSTOP(HTCFG_IAPI2C_PORT);

        /* Clear IsBusy flag to terminate polling of I2CBuffer_GetStatus                                    */
        gI2CBuffer.IsBusy = FALSE;
      }
      break;
    }

    /*-----------------------------Master Transmitter ------------------------------------------------------*/
    case I2C_MASTER_TRANSMITTER_MODE:
    case I2C_MASTER_TX_EMPTY:
    {
      if (gI2CBuffer.uLength != 0)
      {
        I2C_SendData(HTCFG_IAPI2C_PORT, *(gI2CBuffer.puBuffer + gI2CBuffer.uIndex));
        gI2CBuffer.uIndex++;
        gI2CBuffer.uLength--;
      }
      else
      {
        I2C_IntConfig(HTCFG_IAPI2C_PORT, I2C_INT_TXDE, DISABLE);
        I2C_GenerateSTOP(HTCFG_IAPI2C_PORT);

        /* Clear IsBusy flag to terminate polling of I2CBuffer_GetStatus                                    */
        gI2CBuffer.IsBusy = FALSE;
      }
      break;
    }

    /* Received NACK when Read or Write mode                                                                */
    case I2C_MASTER_RECEIVED_RXNACK:
    case I2C_MASTER_RECEIVED_TXNACK:
    {
      I2C_ClearFlag(HTCFG_IAPI2C_PORT, I2C_FLAG_RXNACK);
      I2C_GenerateSTOP(HTCFG_IAPI2C_PORT);

      /* Set uIsNACK flag for re-try by I2CBuffer_GetStatus                                                 */
      gI2CBuffer.uIsNACK = TRUE;
      break;
    }
  }
}

/* Private functions ---------------------------------------------------------------------------------------*/

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
