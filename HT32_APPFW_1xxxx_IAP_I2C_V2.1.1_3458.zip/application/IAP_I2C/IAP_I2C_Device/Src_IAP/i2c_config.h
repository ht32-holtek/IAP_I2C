/*********************************************************************************************************//**
 * @file    IAP_I2C/IAP_I2C_Device/Src_IAP/i2c_config.h
 * @version $Rev:: 3267         $
 * @date    $Date:: 2025-05-20 #$
 * @brief   The configuration file.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
// <<< Use Configuration Wizard in Context Menu >>>

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __I2C_CONFIG_H
#define __I2C_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
/* I2C                                                                                                      */
//<o0> I2C Clock Speed (Hz) <1-1000000:1>
// <i> I2C Clock Speed in Hz.
//<o1> I2C Slave address for IAP mode <0x01-0x7F:1>
// <i> IAP Loader receive COMMAND and transmit RETURN via this slave address.
#define I2C_CLOCK_SPEED               (400000)                      /* I2C Clock speed                      */
#define I2C_SLAVE_ADDRESS_IAP         (0x70)                        /* I2C Slave address for IAP            */

/*  Buffer                                                                                                  */
//<o0> I2C Tx buffer size (Bytes) <4-1024:4>
//<o1> I2C Rx buffer size (Bytes) <4-1024:4>
#define TX_BUFFER_SIZE                (56)                          /* Tx Buffer size for I2C               */
#define RX_BUFFER_SIZE                (132)                         /* Rx Buffer size for I2C               */

/*  Dummy Data                                                                                              */
//<e0> Enable I2C Dummy Data
// <i> Default I2C Dummy Data = DISABLE
//  <o1> I2C Dummy Data <0x00-0xFF:1>
//   <i> I2C Dummy Data Value
#define I2C_ENABLE_DUMMY_DATA         (0)
#define I2C_DUMMY_DATA_VALUE          (0xFF)

#ifdef __cplusplus
}
#endif

#endif
