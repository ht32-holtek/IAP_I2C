/*---------------------------------------------------------------------------------------------------------*/
/* Holtek Semiconductor Inc.                                                                               */
/*                                                                                                         */
/* Copyright (C) Holtek Semiconductor Inc.                                                                 */
/* All rights reserved.                                                                                    */
/*                                                                                                         */
/*-----------------------------------------------------------------------------------------------------------
;  File Name        : startup_ht32f1xxxx_gcc_01.s
;  Version          : $Rev:: 3030         $
;  Date             : $Date:: 2024-01-31 #$
;  Description      : Startup code.
;  Notice           : This file is different with the template of Firmware Library. !! MUST CHECK AFTER SYNC !!
;-----------------------------------------------------------------------------------------------------------*/

/*
;  Supported Device
;  ========================================
;   HT32F1653, HT32F1654
;   HT32F1655, HT32F1656
;   HT32F12365, HT32F12366
;   HT32F12345
*/

;/* <<< Use Configuration Wizard in Context Menu >>>                                                        */
/*
;// <o>  HT32 Device
;//      <0=> By Project Asm Define
;//      <1=> HT32F1653/1654/1655/1656
;//      <2=> HT32F12365/12366
;//      <3=> HT32F12345
*/
    .equ    USE_HT32_CHIP_SET, 0

    .equ _HT32FWID, 0xFFFFFFFF
/*
    .equ _HT32FWID, 0x00012366
*/

    .equ HT32F1653_54_55_56, 1
    .equ HT32F12365_66, 2
    .equ HT32F12345, 3

  .if USE_HT32_CHIP_SET == 0
  .else
    .equ USE_HT32_CHIP, USE_HT32_CHIP_SET
  .endif

  .syntax unified
  .cpu cortex-m3
  .fpu softvfp
  .thumb

/* start address for the initialization values of the .data section. defined in linker script               */
.word  _sidata

/* start address for the .data section. defined in linker script                                            */
.word  _sdata

/* end address for the .data section. defined in linker script                                              */
.word  _edata

/* start address for the .bss section. defined in linker script                                             */
.word  _sbss

/* end address for the .bss section. defined in linker script                                               */
.word  _ebss


/*
; Amount of memory (in bytes) allocated for Stack and Heap
; Tailor those values to your application needs
;//   <o> Stack Size (in Bytes, must 8 byte aligned) <:8>
*/
    .equ    Stack_Size, 512
    .section ".stack", "w"
    .align  3
    .globl  __StackTop
    .globl  __StackLimit
    .globl  __HT_check_sp
__HT_check_sp:
__StackLimit:
    .if     Stack_Size
    .space  Stack_Size
    .endif
    .size __StackLimit, . - __StackLimit
__StackTop:
    .size __StackTop, . - __StackTop

/*
;//   <o>  Heap Size (in Bytes) <:8>
*/
    .equ    Heap_Size, 0
    .section ".heap", "w"
    .align  3
    .globl  __HeapBase
    .globl  _end
    .globl  __HeapLimit
    .globl  __HT_check_heap
__HT_check_heap:
__HeapBase:
_end:
    .if     Heap_Size
    .space  Heap_Size
    .endif
    .size __HeapBase, . - __HeapBase
__HeapLimit:
    .size __HeapLimit, . - __HeapLimit

    .equ    _RESERVED, 0xFFFFFFFF
/*
;*******************************************************************************
; Fill-up the Vector Table entries with the exceptions ISR address
;********************************************************************************/
                    .section  .isr_vector,"a",%progbits
                    .global  __interrupt_vector_cortex_m
                    .type  __interrupt_vector_cortex_m, %object
__interrupt_vector_cortex_m:
                    .long  __StackTop                         /* ---, 00, 0x000, Top address of Stack       */
                    .long  Reset_Handler                      /* ---, 01, 0x004, Reset Handler              */
                    .long  NMI_Handler                        /* ---, 02, 0x008, NMI Handler                */
                    .long  HardFault_Handler                  /* ---, 03, 0x00C, Hard Fault Handler         */
                    .include "../../GNU_ARM/image_info.s"
                    //.long  _RESERVED                          /* ---, 04, 0x010, Reserved                   */
                    //.long  _RESERVED                          /* ---, 05, 0x014, Reserved                   */
                    //.long  _RESERVED                          /* ---, 06, 0x018, Reserved                   */
                    //.long  _RESERVED                          /* ---, 07, 0x01C, Reserved                   */
                    //.long  _HT32FWID                          /* ---, 08, 0x020, Reserved                   */
                    //.long  _RESERVED                          /* ---, 09, 0x024, Reserved                   */
                    .long  _RESERVED                          /* ---, 10, 0x028, Reserved                   */
                    .long  SVC_Handler                        /* ---, 11, 0x02C, SVC Handler                */
                    .long  DebugMon_Handler                   /* ---, 12, 0x030, Debug Monitor Handler      */
                    .long  _RESERVED                          /* ---, 13, 0x034, Reserved                   */
                    .long  PendSV_Handler                     /* ---, 14, 0x038, PendSV Handler             */
                    .long  SysTick_Handler                    /* ---, 15, 0x03C, SysTick Handler            */

                    /* External Interrupt Handler                                                           */
                    .long   CKRDY_IRQHandler                  /*  00, 16, 0x040,                            */
                    .long   LVD_IRQHandler                    /*  01, 17, 0x044,                            */
                    .long   BOD_IRQHandler                    /*  02, 18, 0x048,                            */
                  .if (USE_HT32_CHIP==HT32F1653_54_55_56)
                    .long   WDT_IRQHandler                    /*  03, 19, 0x04C,                            */
                  .else
                    .long   _RESERVED                         /*  03, 19, 0x04C,                            */
                  .endif
                    .long   RTC_IRQHandler                    /*  04, 20, 0x050,                            */
                    .long   FLASH_IRQHandler                  /*  05, 21, 0x054,                            */
                    .long   EVWUP_IRQHandler                  /*  06, 22, 0x058,                            */
                    .long   LPWUP_IRQHandler                  /*  07, 23, 0x05C,                            */
                    .long   EXTI0_IRQHandler                  /*  08, 24, 0x060,                            */
                    .long   EXTI1_IRQHandler                  /*  09, 25, 0x064,                            */
                    .long   EXTI2_IRQHandler                  /*  10, 26, 0x068,                            */
                    .long   EXTI3_IRQHandler                  /*  11, 27, 0x06C,                            */
                    .long   EXTI4_IRQHandler                  /*  12, 28, 0x070,                            */
                    .long   EXTI5_IRQHandler                  /*  13, 29, 0x074,                            */
                    .long   EXTI6_IRQHandler                  /*  14, 30, 0x078,                            */
                    .long   EXTI7_IRQHandler                  /*  15, 31, 0x07C,                            */
                    .long   EXTI8_IRQHandler                  /*  16, 32, 0x080,                            */
                    .long   EXTI9_IRQHandler                  /*  17, 33, 0x084,                            */
                    .long   EXTI10_IRQHandler                 /*  18, 34, 0x088,                            */
                    .long   EXTI11_IRQHandler                 /*  19, 35, 0x08C,                            */
                    .long   EXTI12_IRQHandler                 /*  20, 36, 0x090,                            */
                    .long   EXTI13_IRQHandler                 /*  21, 37, 0x094,                            */
                    .long   EXTI14_IRQHandler                 /*  22, 38, 0x098,                            */
                    .long   EXTI15_IRQHandler                 /*  23, 39, 0x09C,                            */
                    .long   COMP_IRQHandler                   /*  24, 40, 0x0A0,                            */
                    .long   ADC_IRQHandler                    /*  25, 41, 0x0A4,                            */
                    .long   _RESERVED                         /*  26, 42, 0x0A8,                            */
                    .long   MCTM0_BRK_IRQHandler              /*  27, 43, 0x0AC,                            */
                    .long   MCTM0_UP_IRQHandler               /*  28, 44, 0x0B0,                            */
                    .long   MCTM0_TR_IRQHandler               /*  29, 45, 0x0B4,                            */
                    .long   MCTM0_CC_IRQHandler               /*  30, 46, 0x0B8,                            */
                    .long   MCTM1_BRK_IRQHandler              /*  31, 47, 0x0BC,                            */
                    .long   MCTM1_UP_IRQHandler               /*  32, 48, 0x0C0,                            */
                    .long   MCTM1_TR_IRQHandler               /*  33, 49, 0x0C4,                            */
                    .long   MCTM1_CC_IRQHandler               /*  34, 50, 0x0C8,                            */
                    .long   GPTM0_IRQHandler                  /*  35, 51, 0x0CC,                            */
                    .long   GPTM1_IRQHandler                  /*  36, 52, 0x0D0,                            */
                    .long   _RESERVED                         /*  37, 53, 0x0D4,                            */
                    .long   _RESERVED                         /*  38, 54, 0x0D8,                            */
                    .long   _RESERVED                         /*  39, 55, 0x0DC,                            */
                    .long   _RESERVED                         /*  40, 56, 0x0E0,                            */
                    .long   BFTM0_IRQHandler                  /*  41, 57, 0x0E4,                            */
                    .long   BFTM1_IRQHandler                  /*  42, 58, 0x0E8,                            */
                    .long   I2C0_IRQHandler                   /*  43, 59, 0x0EC,                            */
                    .long   I2C1_IRQHandler                   /*  44, 60, 0x0F0,                            */
                    .long   SPI0_IRQHandler                   /*  45, 61, 0x0F4,                            */
                    .long   SPI1_IRQHandler                   /*  46, 62, 0x0F8,                            */
                    .long   USART0_IRQHandler                 /*  47, 63, 0x0FC,                            */
                    .long   USART1_IRQHandler                 /*  48, 64, 0x100,                            */
                    .long   UART0_IRQHandler                  /*  49, 65, 0x104,                            */
                    .long   UART1_IRQHandler                  /*  50, 66, 0x108,                            */
                  .if (USE_HT32_CHIP==HT32F12345)
                    .long   _RESERVED                         /*  51, 67, 0x10C,                            */
                  .else
                    .long   SCI_IRQHandler                    /*  51, 67, 0x10C,                            */
                  .endif
                    .long   I2S_IRQHandler                    /*  52, 68, 0x110,                            */
                    .long   USB_IRQHandler                    /*  53, 69, 0x114,                            */
                  .if (USE_HT32_CHIP==HT32F1653_54_55_56)
                    .long   _RESERVED                         /*  54, 70, 0x118,                            */
                  .else
                    .long   SDIO_IRQHandler                   /*  54, 70, 0x118,                            */
                  .endif
                    .long   PDMA_CH0_IRQHandler               /*  55, 71, 0x11C,                            */
                    .long   PDMA_CH1_IRQHandler               /*  56, 72, 0x120,                            */
                    .long   PDMA_CH2_IRQHandler               /*  57, 73, 0x124,                            */
                    .long   PDMA_CH3_IRQHandler               /*  58, 74, 0x128,                            */
                    .long   PDMA_CH4_IRQHandler               /*  59, 75, 0x12C,                            */
                    .long   PDMA_CH5_IRQHandler               /*  60, 76, 0x130,                            */
                    .long   PDMA_CH6_IRQHandler               /*  61, 77, 0x134,                            */
                    .long   PDMA_CH7_IRQHandler               /*  62, 78, 0x138,                            */
                  .if (USE_HT32_CHIP==HT32F1653_54_55_56)
                    .long   _RESERVED                         /*  63, 79, 0x13C,                            */
                    .long   _RESERVED                         /*  64, 80, 0x140,                            */
                    .long   _RESERVED                         /*  65, 81, 0x144,                            */
                    .long   _RESERVED                         /*  66, 82, 0x148,                            */
                  .else
                    .long   PDMA_CH8_IRQHandler               /*  63, 79, 0x13C,                            */
                    .long   PDMA_CH9_IRQHandler               /*  64, 80, 0x140,                            */
                    .long   PDMA_CH10_IRQHandler              /*  65, 81, 0x144,                            */
                    .long   PDMA_CH11_IRQHandler              /*  66, 82, 0x148,                            */
                  .endif
                  .if (USE_HT32_CHIP==HT32F12365_66)
                    .long   CSIF_IRQHandler                   /*  67, 83, 0x14C,                            */
                  .else
                    .long   _RESERVED                         /*  67, 83, 0x14C,                            */
                  .endif
                    .long   EBI_IRQHandler                    /*  68, 84, 0x150,                            */
                  .if (USE_HT32_CHIP==HT32F12365_66)
                    .long   AES_IRQHandler                    /*  69, 85, 0x154,                            */
                  .endif

    .size   __interrupt_vector_cortex_m, . - __interrupt_vector_cortex_m


    .thumb


/* Reset Handler */

    .section .text.Reset_Handler
    .weak  Reset_Handler
    .type  Reset_Handler, %function
Reset_Handler:
                    LDR     R0, =__StackTop      /* set stack pointer */
                    MOV     SP, R0
                  .if (USE_HT32_CHIP==HT32F1653_54_55_56)
                  .else
                    LDR     R0, =BootProcess
                    BLX     R0
                  .endif
                    LDR     R0, =SystemInit
                    BLX     R0

                    /* Copy the data segment initializers from flash to SRAM */
                    MOVS    R1, #0
                    B       LoopCopyDataInit

CopyDataInit:
                    LDR     R3, =_sidata
                    LDR     R3, [R3, R1]
                    STR     R3, [R0, R1]
                    ADDS    R1, R1, #4

LoopCopyDataInit:
                    LDR     R0, =_sdata
                    LDR     R3, =_edata
                    ADDS    R2, R0, R1
                    CMP     R2, R3
                    BCC     CopyDataInit
                    LDR     R2, =_sbss
                    B       LoopFillZerobss

/* Zero fill the bss segment. */
FillZerobss:
                    MOVS    R3, #0
                    STR     R3, [R2]
                    ADDS    R2, R2, #4

LoopFillZerobss:
                    LDR     R3, =_ebss
                    CMP     R2, R3
                    BCC     FillZerobss

                    /* Call static constructors */
                    BL      __libc_init_array

                    /* Call the application's entry point.*/
                    BL      main

LoopForever:
                    B LoopForever

                  .if (USE_HT32_CHIP==HT32F1653_54_55_56)
                  .else
    .thumb_func
BootProcess:
                    LDR     R0, =0x40080300
                    LDR     R1,[R0, #0x10]
                    CMP     R1, #0
                    BNE     BP1
                    LDR     R1,[R0, #0x14]
                    CMP     R1, #0
                    BNE     BP1
                    LDR     R1,[R0, #0x18]
                    CMP     R1, #0
                    BNE     BP1
                    LDR     R1,[R0, #0x1C]
                    CMP     R1, #0
                    BEQ     BP2
BP1:
                    LDR     R0, =0x40080180
                    LDR     R1,[R0, #0xC]
                    LSLS    R1, R1, #4
                    LSRS    R1, R1, #20
                    CMP     R1, #0
                    BEQ     BP3
                    CMP     R1, #1
                    BEQ     BP3
                    CMP     R1, #2
                    BEQ     BP3
BP2:
                    DSB
                    LDR     R0, =0x20000000
                    LDR     R1, =0x05fa0004
                    STR     R1, [R0]
                    LDR     R1, =0xe000ed00
                    LDR     R0, =0x05fa0004
                    STR     R0, [R1, #0xC]
                    DSB
                    B       .
BP3:
                    LDR     R0, =0x20000000
                    LDR     R1, [R0]
                    LDR     R0, =0x05fa0004
                    CMP     R0, R1
                    BEQ     BP4
                    BX      LR
BP4:
                    LDR     R0, =0x40088100
                    LDR     R1, =0x00000001
                    STR     R1, [R0]
                    LDR     R0, =0x20000000
                    LDR     R1, =0x0
                    STR     R1, [R0]
                    BX      LR
                 .endif

    .size  Reset_Handler, .-Reset_Handler

/* Exception Handlers */

    .weak   NMI_Handler
    .type   NMI_Handler, %function
NMI_Handler:
                    B       .
    .size   NMI_Handler, . - NMI_Handler

    .weak   HardFault_Handler
    .type   HardFault_Handler, %function
HardFault_Handler:
                    B       .
    .size   HardFault_Handler, . - HardFault_Handler

    .weak   MemManage_Handler
    .type   MemManage_Handler, %function
MemManage_Handler:
                    B       .
    .size   MemManage_Handler, . - MemManage_Handler

    .weak   BusFault_Handler
    .type   BusFault_Handler, %function
BusFault_Handler:
                    B       .
    .size   BusFault_Handler, . - BusFault_Handler

    .weak   UsageFault_Handler
    .type   UsageFault_Handler, %function
UsageFault_Handler:
                    B       .
    .size   UsageFault_Handler, . - UsageFault_Handler

    .weak   SVC_Handler
    .type   SVC_Handler, %function
SVC_Handler:
                    B       .
    .size   SVC_Handler, . - SVC_Handler

    .weak   DebugMon_Handler
    .type   DebugMon_Handler, %function
DebugMon_Handler:
                    B       .
    .size   DebugMon_Handler, . - DebugMon_Handler

    .weak   PendSV_Handler
    .type   PendSV_Handler, %function
PendSV_Handler:
                    B       .
    .size   PendSV_Handler, . - PendSV_Handler

    .weak   SysTick_Handler
    .type   SysTick_Handler, %function
SysTick_Handler:
                    B       .
    .size   SysTick_Handler, . - SysTick_Handler


/* IRQ Handlers */

    .globl  Default_Handler
    .type   Default_Handler, %function
Default_Handler:
                    B       .
    .size   Default_Handler, . - Default_Handler

    .macro  IRQ handler
    .weak   \handler
    .set    \handler, Default_Handler
    .endm

    IRQ     CKRDY_IRQHandler
    IRQ     LVD_IRQHandler
    IRQ     BOD_IRQHandler
    IRQ     WDT_IRQHandler
    IRQ     RTC_IRQHandler
    IRQ     FLASH_IRQHandler
    IRQ     EVWUP_IRQHandler
    IRQ     LPWUP_IRQHandler
    IRQ     EXTI0_IRQHandler
    IRQ     EXTI1_IRQHandler
    IRQ     EXTI2_IRQHandler
    IRQ     EXTI3_IRQHandler
    IRQ     EXTI4_IRQHandler
    IRQ     EXTI5_IRQHandler
    IRQ     EXTI6_IRQHandler
    IRQ     EXTI7_IRQHandler
    IRQ     EXTI8_IRQHandler
    IRQ     EXTI9_IRQHandler
    IRQ     EXTI10_IRQHandler
    IRQ     EXTI11_IRQHandler
    IRQ     EXTI12_IRQHandler
    IRQ     EXTI13_IRQHandler
    IRQ     EXTI14_IRQHandler
    IRQ     EXTI15_IRQHandler
    IRQ     COMP_IRQHandler
    IRQ     ADC_IRQHandler
    IRQ     MCTM0_BRK_IRQHandler
    IRQ     MCTM0_UP_IRQHandler
    IRQ     MCTM0_TR_IRQHandler
    IRQ     MCTM0_CC_IRQHandler
    IRQ     MCTM1_BRK_IRQHandler
    IRQ     MCTM1_UP_IRQHandler
    IRQ     MCTM1_TR_IRQHandler
    IRQ     MCTM1_CC_IRQHandler
    IRQ     GPTM0_IRQHandler
    IRQ     GPTM1_IRQHandler
    IRQ     BFTM0_IRQHandler
    IRQ     BFTM1_IRQHandler
    IRQ     I2C0_IRQHandler
    IRQ     I2C1_IRQHandler
    IRQ     SPI0_IRQHandler
    IRQ     SPI1_IRQHandler
    IRQ     USART0_IRQHandler
    IRQ     USART1_IRQHandler
    IRQ     UART0_IRQHandler
    IRQ     UART1_IRQHandler
    IRQ     SCI_IRQHandler
    IRQ     I2S_IRQHandler
    IRQ     USB_IRQHandler
    IRQ     SDIO_IRQHandler
    IRQ     PDMA_CH0_IRQHandler
    IRQ     PDMA_CH1_IRQHandler
    IRQ     PDMA_CH2_IRQHandler
    IRQ     PDMA_CH3_IRQHandler
    IRQ     PDMA_CH4_IRQHandler
    IRQ     PDMA_CH5_IRQHandler
    IRQ     PDMA_CH6_IRQHandler
    IRQ     PDMA_CH7_IRQHandler
    IRQ     PDMA_CH8_IRQHandler
    IRQ     PDMA_CH9_IRQHandler
    IRQ     PDMA_CH10_IRQHandler
    IRQ     PDMA_CH11_IRQHandler
    IRQ     CSIF_IRQHandler
    IRQ     EBI_IRQHandler
    IRQ     AES_IRQHandler

    .end
